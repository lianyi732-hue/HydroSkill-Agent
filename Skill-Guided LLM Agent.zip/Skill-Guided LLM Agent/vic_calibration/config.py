# -*- coding: utf-8 -*-
"""
冻结实验配置（benchmark 的"冻结"层）。

时段、预算、停止规则、参数边界、response tolerance 全部在此定义，
运行期不得修改。三个方法（Skill-LLM / NoSkill-LLM / SCE-UA）共享本配置，
以保证完全一致的参数化、bounds 与评估预算。

注：VIC 冷启动 2004–2018，观测 2007 起，故 2004–2006 为暖机期，
率定期从 2007-01-01 起。
"""
import numpy as np

# ------------------------------------------------------------------ #
# 路径
# ------------------------------------------------------------------ #
PROJECT_ROOT = r"E:/thesis"

CONFIG = {
    # ---- 路径 ----
    "project_root":  PROJECT_ROOT,
    "global_param":  r"E:/thesis/data/8-16-110/global_param.C.txt",  # 方案C: 日尺度+FULL_ENERGY=FALSE（方案B=global_param.B.txt 小时尺度；原始 FULL_ENERGY=TRUE=global_param.txt）
    "soil_param":    r"E:/thesis/data/处理好的数据/soil_data/soil_param.txt",   # VIC 工作文件（每轮被乘子覆盖）
    # 不可变基线副本：基线读取永远从它读，绝不就地改写；工作文件 soil_param 每轮覆盖 VIC 读的那个。
    # 防止跨 run 污染（上一轮 final_evaluation 残留的乘子被下一轮当成基线）。
    "soil_param_pristine": r"E:/thesis/data/处理好的数据/soil_data/soil_param.pristine.txt",
    "vic_exe":       r"E:/thesis/VIC-5.1.0/vic/drivers/classic/vic_classic.exe",
    "grid_csv":      r"E:/thesis/data/处理好的数据/vic_grid/grid_coordinates.csv",
    "flux_dir":      r"E:/thesis/data/8-16-110/results",
    "forcing_nc":    r"E:/thesis/data/8-16-110/rvic/forcings/jialingjiang_runoff_2004_2018.nc",
    "rvic_conv_cfg": r"E:/thesis/code/routing/rvic.convolution.jialingjiang.cfg",
    "rvic_master":   r"E:/thesis/RVIC-master",
    "hist_nc":       r"E:/thesis/data/8-16-110/rvic/hist/jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc",
    "obs_dir":       r"E:/thesis/data/嘉陵江流域逐日径流量数据（1950-2018年）",
    "skill_file":    r"E:/thesis/vic_calibration_v1.3.skill",
    "experiments_dir": r"E:/thesis/experiments",

    # ---- 时段 ----
    "cal_start": "2007-01-01",
    "cal_end":   "2015-12-31",
    "val_start": "2016-01-01",
    "val_end":   "2018-12-31",

    # ---- 站点 ----
    "primary_station": "Beibei",
    "primary_keyword": "北碚",
    "internal_stations": [("Wusheng", "武胜"), ("Lueyang", "略阳"),
                          ("Luoduxi", "罗渡溪")],

    # ---- 目标 / 预算 / 停止 ----
    "primary_metric": "NSE",
    "max_evals": 30,
    "nse_targets": [0.50],   # 首跑放宽：到达 NSE=0.50 即 target_reached 停（0.7 对首跑过高）
    "stagnation_window": 2,
    "stagnation_tol": 0.01,
    "stagnation_enabled": False,   # 关闭停滞提前停止：三方法都用满同一评估预算，公平对照
    "rollback_nse_drop": 0.05,     # 本轮 NSE 较 best 跌超此阈值 → 回滚 theta 到 best
    "reask_max": 3,

    # ---- 活动参数（固定 5 个，basin-wide multiplier）----
    "active_params": ["infilt", "Ds", "Dsmax", "Ws", "depth"],

    # ---- 绝对参数边界（skill §3.3，project-specific）----
    "absolute_bounds": {
        "infilt": (0.001, 0.5),
        "Ds":     (0.0001, 0.5),
        "Dsmax":  (0.1, 200.0),
        "Ws":     (0.2, 0.999),
        "depth":  (0.05, 5.0),   # 每层，m
    },

    # ---- hypothesis 验证 tolerance（skill §8）----
    "response_tolerance": {
        "NSE": 0.005,
        "abs_PBIAS_pct": 1.0,
        "abs_peak_error_pct": 2.0,
        "abs_lowflow_error_pct": 2.0,
        "recession_slope_ratio": 0.05,
    },

    # ---- 过程特征细节 ----
    "recession_min_points": 4,   # 退水段最少点数（≥3 个连续下降日 = 4 点）
    "timing_max_lag_days": 7,
    "lowflow_epsilon": 1e-6,
    "te_min_pairs": 30,
}


# ------------------------------------------------------------------ #
# 乘子搜索空间推导
# ------------------------------------------------------------------ #
def compute_multiplier_bounds(baseline_fields, absolute_bounds):
    """对每个参数求乘子合法区间 [m_lo, m_hi]。

    m 需保证所有格点/土层满足 m·p ∈ [lo, hi]：
      m ≥ lo / p_min（最小格点不低于 lo）
      m ≤ hi / p_max（最大格点不高于 hi）
    """
    bounds = {}
    for name, (lo, hi) in absolute_bounds.items():
        vals = baseline_fields[name]
        p_min = float(np.min(vals))
        p_max = float(np.max(vals))
        if p_min <= 0 or p_max <= 0:
            raise ValueError("参数 %s 基线值必须为正，得到 min=%.4g max=%.4g"
                             % (name, p_min, p_max))
        bounds[name] = (lo / p_min, hi / p_max)
    return bounds
