# -*- coding: utf-8 -*-
"""系统提示（Skill / NoSkill）与 calibration-state 构建。

Skill 组系统提示 = vic_calibration_v1.3.skill 全文（已规定 JSON-only）。
NoSkill 组为最小通用指令（消融对照），只给参数名、乘子机制、JSON 契约与
指标符号约定，不含任何物理机制 / 诊断决策树 / 过程特征解释。
"""
import json


def load_skill_text(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


NO_SKILL_SYSTEM = """你是一个水文模型参数率定助手。

任务：对 VIC 水文模型进行参数率定，目标是最大化 NSE（Nash-Sutcliffe 效率系数，越大越好）。

VIC 模型有 5 个可调参数：infilt、Ds、Dsmax、Ws、depth。
它们以 basin-wide 乘子的方式调整：p_i = m_p × p_i(baseline)，m_p 是乘子，从 1.0 出发。
（baseline 是冻结的初始土壤参数场；depth 是三层土壤厚度，用一个乘子等比缩放三层。）

每轮输入（calibration state）含：
- current_params：各参数的当前乘子与当前数值范围；
- metrics：NSE、KGE、PBIAS_pct、RMSE；
- process_features：volume_bias_pct（正=模拟总量偏多）、peak_error_pct（正=洪峰偏高）、
  lowflow_error_pct（正=低流偏高）、recession_slope_ratio（>1=模拟退水更快）、
  timing_bias_days（正=模拟滞后）；
- history：最近几轮的动作与响应。

你需要输出下一轮要调整哪些乘子（每轮最多 2 个），并只输出如下 JSON，不要输出其他文字：

{
  "hypothesis": "你认为当前 NSE 可改进的原因",
  "diagnostic_flags": {"routing_timing_suspected": false, "structural_error_suspected": false},
  "adjustments": [
    {"param": "参数名", "mode": "multiply", "multiplier": 乘子值, "physical_reason": "理由", "confidence": 0.0}
  ],
  "expected_response": {
    "NSE": "increase", "abs_PBIAS": "decrease", "abs_peak_error": "no_clear_change",
    "abs_lowflow_error": "decrease", "recession_slope_ratio": "decrease"
  }
}

要求：
- param 只能是 infilt / Ds / Dsmax / Ws / depth；
- mode 只能是 multiply；
- multiplier 必须为正数；
- 每轮最多调整 2 个参数；
- expected_response 的方向值只能是 increase / decrease / no_clear_change。
"""


def build_current_params_info(baseline_fields, theta, depth_layers,
                              active_params):
    """构建 calibration-state 的 current_params 块（skill §8 结构）。"""
    info = {}
    for name in active_params:
        base = baseline_fields[name]
        m = float(theta[name])
        info[name] = {
            "multiplier": m,
            "baseline_range": [round(float(base.min()), 6),
                               round(float(base.max()), 6)],
            "current_range": [round(float(base.min() * m), 6),
                              round(float(base.max() * m), 6)],
        }
    # depth 额外给出三层
    m = float(theta["depth"])
    info["depth"]["baseline_layers_m"] = [round(x, 4) for x in depth_layers]
    info["depth"]["current_layers_m"] = [round(x * m, 4) for x in depth_layers]
    info["depth"]["total_depth_m"] = round(sum(depth_layers) * m, 4)
    return info


def build_calibration_state(iteration, used, max_evals, current_params_info,
                            metrics, process_features, history,
                            primary_station="Beibei", rollback=None):
    """构建每轮喂给 LLM 的 calibration state（skill §8）。

    rollback=True 时附加一段回滚说明，告知 LLM 已回滚到 best、勿重复被否决方向。
    """
    state = {
        "iteration": iteration,
        "budget": {"used": used, "max": max_evals},
        "objective": {"station": primary_station,
                      "primary_metric": "NSE", "target": "maximize"},
        "parameterization": {
            "type": "basin_wide_multiplier_on_frozen_baseline_fields"
        },
        "current_params": current_params_info,
        "metrics": metrics,
        "process_features": process_features,
        "history": history,
    }
    if rollback:
        state["rollback"] = {
            "triggered": True,
            "message": "上一轮调整使 NSE 较当前最优明显下降，已回滚到最优参数。"
                       "当前 current_params 即回滚后的最优值，请从它出发重新调整，"
                       "不要再重复刚被否决的调整方向。",
        }
    return state


def build_user_message(state):
    """calibration state 的 pretty JSON + 一句输出指令。"""
    body = json.dumps(state, ensure_ascii=False, indent=2)
    return body + "\n\n请输出下一轮参数调整决策（只输出 JSON）。"
