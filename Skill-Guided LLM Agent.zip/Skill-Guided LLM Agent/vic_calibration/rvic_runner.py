# -*- coding: utf-8 -*-
"""RVIC 链条：VIC fluxes → 强迫 nc；以及 convolution 汇流。

fluxes→nc 核心逻辑取自 code/routing/vic_fluxes_to_nc.py；
convolution 复用 RVIC-master 的 rvic.convolution。
"""
import gc
import os
import sys
import time

# HDF5 在 Windows 上默认开文件锁，循环覆盖写 nc 时会偶发 PermissionError
# （安全软件扫描 / 上一步读句柄未及时释放）。必须先于 netCDF4 导入设置。
os.environ.setdefault("HDF5_USE_FILE_LOCKING", "FALSE")

import numpy as np
import pandas as pd
from netCDF4 import Dataset


def build_forcing_nc(flux_dir, grid_csv, out_nc):
    """把 VIC 逐日 fluxes 的 OUT_RUNOFF + OUT_BASEFLOW 转成 RVIC 强迫 nc。

    返回时间步数 ntime（2004-01-01 ~ 2018-12-31 应为 5479）。
    """
    os.makedirs(os.path.dirname(out_nc), exist_ok=True)

    df = pd.read_csv(grid_csv)
    lons = np.sort(np.unique(df["lon_center"].round(6)))   # 升序(西->东)
    lats = np.sort(np.unique(df["lat_center"].round(6)))   # 升序(南->北)
    lats_desc = lats[::-1]                                  # 降序(北->南)
    nlon, nlat = len(lons), len(lats)

    cell_map = {}   # (i, j) -> flux 文件绝对路径
    for _, r in df.iterrows():
        lat, lon = float(r["lat_center"]), float(r["lon_center"])
        i = int(np.argmin(np.abs(lats_desc - lat)))
        j = int(np.argmin(np.abs(lons - lon)))
        fn = "fluxes_%.4f_%.4f.txt" % (lat, lon)
        path = os.path.join(flux_dir, fn)
        if not os.path.isfile(path):
            raise FileNotFoundError("缺少 flux 文件: %s" % path)
        cell_map[(i, j)] = path

    assert len(cell_map) == len(df), "格点映射不唯一"

    runoff = None
    baseflow = None
    ntime = None
    for idx, ((i, j), path) in enumerate(sorted(cell_map.items())):
        d = np.loadtxt(path, skiprows=3, usecols=(5, 6), dtype=np.float64)
        if ntime is None:
            ntime = d.shape[0]
            runoff = np.zeros((ntime, nlat, nlon), dtype=np.float32)
            baseflow = np.zeros((ntime, nlat, nlon), dtype=np.float32)
        if d.shape[0] != ntime:
            raise ValueError("时间长度不一致: %s (%d != %d)"
                             % (path, d.shape[0], ntime))
        runoff[:, i, j] = d[:, 0]
        baseflow[:, i, j] = d[:, 1]

    def _write_nc(path):
        with Dataset(path, "w", format="NETCDF4") as f:
            f.createDimension("time", ntime)
            f.createDimension("lat", nlat)
            f.createDimension("lon", nlon)

            vtime = f.createVariable("time", "f8", ("time",))
            vtime.units = "days since 2004-01-01 00:00:00"
            vtime.calendar = "standard"
            vtime.long_name = "time"
            vtime[:] = np.arange(ntime, dtype=np.float64)

            vlat = f.createVariable("lat", "f8", ("lat",))
            vlat.units = "degrees_north"
            vlat.long_name = "latitude"
            vlat[:] = lats_desc

            vlon = f.createVariable("lon", "f8", ("lon",))
            vlon.units = "degrees_east"
            vlon.long_name = "longitude"
            vlon[:] = lons

            vr = f.createVariable("Runoff", "f4", ("time", "lat", "lon"))
            vr.units = "mm"
            vr.long_name = "surface runoff (VIC OUT_RUNOFF)"
            vr[:, :, :] = runoff

            vb = f.createVariable("Baseflow", "f4", ("time", "lat", "lon"))
            vb.units = "mm"
            vb.long_name = "baseflow (VIC OUT_BASEFLOW)"
            vb[:, :, :] = baseflow

            f.title = "Jialingjiang VIC daily runoff forcing for RVIC convolution"

    # 覆盖写 nc 偶发 PermissionError（Windows 安全软件扫描 / HDF5 锁延迟释放），重试兜底
    last_err = None
    for attempt in range(10):
        gc.collect()   # 释放上一轮 RVIC DataModel 残留的读句柄（引用环→非确定性 GC）
        try:
            _write_nc(out_nc)
            break
        except (PermissionError, OSError) as e:
            last_err = e
            print("[rvic_runner] 写强迫 nc 失败（%s），第 %d 次重试…"
                  % (e, attempt + 1), flush=True)
            time.sleep(5)
    else:
        raise last_err

    return ntime


def run_convolution(cfg_path, rvic_master):
    """运行 RVIC convolution 步，把产流卷积到出口站，输出逐日流量 hist nc。"""
    if rvic_master not in sys.path:
        sys.path.insert(0, rvic_master)
    from rvic.convolution import convolution
    convolution(cfg_path)
    # RVIC 的 DataModel 读句柄靠 GC 释放，偶发引用环导致残留 → 下一轮写 nc 撞共享冲突。
    # 这里显式 gc.collect() 尽早释放读句柄（build_forcing_nc 里还有一道兜底）。
    gc.collect()
