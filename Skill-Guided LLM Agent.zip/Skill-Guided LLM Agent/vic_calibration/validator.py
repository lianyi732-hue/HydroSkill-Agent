# -*- coding: utf-8 -*-
"""LLM JSON 输出的 reject-not-clamp 校验 + 应用。

严格实现 vic_calibration_v1.3.skill §3.4：任一规则违反即 reject（返回原因），
绝不 clamp 后继续。reject 不计入"完整水文模型评价"预算，但计入 LLM 调用。
"""
from . import soil_io

VALID_DIRECTIONS = {"increase", "decrease", "no_clear_change"}

# 顶层禁止字段（会被 reject）
FORBIDDEN_FIELDS = {
    "diagnosis_summary",
    "stop_decision",
    "best_parameter_set",
    "validation_metrics",
    "internal_station_metrics",
    "model_evaluation_budget_decision",
}

# 必需字段
REQUIRED_FIELDS = {"hypothesis", "diagnostic_flags", "adjustments", "expected_response"}


def validate(parsed, current_theta, baseline_lines, absolute_bounds,
             active_params):
    """校验并应用 LLM 建议。

    返回 (ok, err, new_theta, applied)。
      ok=False 时 err 为 reject 原因；ok=True 时 new_theta 为应用后的完整乘子。
    """
    if not isinstance(parsed, dict):
        return False, "输出不是 JSON 对象", dict(current_theta), []

    for f in FORBIDDEN_FIELDS:
        if f in parsed:
            return False, "禁止输出字段: %s" % f, dict(current_theta), []

    for f in REQUIRED_FIELDS:
        if f not in parsed:
            return False, "缺少字段: %s" % f, dict(current_theta), []

    er = parsed.get("expected_response", {})
    if not isinstance(er, dict):
        return False, "expected_response 必须是对象", dict(current_theta), []
    for k, v in er.items():
        if v not in VALID_DIRECTIONS:
            return False, "expected_response.%s 非法方向: %r" % (k, v), \
                dict(current_theta), []

    adjustments = parsed.get("adjustments", [])
    if not isinstance(adjustments, list):
        return False, "adjustments 必须是数组", dict(current_theta), []
    if len(adjustments) > 2:
        return False, "每轮最多调整 2 个参数，收到 %d" % len(adjustments), \
            dict(current_theta), []

    new_theta = dict(current_theta)
    applied = []
    seen = set()
    for adj in adjustments:
        if not isinstance(adj, dict):
            return False, "adjustment 不是对象", dict(current_theta), []
        param = adj.get("param")
        mode = adj.get("mode")
        mult = adj.get("multiplier")

        if param not in active_params:
            return False, "非法参数: %r" % param, dict(current_theta), []
        if mode != "multiply":
            return False, "本版只允许 mode=multiply，收到 %r" % mode, \
                dict(current_theta), []
        if mult is None or not isinstance(mult, (int, float)) or \
                isinstance(mult, bool):
            return False, "multiplier 缺失或非数值: %r" % mult, \
                dict(current_theta), []
        if float(mult) <= 0:
            return False, "multiplier 必须为正，收到 %r" % mult, \
                dict(current_theta), []
        if param in seen:
            return False, "同一参数重复调整: %s" % param, dict(current_theta), []
        seen.add(param)
        new_theta[param] = float(mult)
        applied.append({
            "param": param,
            "mode": mode,
            "multiplier": float(mult),
            "physical_reason": adj.get("physical_reason", ""),
            "confidence": adj.get("confidence"),
        })

    # 越界检查（reject，不 clamp）
    new_lines = soil_io.apply_multipliers(baseline_lines, new_theta)
    violations = soil_io.check_bounds(new_lines, absolute_bounds)
    if violations:
        return False, "越界: " + "; ".join(violations[:3]), \
            dict(current_theta), []

    return True, "", new_theta, applied
