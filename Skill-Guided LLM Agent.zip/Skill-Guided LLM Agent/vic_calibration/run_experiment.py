# -*- coding: utf-8 -*-
"""CLI 入口：运行 VIC 率定实验（Skill-LLM / NoSkill-LLM / SCE-UA）。

用法：
    python run_experiment.py --method skill_llm            # 真实 API + 真实 VIC
    python run_experiment.py --method all --dry-run        # 三种方法各 1 轮 mock
    python run_experiment.py --method sceua --max-evals 20

日志：experiments/vic_{method}_{timestamp}.jsonl
"""
import argparse
import json
import os
import sys
import time

# Windows 控制台/重定向下强制 UTF-8，避免中文打印乱码或报错
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from . import config as config_module
from . import controller, sceua, soil_io


def _run_llm(use_skill, config, dry_run, max_evals, resume_from=None):
    return controller.run_llm_loop(use_skill=use_skill, config=config,
                                   dry_run=dry_run, max_evals=max_evals,
                                   resume_from=resume_from)


def _run_sceua(config, dry_run, max_evals, seed):
    baseline_lines = soil_io.load_soil_lines(config["soil_param_pristine"])
    result, evals = sceua.run_sceua(config=config, dry_run=dry_run,
                                    max_evals=max_evals, seed=seed)
    final = (controller.final_evaluation(result["best_theta"], config,
                                         baseline_lines)
             if not dry_run else {"dry_run": True,
                                  "skipped_final_evaluation": True})

    ts = time.strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(config["experiments_dir"],
                            "vic_sceua_%s.jsonl" % ts)
    os.makedirs(config["experiments_dir"], exist_ok=True)
    record = {"condition": "sceua", "result": result,
              "final_evaluation": final}
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")

    print("完成 sceua：best NSE(cal)=%.4f（%d evals），日志 %s"
          % (result["best_nse"], evals, log_path))
    return result["best_theta"], result["best_nse"], log_path


def main(argv=None):
    p = argparse.ArgumentParser(description="VIC 率定实验（LLM / SCE-UA 对照）")
    p.add_argument("--method", choices=["skill_llm", "noskill_llm", "sceua", "all"],
                   default="skill_llm")
    p.add_argument("--dry-run", action="store_true",
                   help="跳过 VIC 与真实 LLM，用 mock 验证流程")
    p.add_argument("--max-evals", type=int, default=None,
                   help="覆盖默认评估预算")
    p.add_argument("--resume", type=str, default=None,
                   help="从已有 JSONL 日志续跑（跳过已完成轮次，续写同一日志）")
    p.add_argument("--seed", type=int, default=0, help="SCE-UA 随机种子")
    args = p.parse_args(argv)

    config = config_module.CONFIG
    max_evals = args.max_evals or config["max_evals"]

    methods = (["skill_llm", "noskill_llm", "sceua"] if args.method == "all"
               else [args.method])

    for m in methods:
        if m in ("skill_llm", "noskill_llm"):
            _run_llm(use_skill=(m == "skill_llm"), config=config,
                     dry_run=args.dry_run, max_evals=max_evals,
                     resume_from=args.resume)
        elif m == "sceua":
            _run_sceua(config=config, dry_run=args.dry_run,
                       max_evals=max_evals, seed=args.seed)


if __name__ == "__main__":
    main()
