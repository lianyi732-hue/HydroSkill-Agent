# -*- coding: utf-8 -*-
"""手写 SCE-UA（Duan et al. 1992）基线优化器。

- 目标 f(theta) = -NSE_Beibei(率定期)，最小化。
- 搜索边界来自 config.compute_multiplier_bounds（与 Validator 同源）。
- 评估预算 = max_evals（与 LLM 完全一致），共享 controller.evaluate 执行路径。
- 只按乘法器空间搜索（与 LLM 相同参数化），baseline theta=[1.0]*5 作为种群种子。
"""
import numpy as np

from . import config as config_module
from . import controller, metrics, soil_io


def _theta_to_vec(theta, active_params):
    return np.asarray([theta[p] for p in active_params], dtype=np.float64)


def _vec_to_theta(vec, active_params):
    return {p: float(v) for p, v in zip(active_params, vec)}


def _build_objective(config, baseline_lines, obs, dry_run):
    """返回 f(theta_vec) -> -NSE；并附带 eval 计数器与 best 追踪。"""
    active = config["active_params"]
    state = {"evals": 0, "best_nse": -np.inf, "best_vec": None}

    def f(vec):
        state["evals"] += 1
        if dry_run:
            nse = _mock_nse(vec, config, baseline_lines)
        else:
            theta = _vec_to_theta(vec, active)
            sim = controller.evaluate(theta, config, baseline_lines)
            nse = metrics.nse(sim, obs)
        if nse == nse and nse > state["best_nse"]:
            state["best_nse"] = nse
            state["best_vec"] = vec.copy()
        return -nse

    return f, state


def _mock_nse(vec, config, baseline_lines):
    """dry-run 用：以 baseline 为中心的光滑凹函数，便于验证算法跑通。

    不做真实 VIC，只保证 (a) 有可改进方向 (b) 越界不影响（边界由算法约束）。
    """
    # baseline 乘子 = 1.0；构造峰值在 1.0 的简单凹函数，NSE 0.5~0.75 之间
    d = vec - 1.0
    nse = 0.75 - 0.05 * float(np.dot(d, d))
    return nse


# ------------------------------------------------------------------ #
# SCE-UA 主体
# ------------------------------------------------------------------ #
def run_sceua(config=None, dry_run=False, max_evals=None, seed=0):
    config = config or config_module.CONFIG
    max_evals = max_evals or config["max_evals"]
    active = config["active_params"]
    n = len(active)

    # 从不可变基线副本读基线，并把工作文件恢复到纯净基线（防跨 run 污染）
    soil_io.restore_baseline(config["soil_param_pristine"], config["soil_param"])
    baseline_lines = soil_io.load_soil_lines(config["soil_param_pristine"])
    baseline_fields = soil_io.baseline_fields(baseline_lines)
    bounds_map = config_module.compute_multiplier_bounds(baseline_fields,
                                                         config["absolute_bounds"])
    lo = np.asarray([bounds_map[p][0] for p in active])
    hi = np.asarray([bounds_map[p][1] for p in active])

    obs = None
    if not dry_run:
        obs = metrics.load_observed(config["obs_dir"], config["primary_keyword"],
                                    config["cal_start"], config["cal_end"])
    f, state = _build_objective(config, baseline_lines, obs, dry_run)

    rng = np.random.default_rng(seed)

    # 种群规模：极小预算下取 n_complexes=2、每复数 2n+1 点；受 max_evals 上限约束。
    n_complexes = 2
    per_complex = 2 * n + 1
    pop_size = min(max_evals, n_complexes * per_complex)
    n_complexes = max(1, min(n_complexes, pop_size // max(2, 2 * n + 1) or 1))
    per_complex = pop_size // n_complexes
    pop_size = n_complexes * per_complex

    # 初始化：baseline 作种子，其余均匀随机。
    pop = np.empty((pop_size, n))
    pop[0] = _theta_to_vec({p: 1.0 for p in active}, active)
    for i in range(1, pop_size):
        pop[i] = lo + rng.random(n) * (hi - lo)
    fit = np.asarray([f(v) for v in pop])

    # 进化循环：排序 → 分复数 → CCE → 洗牌，直到预算耗尽。
    while state["evals"] < max_evals:
        order = np.argsort(fit)
        pop = pop[order]
        fit = fit[order]

        # 分复数（轮转分配，保证每个复数覆盖整个种群）
        complexes = []
        for k in range(n_complexes):
            idx = np.arange(k, pop_size, n_complexes)
            complexes.append(idx)

        for cidx in complexes:
            if state["evals"] >= max_evals:
                break
            _cce(pop, fit, cidx, lo, hi, f, state, max_evals, rng)

        # 洗牌后重新排序，进入下一轮
        order = np.argsort(fit)
        pop = pop[order]
        fit = fit[order]

    order = np.argsort(fit)
    best_vec = pop[order[0]]
    best_theta = _vec_to_theta(best_vec, active)
    best_nse = state["best_nse"]

    result = {
        "best_theta": best_theta,
        "best_nse": best_nse,
        "evals_used": state["evals"],
        "pop_size": pop_size,
        "n_complexes": n_complexes,
    }
    return result, state["evals"]


def _cce(pop, fit, cidx, lo, hi, f, state, max_evals, rng):
    """Competitive Complex Evolution：对单个复数做一轮演化。

    q = 子复数大小（n+1）；对最差点依次尝试反射/收缩/变异。
    """
    n = pop.shape[1]
    q = min(len(cidx), n + 1)
    if q < 2:
        return

    # 三角概率：排名越靠前（fit 越小）越易被选进子复数
    m = len(cidx)
    if m < 2:
        return
    probs = (m + 1 - np.arange(1, m + 1)) / np.sum(np.arange(1, m + 1))
    sub_idx = rng.choice(cidx, size=q, replace=False, p=probs)
    sub_idx = sub_idx[np.argsort(fit[sub_idx])]

    worst = sub_idx[-1]
    centroid = np.mean(pop[sub_idx[:-1]], axis=0)

    # 反射
    cand = 2.0 * centroid - pop[worst]
    cand = np.clip(cand, lo, hi)
    if state["evals"] >= max_evals:
        return
    f_cand = f(cand)
    if f_cand < fit[worst]:
        pop[worst], fit[worst] = cand, f_cand
        return

    # 收缩
    cand = 0.5 * (centroid + pop[worst])
    cand = np.clip(cand, lo, hi)
    if state["evals"] >= max_evals:
        return
    f_cand = f(cand)
    if f_cand < fit[worst]:
        pop[worst], fit[worst] = cand, f_cand
        return

    # 变异（在复数成员构成的超立方内随机）
    cmin = np.min(pop[cidx], axis=0)
    cmax = np.max(pop[cidx], axis=0)
    cand = cmin + rng.random(n) * (cmax - cmin)
    cand = np.clip(cand, lo, hi)
    if state["evals"] >= max_evals:
        return
    f_cand = f(cand)
    pop[worst], fit[worst] = cand, f_cand
