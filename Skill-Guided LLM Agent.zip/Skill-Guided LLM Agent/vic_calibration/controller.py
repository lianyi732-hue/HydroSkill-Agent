# -*- coding: utf-8 -*-
"""Controller：执行 VIC→RVIC→指标，驱动 LLM（Skill / NoSkill）闭环。

- 停止权归 Controller：max_evals / NSE 达目标 / 连续停滞。
- hypothesis_outcome：用冻结 response_tolerance 比较上一轮 expected_response
  与本轮确定性 actual_response，判 supported / refuted / inconclusive。
- 校验走 validator（reject 不 clamp），reject 计入 LLM 调用但不计入完整模型评价预算。
"""
import json
import os
import sys
import time

import numpy as np
import pandas as pd

from . import config as config_module
from . import metrics, prompts, rvic_runner, soil_io, validator, vic_runner

# 让 controller 能 import 到 E:/thesis/code/llm_clients.py
_CODE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _CODE_DIR not in sys.path:
    sys.path.insert(0, _CODE_DIR)

from llm_clients import call_llm, parse_llm_json  # noqa: E402


def _safe_call_llm(system_prompt, user_msg):
    """调用 LLM，重试耗尽后优雅降级为空串（走 validator 的 reject 路径），不崩掉长跑。"""
    try:
        return call_llm("deepseek", system_prompt, user_msg)
    except Exception as e:  # noqa: BLE001
        print("[controller] LLM 调用失败（已降级为 rejected）：%s" % e)
        return ""

# 与 skill §7 expected_response 的键一致
RESPONSE_KEYS = ["NSE", "abs_PBIAS", "abs_peak_error",
                 "abs_lowflow_error", "recession_slope_ratio"]

# 映射到 config.response_tolerance 的键
TOL_MAP = {
    "NSE": "NSE",
    "abs_PBIAS": "abs_PBIAS_pct",
    "abs_peak_error": "abs_peak_error_pct",
    "abs_lowflow_error": "abs_lowflow_error_pct",
    "recession_slope_ratio": "recession_slope_ratio",
}


# ------------------------------------------------------------------ #
# 共享执行路径：theta → VIC → RVIC → Beibei 率定期模拟序列
# ------------------------------------------------------------------ #
def evaluate(theta, config, baseline_lines):
    """应用乘子、跑 VIC、生成强迫、卷积，返回 Beibei 率定期模拟 Series。"""
    new_lines = soil_io.apply_multipliers(baseline_lines, theta)
    soil_io.write_soil_lines(config["soil_param"], new_lines)

    rc, out, err = vic_runner.run_vic(config["vic_exe"], config["global_param"])
    if rc != 0:
        raise RuntimeError("VIC 运行失败 (rc=%d)\n--- stdout ---\n%s\n--- stderr ---\n%s"
                           % (rc, out[-2000:], err[-2000:]))

    rvic_runner.build_forcing_nc(config["flux_dir"], config["grid_csv"],
                                 config["forcing_nc"])
    rvic_runner.run_convolution(config["rvic_conv_cfg"], config["rvic_master"])

    sim_df = metrics.load_simulated(config["hist_nc"],
                                    config["cal_start"], config["cal_end"])
    return sim_df[config["primary_station"]]


# ------------------------------------------------------------------ #
# hypothesis_outcome 判定
# ------------------------------------------------------------------ #
def _direction(delta, tol):
    if delta != delta:            # NaN
        return "no_clear_change"
    if delta > tol:
        return "increase"
    if delta < -tol:
        return "decrease"
    return "no_clear_change"


def compute_actual_response(prev_m, curr_m, prev_pf, curr_pf, tol_map):
    """把两轮指标差映射为方向（与 expected_response 同键）。"""
    resp = {}
    for key in RESPONSE_KEYS:
        tk = tol_map[key]
        if key == "NSE":
            delta = curr_m["NSE"] - prev_m["NSE"]
        elif key == "abs_PBIAS":
            delta = abs(curr_m["PBIAS_pct"]) - abs(prev_m["PBIAS_pct"])
        elif key == "abs_peak_error":
            delta = abs(curr_pf["peak_error_pct"]) - abs(prev_pf["peak_error_pct"])
        elif key == "abs_lowflow_error":
            delta = abs(curr_pf["lowflow_error_pct"]) - abs(prev_pf["lowflow_error_pct"])
        else:  # recession_slope_ratio
            delta = curr_pf["recession_slope_ratio"] - prev_pf["recession_slope_ratio"]
        resp[key] = _direction(delta, tk)
    return resp


def judge_hypothesis(expected, actual):
    """supported / refuted / inconclusive（确定性规则）。"""
    meaningful = {k: (expected.get(k), actual.get(k)) for k in RESPONSE_KEYS
                  if expected.get(k) in ("increase", "decrease")}
    if not meaningful:
        return "inconclusive"
    any_opposite = any((e == "increase" and a == "decrease") or
                       (e == "decrease" and a == "increase")
                       for e, a in meaningful.values())
    all_agree = all(e == a for e, a in meaningful.values())
    if any_opposite:
        return "refuted"
    if all_agree:
        return "supported"
    return "inconclusive"


def reconstruct_state_from_jsonl(jsonl_path, config):
    """从已完成的 JSONL 日志重建循环状态，供 --resume 续跑。

    只重建"能确定"的状态：theta / best / history / used / prev_* / 阈值记录。
    stagnant 无需重建（停滞停止默认关闭，续跑时从 0 重新计数即可）。
    """
    records = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            if d.get("final"):
                break
            records.append(d)
    if not records:
        raise ValueError("日志里没有可续的迭代记录：%s" % jsonl_path)

    active_params = config["active_params"]
    tol_map = {k: config["response_tolerance"][v] for k, v in TOL_MAP.items()}

    # theta：最后一条记录的 theta 即下一轮 eval 要用的 theta
    theta = dict(records[-1]["theta"])

    # best：best_nse 取最后一条；best_theta = 达到 best 那一轮的 eval theta
    # （eval theta 对第 1 轮 = 全 1.0，对第 k 轮 = 上一条记录的 theta）
    best_nse = records[-1]["best_so_far_nse"]
    best_idx = max(range(len(records)), key=lambda i: records[i]["metrics"]["NSE"])
    best_theta = ({p: 1.0 for p in active_params} if best_idx == 0
                  else dict(records[best_idx - 1]["theta"]))

    used = records[-1]["used"]

    # history：为每条"有后继"的记录重建（描述第 i 轮的 outcome）
    history = []
    for i in range(1, len(records)):
        prev_rec, curr_rec = records[i - 1], records[i]
        actual = compute_actual_response(prev_rec["metrics"], curr_rec["metrics"],
                                         prev_rec["process_features"],
                                         curr_rec["process_features"], tol_map)
        history.append({
            "iteration": i,
            "action": prev_rec["adjustments_applied"] or None,
            "before": {"NSE": prev_rec["metrics"]["NSE"],
                       "PBIAS_pct": prev_rec["metrics"]["PBIAS_pct"]},
            "after": {"NSE": curr_rec["metrics"]["NSE"],
                      "PBIAS_pct": curr_rec["metrics"]["PBIAS_pct"]},
            "actual_response": actual,
            "hypothesis_outcome": curr_rec["hypothesis_outcome"],
        })

    # prev_*：最后一轮的动作/预期，供下一轮 outcome 判定
    last = records[-1]
    parsed = last.get("llm_parsed")
    prev_expected = (parsed.get("expected_response", {}) if parsed else {})
    prev_action = last.get("adjustments_applied") or None

    # n_eval_to_threshold
    n_eval_to_threshold = {t: None for t in config["nse_targets"]}
    for i, rec in enumerate(records, start=1):
        nse = rec["metrics"]["NSE"]
        for t in config["nse_targets"]:
            if n_eval_to_threshold[t] is None and nse >= t:
                n_eval_to_threshold[t] = i

    return {
        "theta": theta, "best_theta": best_theta, "best_nse": best_nse,
        "history": history, "used": used,
        "prev_m": last["metrics"], "prev_pf": last["process_features"],
        "prev_expected": prev_expected, "prev_action": prev_action,
        "n_eval_to_threshold": n_eval_to_threshold,
    }


# ------------------------------------------------------------------ #
# dry-run 桩
# ------------------------------------------------------------------ #
def _mock_sim(obs):
    """dry-run 桩：明显劣化的模拟（低 NSE），保证循环会跑满多轮而非第一轮达目标。"""
    rng = np.random.default_rng(0)
    noise = rng.normal(0, 0.5, len(obs))
    return pd.Series(np.maximum(0.3 * obs.values * (1 + noise), 0.0),
                     index=obs.index)


def _mock_llm():
    return json.dumps({
        "hypothesis": "dry-run 桩：假设降低 Dsmax 可削减水量偏差",
        "diagnostic_flags": {"routing_timing_suspected": False,
                             "structural_error_suspected": False},
        "adjustments": [{"param": "Dsmax", "mode": "multiply", "multiplier": 0.9,
                         "physical_reason": "dry-run", "confidence": 0.5}],
        "expected_response": {"NSE": "increase", "abs_PBIAS": "decrease",
                              "abs_peak_error": "no_clear_change",
                              "abs_lowflow_error": "decrease",
                              "recession_slope_ratio": "decrease"},
    })


# ------------------------------------------------------------------ #
# 主循环
# ------------------------------------------------------------------ #
def run_llm_loop(use_skill, config=None, dry_run=False, max_evals=None,
                 resume_from=None):
    config = config or config_module.CONFIG
    max_evals = max_evals or config["max_evals"]
    active_params = config["active_params"]
    bounds = config["absolute_bounds"]
    tol_map = {k: config["response_tolerance"][v] for k, v in TOL_MAP.items()}

    # 从不可变基线副本读基线，并把工作文件恢复到纯净基线（防跨 run 污染）
    soil_io.restore_baseline(config["soil_param_pristine"], config["soil_param"])
    baseline_lines = soil_io.load_soil_lines(config["soil_param_pristine"])
    baseline_fields = soil_io.baseline_fields(baseline_lines)
    depth_layers = soil_io.depth_layers_baseline(baseline_lines)

    obs = metrics.load_observed(config["obs_dir"], config["primary_keyword"],
                                config["cal_start"], config["cal_end"])

    # 初始化（或从日志恢复）
    if resume_from:
        st = reconstruct_state_from_jsonl(resume_from, config)
        theta = st["theta"]
        history = st["history"]
        used = st["used"]
        best_nse = st["best_nse"]
        best_theta = st["best_theta"]
        n_eval_to_threshold = st["n_eval_to_threshold"]
        prev_m, prev_pf = st["prev_m"], st["prev_pf"]
        prev_expected, prev_action = st["prev_expected"], st["prev_action"]
        stagnant = 0
        start_iteration = used + 1
        print("resume：从第 %d 轮续跑（best NSE=%.4f），日志续写 %s"
              % (start_iteration, best_nse, resume_from))
    else:
        theta = {p: 1.0 for p in active_params}
        history = []            # 供 LLM 输入（最近几轮）
        used = 0
        best_nse = -np.inf
        best_theta = dict(theta)
        stagnant = 0
        n_eval_to_threshold = {t: None for t in config["nse_targets"]}
        prev_m, prev_pf, prev_expected, prev_action = None, None, None, None
        start_iteration = 1

    system_prompt = (prompts.load_skill_text(config["skill_file"]) if use_skill
                     else prompts.NO_SKILL_SYSTEM)
    cond = "skill_llm" if use_skill else "noskill_llm"
    if resume_from:
        log_path = resume_from           # 续写原日志，保持轨迹连续
    else:
        ts = time.strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(config["experiments_dir"],
                                "vic_%s_%s.jsonl" % (cond, ts))
    os.makedirs(config["experiments_dir"], exist_ok=True)

    for iteration in range(start_iteration, max_evals + 1):
        # 1. 跑模型（占 1 次完整水文模型评价）
        if dry_run:
            sim = _mock_sim(obs)
        else:
            sim = evaluate(theta, config, baseline_lines)
        m, pf = metrics.compute_cal_metrics(sim, obs, config)
        used += 1

        nse_now = m["NSE"]

        # 2. 上一轮假设的 outcome
        outcome = None
        if prev_m is not None and prev_expected is not None:
            actual = compute_actual_response(prev_m, m, prev_pf, pf, tol_map)
            outcome = judge_hypothesis(prev_expected, actual)
            history.append({
                "iteration": iteration - 1,
                "action": prev_action,
                "before": {"NSE": prev_m["NSE"], "PBIAS_pct": prev_m["PBIAS_pct"]},
                "after": {"NSE": m["NSE"], "PBIAS_pct": m["PBIAS_pct"]},
                "actual_response": actual,
                "hypothesis_outcome": outcome,
            })

        # 3. 更新 best / 阈值记录 / 停滞
        if not np.isnan(nse_now):
            if nse_now > best_nse:
                best_nse = nse_now
                best_theta = dict(theta)
                stagnant = 0
            else:
                if abs(nse_now - best_nse) < config["stagnation_tol"]:
                    stagnant += 1
                else:
                    stagnant = 0
            for t in config["nse_targets"]:
                if n_eval_to_threshold[t] is None and nse_now >= t:
                    n_eval_to_threshold[t] = used

        # 3.5 回滚：本轮 NSE 较 best 跌超阈值 → 回滚 theta 到 best，避免在坏态上继续
        rolled_back = False
        rollback_drop = config.get("rollback_nse_drop", 0.05)
        if (not np.isnan(nse_now)) and best_nse != -np.inf and \
                (best_nse - nse_now) > rollback_drop:
            theta = dict(best_theta)
            rolled_back = True

        # 4. 停止判定（停滞停止默认关闭，三方法用满同一预算）
        if not np.isnan(nse_now) and nse_now >= config["nse_targets"][-1]:
            status = "target_reached"
        elif config.get("stagnation_enabled", False) and stagnant >= config["stagnation_window"]:
            status = "stagnated"
        elif used >= max_evals:
            status = "budget_exhausted"
        else:
            status = None

        if status is not None:
            _log(log_path, _record(iteration, cond, theta, m, pf, used, status,
                                   None, None, [], outcome, best_nse, rolled_back))
            break

        # 5. 构建 state → LLM
        cp_info = prompts.build_current_params_info(baseline_fields, theta,
                                                    depth_layers, active_params)
        state = prompts.build_calibration_state(
            iteration, used, max_evals, cp_info, m, pf, history[-8:],
            config["primary_station"], rollback=rolled_back)
        user_msg = prompts.build_user_message(state)

        if dry_run:
            llm_raw = _mock_llm()
        else:
            llm_raw = _safe_call_llm(system_prompt, user_msg)

        parsed = parse_llm_json(llm_raw)

        # 6. 校验（reject 则 re-ask）
        applied = []
        new_theta = theta
        if parsed is None:
            ok, err = False, "JSON 解析失败"
        else:
            ok, err, new_theta, applied = validator.validate(
                parsed, theta, baseline_lines, bounds, active_params)

        reask = 0
        while (not ok) and reask < config["reask_max"] and not dry_run:
            reask += 1
            followup = "你上一次输出被拒绝：%s\n请重新输出下一轮 JSON（只输出 JSON）。" % err
            llm_raw = _safe_call_llm(system_prompt,
                                     user_msg + "\n\n" + followup)
            parsed = parse_llm_json(llm_raw)
            if parsed is None:
                ok, err = False, "JSON 解析失败"
            else:
                ok, err, new_theta, applied = validator.validate(
                    parsed, theta, baseline_lines, bounds, active_params)

        status = "ok" if ok else "rejected"

        # 7. 记录本轮动作，供下一轮 outcome 判定
        prev_m, prev_pf = m, pf
        prev_expected = (parsed.get("expected_response", {}) if parsed else {})
        prev_action = applied if applied else None
        theta = new_theta

        _log(log_path, _record(iteration, cond, theta, m, pf, used, status,
                               llm_raw, parsed, applied, outcome, best_nse,
                               rolled_back))

    # 8. 结束：冻结 best，最终评价
    final = (final_evaluation(best_theta, config, baseline_lines)
             if not dry_run else {"dry_run": True,
                                  "skipped_final_evaluation": True})
    _log(log_path, {"final": True, "best_theta": best_theta,
                    "best_nse_cal": best_nse,
                    "n_eval_to_threshold": n_eval_to_threshold,
                    "final_evaluation": final})

    print("完成 %s：best NSE(cal)=%.4f，日志 %s" % (cond, best_nse, log_path))
    return best_theta, best_nse, log_path


# ------------------------------------------------------------------ #
# 落盘
# ------------------------------------------------------------------ #
def _record(iteration, cond, theta, m, pf, used, status, llm_raw, parsed,
            applied, outcome, best_nse, rolled_back=False):
    return {
        "iteration": iteration,
        "condition": cond,
        "theta": dict(theta),
        "metrics": m,
        "process_features": pf,
        "used": used,
        "status": status,
        "llm_raw": llm_raw,
        "llm_parsed": parsed,
        "adjustments_applied": applied,
        "hypothesis_outcome": outcome,
        "best_so_far_nse": best_nse,
        "rolled_back": rolled_back,
    }


def _log(log_path, record):
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")


# ------------------------------------------------------------------ #
# 冻结后最终评价（验证期 + 内部站点，不回流率定循环）
# ------------------------------------------------------------------ #
def final_evaluation(best_theta, config, baseline_lines):
    """只跑一次：写入 best theta、跑链、算 Beibei 验证期 + 内部站点指标。"""
    try:
        new_lines = soil_io.apply_multipliers(baseline_lines, best_theta)
        soil_io.write_soil_lines(config["soil_param"], new_lines)
        rc, out, err = vic_runner.run_vic(config["vic_exe"], config["global_param"])
        if rc != 0:
            return {"error": "VIC 失败 rc=%d" % rc}
        rvic_runner.build_forcing_nc(config["flux_dir"], config["grid_csv"],
                                     config["forcing_nc"])
        rvic_runner.run_convolution(config["rvic_conv_cfg"], config["rvic_master"])
    except Exception as e:  # noqa: BLE001
        return {"error": str(e)}

    result = {}
    # Beibei 验证期
    try:
        sim_val = metrics.load_simulated(config["hist_nc"],
                                         config["val_start"], config["val_end"])
        obs_val = metrics.load_observed(config["obs_dir"], config["primary_keyword"],
                                        config["val_start"], config["val_end"])
        m_val, _ = metrics.compute_cal_metrics(sim_val[config["primary_station"]],
                                               obs_val, config)
        result["Beibei_val"] = m_val
    except Exception as e:  # noqa: BLE001
        result["Beibei_val"] = {"error": str(e)}

    # 内部站点（率定期 + 验证期整体 2007-2018，与 compare_discharge 一致）
    for name, kw in config["internal_stations"]:
        try:
            obs_full = metrics.load_observed(config["obs_dir"], kw,
                                             config["cal_start"], config["val_end"])
            sim_full = metrics.load_simulated(config["hist_nc"],
                                              config["cal_start"], config["val_end"])
            m_full, _ = metrics.compute_cal_metrics(sim_full[name], obs_full, config)
            result[name] = m_full
        except Exception as e:  # noqa: BLE001
            result[name] = {"error": str(e)}

    return result
