# -*- coding: utf-8 -*-
"""确定性指标（NSE/KGE/PBIAS/RMSE/R）与过程特征（VB/PE/LE/RR/TE）。

观测/模拟加载逻辑取自 code/routing/compare_discharge.py。
过程特征定义严格按 vic_calibration_v1.3.skill §3 2.1，全部确定性计算，
LLM 不参与估算。
"""
import glob
import os

import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date


# ------------------------------------------------------------------ #
# 加载
# ------------------------------------------------------------------ #
def load_observed(obs_dir, keyword, start, end):
    """读取实测逐日径流 xlsx，返回以日期为索引的 Series (m3/s)。"""
    files = glob.glob(os.path.join(obs_dir, "*%s*.xlsx" % keyword))
    if not files:
        raise FileNotFoundError("找不到实测文件: %s" % keyword)
    df = pd.read_excel(files[0], engine="openpyxl")
    y, m, d = df.iloc[:, 0], df.iloc[:, 1], df.iloc[:, 2]
    q = pd.to_numeric(df.iloc[:, 3], errors="coerce")
    idx = pd.to_datetime(dict(year=y, month=m, day=d), errors="coerce")
    s = pd.Series(q.values, index=idx).sort_index()
    s = s[~s.index.duplicated(keep="first")]
    return s[(s.index >= pd.Timestamp(start)) & (s.index <= pd.Timestamp(end))]


def load_simulated(hist_nc, start, end):
    """读取 RVIC hist nc，返回 DataFrame（列=站点名，索引=日期，m3/s）。"""
    f = Dataset(hist_nc, "r")
    sf = f.variables["streamflow"][:]
    t = f.variables["time"][:]
    t_units = f.variables["time"].units
    t_cal = f.variables["time"].calendar
    names = [b"".join(r).decode().strip()
             for r in np.asarray(f.variables["outlet_name"][:], dtype="S1")]
    f.close()

    dates = num2date(t, t_units, calendar=t_cal)
    dates = [pd.Timestamp(d.year, d.month, d.day, d.hour, d.minute, d.second)
             for d in dates]
    df = pd.DataFrame(sf, index=dates, columns=names)
    df = df[~df.index.duplicated(keep="first")]
    return df[(df.index >= pd.Timestamp(start)) & (df.index <= pd.Timestamp(end))]


# ------------------------------------------------------------------ #
# 基础指标
# ------------------------------------------------------------------ #
def _mask(sim, obs):
    """对齐并返回有效 (s, o) numpy 数组。"""
    obs = obs.reindex(sim.index)
    m = obs.notna() & sim.notna()
    return sim[m].values.astype(float), obs[m].values.astype(float)


def nse(sim, obs):
    s, o = _mask(sim, obs)
    if len(s) < 30 or np.var(o) == 0:
        return np.nan
    return float(1.0 - np.sum((s - o) ** 2) / np.sum((o - o.mean()) ** 2))


def pbias(sim, obs):
    s, o = _mask(sim, obs)
    if len(s) < 30 or np.sum(o) == 0:
        return np.nan
    return float(100.0 * np.sum(s - o) / np.sum(o))


def rmse(sim, obs):
    s, o = _mask(sim, obs)
    if len(s) < 30:
        return np.nan
    return float(np.sqrt(np.mean((s - o) ** 2)))


def pearson_r(sim, obs):
    s, o = _mask(sim, obs)
    if len(s) < 30:
        return np.nan
    return float(np.corrcoef(s, o)[0, 1])


def kge(sim, obs):
    """Kling-Gupta Efficiency：1 - sqrt((r-1)^2 + (alpha-1)^2 + (beta-1)^2)。"""
    s, o = _mask(sim, obs)
    if len(s) < 30 or np.std(o) == 0 or np.mean(o) == 0:
        return np.nan
    r = np.corrcoef(s, o)[0, 1]
    alpha = np.std(s) / np.std(o)
    beta = np.mean(s) / np.mean(o)
    return float(1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


# ------------------------------------------------------------------ #
# 过程特征
# ------------------------------------------------------------------ #
def volume_bias(sim, obs):
    """VB = PBIAS（%）。"""
    return pbias(sim, obs)


def peak_error(sim, obs):
    """PE = median over years of 年最大日流量相对误差（%）。"""
    obs = obs.reindex(sim.index)
    m = obs.notna() & sim.notna()
    s = sim[m].values.astype(float)
    o = obs[m].values.astype(float)
    idx = obs[m].index
    if len(s) < 30:
        return np.nan
    ps = pd.Series(s, index=idx).groupby(idx.year).max()
    po = pd.Series(o, index=idx).groupby(idx.year).max()
    years = ps.index.intersection(po.index)
    errs = [100.0 * (ps[y] - po[y]) / po[y] for y in years if po[y] > 0]
    if not errs:
        return np.nan
    return float(np.median(errs))


def lowflow_error(sim, obs, epsilon=1e-6):
    """LE = (Q10_sim - Q10_obs) / Q10_obs × 100（%），Q10 = 10 分位。"""
    s, o = _mask(sim, obs)
    if len(s) < 30:
        return np.nan
    q10s = np.percentile(s, 10)
    q10o = np.percentile(o, 10)
    if abs(q10o) < epsilon:
        q10o = epsilon
    return float((q10s - q10o) / q10o * 100.0)


def _recession_slopes(values, min_points=4):
    """识别 ≥min_points 点的连续下降退水段，拟合 ln Q = a - k t，返回 k 列表。"""
    vals = np.asarray(values, dtype=float)
    ks = []
    n = len(vals)
    start = 0
    for t in range(1, n):
        if vals[t] < vals[t - 1]:
            continue
        seg = vals[start:t]
        if len(seg) >= min_points:
            k = _fit_recession(seg)
            if k is not None and k > 0:
                ks.append(k)
        start = t
    seg = vals[start:]
    if len(seg) >= min_points:
        k = _fit_recession(seg)
        if k is not None and k > 0:
            ks.append(k)
    return ks


def _fit_recession(seg):
    idx = seg > 0
    if idx.sum() < 3:
        return None
    seg = seg[idx]
    t = np.arange(len(seg))
    slope = np.polyfit(t, np.log(seg), 1)[0]
    return float(-slope)


def recession_slope_ratio(sim, obs, min_points=4):
    """RR = median(k_sim) / median(k_obs)。>1 表示模拟退水更快。"""
    s, o = _mask(sim, obs)
    ks = _recession_slopes(s, min_points)
    ko = _recession_slopes(o, min_points)
    if not ks or not ko:
        return np.nan
    return float(np.median(ks) / np.median(ko))


def timing_error(sim, obs, max_lag=7, min_pairs=30):
    """TE = argmax_lag corr(Qobs(t), Qsim(t+lag))，|lag| ≤ max_lag。>0 模拟滞后。"""
    s, o = _mask(sim, obs)
    n = len(s)
    so = (o - o.mean()) / (o.std() + 1e-12)
    ss = (s - s.mean()) / (s.std() + 1e-12)
    best_lag, best_corr = 0, -np.inf
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            a = so[:n - lag]
            b = ss[lag:]
        else:
            a = so[-lag:]
            b = ss[:n + lag]
        if len(a) < min_pairs:
            continue
        c = np.corrcoef(a, b)[0, 1]
        if c > best_corr:
            best_corr, best_lag = c, lag
    return int(best_lag)


# ------------------------------------------------------------------ #
# 汇总
# ------------------------------------------------------------------ #
def compute_cal_metrics(sim, obs, config=None):
    """计算北碚率定期主指标 + 过程特征。返回 (metrics, process_features)。"""
    cfg = config or {}
    eps = cfg.get("lowflow_epsilon", 1e-6)
    rp = cfg.get("recession_min_points", 4)
    mlag = cfg.get("timing_max_lag_days", 7)
    mpr = cfg.get("te_min_pairs", 30)

    m = {
        "NSE": nse(sim, obs),
        "KGE": kge(sim, obs),
        "PBIAS_pct": pbias(sim, obs),
        "RMSE": rmse(sim, obs),
    }
    pf = {
        "volume_bias_pct": volume_bias(sim, obs),
        "peak_error_pct": peak_error(sim, obs),
        "lowflow_error_pct": lowflow_error(sim, obs, epsilon=eps),
        "recession_slope_ratio": recession_slope_ratio(sim, obs, min_points=rp),
        "timing_bias_days": timing_error(sim, obs, max_lag=mlag, min_pairs=mpr),
    }
    return m, pf
