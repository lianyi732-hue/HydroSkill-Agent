# -*- coding: utf-8 -*-
"""VIC Classic driver 的 subprocess 封装。"""
import os
import subprocess


def run_vic(vic_exe, global_param, timeout=None):
    """运行 VIC Classic，返回 (returncode, stdout, stderr)。

    VIC 结果写入 global_param.txt 指定的 RESULT_DIR（原地覆盖 fluxes_*）。

    timeout 默认 None（不设超时）。subprocess.run 的 timeout 基于 time.monotonic()，
    该时钟在 Windows 上会跨系统睡眠继续计数：若设固定超时（如 7200s），机器睡几小时后
    超时在睡眠期间耗尽，醒来时 subprocess 立刻 TimeoutExpired 杀掉 VIC，白废整轮。
    VIC 是确定性计算（同配置必终止），故不设超时；真卡死靠外部 CPU 采样诊断。
    """
    cwd = os.path.dirname(global_param)
    proc = subprocess.run(
        [vic_exe, "-g", global_param],
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr
