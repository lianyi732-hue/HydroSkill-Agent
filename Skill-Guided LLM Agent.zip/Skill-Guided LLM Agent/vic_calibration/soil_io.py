# -*- coding: utf-8 -*-
"""soil_param.txt 的 token 级读写与乘子应用。

只修改 7 个活动列（1 基 5/6/7/8/23/24/25），其余 token 原样保留，
避免 int/float 混排与 -99 哨兵被破坏。
"""
import numpy as np

# 活动参数 -> 1 基列号（depth 为三层）
SOIL_COLS = {
    "infilt": [5],
    "Ds":     [6],
    "Dsmax":  [7],
    "Ws":     [8],
    "depth":  [23, 24, 25],
}


def load_soil_lines(path):
    """读取 soil_param.txt，返回 list[list[str]]（按空白切分）。"""
    with open(path, "r", encoding="utf-8") as f:
        return [ln.strip().split() for ln in f if ln.strip()]


def restore_baseline(pristine_path, working_path):
    """把不可变基线副本覆盖到 VIC 工作文件，保证每次 run 从纯净基线出发。

    这是跨 run 防污染的安全闸：apply_multipliers 会就地改写 working 文件，
    若不显式恢复，上一轮 final_evaluation 残留的乘子会被下一轮误当基线。
    """
    with open(pristine_path, "r", encoding="utf-8") as f:
        content = f.read()
    with open(working_path, "w", encoding="utf-8") as f:
        f.write(content)


def write_soil_lines(path, lines):
    """写回 soil_param.txt（单空格 join，保留行结构）。"""
    with open(path, "w", encoding="utf-8") as f:
        for toks in lines:
            f.write(" ".join(toks) + "\n")


def baseline_fields(lines):
    """提取 5 参数基线值。返回 {name: 1D np.ndarray}（depth 展开三层所有值）。"""
    fields = {}
    for name, cols in SOIL_COLS.items():
        vals = []
        for toks in lines:
            for c in cols:
                vals.append(float(toks[c - 1]))
        fields[name] = np.asarray(vals, dtype=np.float64)
    return fields


def depth_layers_baseline(lines):
    """返回第一行数据的三层深度 [d1, d2, d3]（本数据中全场恒定）。"""
    toks = lines[0]
    return [float(toks[c - 1]) for c in SOIL_COLS["depth"]]


def apply_multipliers(lines, theta):
    """把 theta[name] 乘到对应活动列上（基于传入 lines 的当前值）。

    注意：调用方应始终传入 baseline lines + 完整 theta，得到
    p_i = m_p · p_i(baseline) 的字段。返回新的 token 列表。
    """
    new_lines = []
    for toks in lines:
        new_toks = list(toks)
        for name, cols in SOIL_COLS.items():
            m = float(theta.get(name, 1.0))
            for c in cols:
                v = float(toks[c - 1]) * m
                new_toks[c - 1] = "%.4f" % v
        new_lines.append(new_toks)
    return new_lines


def check_bounds(lines, absolute_bounds):
    """检查（已乘好乘子的）lines 是否全部落在绝对边界内。返回违规明细列表。"""
    violations = []
    for name, cols in SOIL_COLS.items():
        lo, hi = absolute_bounds[name]
        for toks in lines:
            for c in cols:
                v = float(toks[c - 1])
                if v < lo or v > hi:
                    violations.append("%s=%.6g 越界 [%.4g, %.4g]"
                                      % (name, v, lo, hi))
                    break  # 该参数只报一次
    return violations
