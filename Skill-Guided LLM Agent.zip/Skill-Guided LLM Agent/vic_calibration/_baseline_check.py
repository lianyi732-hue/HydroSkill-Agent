# -*- coding: utf-8 -*-
"""一次性诊断：跳过 VIC，直接用已完成的 fluxes 跑下游链，得水量平衡基线 NSE。

背景：方案 B 最小闭环的 eval 1 VIC 在写完全部 305 个 fluxes（每格 5479 行，完整）
后，尚未正常退出就被 3600s 超时杀掉。fluxes 本身已完整，故无需重跑 VIC，
直接 build_forcing_nc -> run_convolution -> metrics 即可得基线 NSE。
"""
import json
import sys
import time

sys.path.insert(0, r"E:/thesis/code")

from vic_calibration import config as cfg  # noqa: E402
from vic_calibration import metrics, rvic_runner  # noqa: E402

C = cfg.CONFIG

t0 = time.time()
ntime = rvic_runner.build_forcing_nc(C["flux_dir"], C["grid_csv"], C["forcing_nc"])
t1 = time.time()
print("build_forcing_nc: ntime=%d  %.1fs" % (ntime, t1 - t0), flush=True)

rvic_runner.run_convolution(C["rvic_conv_cfg"], C["rvic_master"])
t2 = time.time()
print("run_convolution: %.1fs" % (t2 - t1), flush=True)

obs = metrics.load_observed(C["obs_dir"], C["primary_keyword"],
                            C["cal_start"], C["cal_end"])
sim = metrics.load_simulated(C["hist_nc"], C["cal_start"], C["cal_end"])
m, pf = metrics.compute_cal_metrics(sim[C["primary_station"]], obs, C)

print("=== Beibei 率定期(2007-2015) 水量平衡(FULL_ENERGY=FALSE) 基线 ===")
print(json.dumps({"metrics": m, "process_features": pf},
                 ensure_ascii=False, indent=2, default=str))
