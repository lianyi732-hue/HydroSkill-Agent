Release Tests Configuration
