Example Tests Configuration
