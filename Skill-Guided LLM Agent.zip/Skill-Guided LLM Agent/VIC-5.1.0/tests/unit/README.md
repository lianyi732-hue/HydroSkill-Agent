Unit Tests Configuration
