Science Tests Configuration
