/******************************************************************************
 * @section DESCRIPTION
 *
 * Write vic timing table for classic driver
 *****************************************************************************/

#include <vic_driver_classic.h>

/******************************************************************************
 * @brief    VIC timing file
 *****************************************************************************/
void
write_vic_timing_table(timer_struct *timers)
{
    extern FILE               *LOG_DEST;
    extern filenames_struct    filenames;
    extern global_param_struct global_param;

    char                       machine[MAXSTRING];
    char                       user[MAXSTRING];
    time_t                     curr_date_time;
    struct tm                 *timeinfo;
    uid_t                      uid;
    struct passwd             *pw;
    double                     ndays;
    double                     nyears;

    // datestr
    curr_date_time = time(NULL);
    if (curr_date_time == -1) {
        log_err("Failed to get the current time!");
    }
    timeinfo = localtime(&curr_date_time);

    // hostname
    if (gethostname(machine, MAXSTRING) != 0) {
        strcpy(machine, "unknown");
    }

    // username
    uid = geteuid();
    pw = getpwuid(uid);

    if (pw) {
        strcpy(user, pw->pw_name);
    }
    else {
        strcpy(user, "unknown");
    }

    // calculate run length
    ndays = global_param.dt * global_param.nrecs / SEC_PER_DAY;
    nyears = ndays / DAYS_PER_YEAR;

    fprintf(LOG_DEST, "\n");
    fprintf(LOG_DEST,
            "------------------------------"
            " VIC TIMING PROFILE "
            "------------------------------\n\n");
    fprintf(LOG_DEST, "  Date                      : %s", asctime(timeinfo));
    fprintf(LOG_DEST, "  Compiler                  : %s (%s)\n", COMPILER,
            COMPILER_VERSION);
    fprintf(LOG_DEST, "  Machine                   : %s\n", machine);
    fprintf(LOG_DEST, "  VIC User                  : %s\n", user);
    fprintf(LOG_DEST, "  VIC Version               : %s\n", GIT_VERSION);
    fprintf(LOG_DEST, "  VIC GIT Version           : %s\n", VERSION);
    fprintf(LOG_DEST, "  VIC_DRIVER                : %s\n", VIC_DRIVER);
    fprintf(LOG_DEST, "\n");
    fprintf(LOG_DEST, "  Global Param File         : %s\n", filenames.global);
    fprintf(LOG_DEST, "  Start Date                : %04hu-%02hu-%02hu-%05u\n",
            global_param.startyear, global_param.startmonth,
            global_param.startday, global_param.startsec);
    fprintf(LOG_DEST, "  Stop Date                 : %04hu-%02hu-%02hu\n",
            global_param.endyear, global_param.endmonth, global_param.endday);
    fprintf(LOG_DEST, "  Nrecs                     : %zu\n",
            global_param.nrecs);
    fprintf(LOG_DEST, "  Model Timestep (seconds)  : %g\n", global_param.dt);
    fprintf(LOG_DEST, "  Snow Timestep (seconds)   : %g\n",
            global_param.snow_dt);
    fprintf(LOG_DEST, "  Runoff Timestep (seconds) : %g\n",
            global_param.runoff_dt);
    fprintf(LOG_DEST, "  Atmos Timestep (seconds)  : %g\n",
            global_param.atmos_dt);
    fprintf(LOG_DEST, "\n");

    fprintf(LOG_DEST, "\n");

    fprintf(LOG_DEST, "  Overall Metrics\n");
    fprintf(LOG_DEST, "  ---------------\n");
    fprintf(LOG_DEST, "    Model Cost       : %g pe-hrs/simulated_year\n",
            timers[TIMER_VIC_ALL].delta_wall / SEC_PER_HOUR / nyears);
    fprintf(LOG_DEST, "    Model Throughput : %g simulated_years/day\n",
            nyears / (timers[TIMER_VIC_ALL].delta_wall / SEC_PER_DAY));
    fprintf(LOG_DEST, "\n");
    fprintf(LOG_DEST, "  Timing Table:\n");
    fprintf(LOG_DEST,
            "|------------|----------------------|----------------------|----------------------|----------------------|\n");
    fprintf(LOG_DEST,
            "| Timer      | Wall Time (secs)     | CPU Time (secs)      | Wall Time (secs/day) | CPU Time (secs/day)  |\n");
    fprintf(LOG_DEST,
            "|------------|----------------------|----------------------|----------------------|----------------------|\n");
    fprintf(LOG_DEST, "| Init Time  | %20g | %20g | %20g | %20g |\n",
            timers[TIMER_VIC_INIT].delta_wall, timers[TIMER_VIC_INIT].delta_cpu,
            timers[TIMER_VIC_INIT].delta_wall / ndays,
            timers[TIMER_VIC_INIT].delta_cpu / ndays);
    fprintf(LOG_DEST, "| Run Time   | %20g | %20g | %20g | %20g |\n",
            timers[TIMER_VIC_RUN].delta_wall, timers[TIMER_VIC_RUN].delta_cpu,
            timers[TIMER_VIC_RUN].delta_wall / ndays,
            timers[TIMER_VIC_RUN].delta_cpu / ndays);
    fprintf(LOG_DEST, "| Final Time | %20g | %20g | %20g | %20g |\n",
            timers[TIMER_VIC_FINAL].delta_wall,
            timers[TIMER_VIC_FINAL].delta_cpu,
            timers[TIMER_VIC_FINAL].delta_wall / ndays,
            timers[TIMER_VIC_FINAL].delta_cpu / ndays);
    fprintf(LOG_DEST, "| Total Time | %20g | %20g | %20g | %20g |\n",
            timers[TIMER_VIC_ALL].delta_wall, timers[TIMER_VIC_ALL].delta_cpu,
            timers[TIMER_VIC_ALL].delta_wall / ndays,
            timers[TIMER_VIC_ALL].delta_cpu / ndays);
    fprintf(LOG_DEST,
            "|------------|----------------------|----------------------|----------------------|----------------------|\n");
    fprintf(LOG_DEST, "\n");

    fprintf(LOG_DEST,
            "\n------------------------------"
            " END VIC TIMING PROFILE "
            "------------------------------\n\n");
}
