"""
LLM API wrappers for DeepSeek, OpenAI (GPT-4o), and Anthropic (Claude Opus).

Usage:
    from llm_clients import call_llm
    response_text = call_llm("deepseek", system_prompt, user_message)
"""

import os
import json
import re
import time


# ── API Keys（从环境变量读取，或直接在此填写）──────────────────────────────

DEEPSEEK_API_KEY  = os.environ.get("DEEPSEEK_API_KEY",  "sk-384d904c0c1e40da82e4a2d404f9292e")
OPENAI_API_KEY    = os.environ.get("OPENAI_API_KEY",    "sk-HBB76rHxiyNi6w92r1rBJqxssHvSKpDOrDur0qjd6kE9slZZ")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "YOUR_ANTHROPIC_KEY_HERE")
GLM_API_KEY       = os.environ.get("GLM_API_KEY",       "be348bbc1d3b4573b0a53489f4fc4117.iQLQLOHwidvmxaxv")


# ── Model IDs ─────────────────────────────────────────────────────────────────

LLM_MODELS = {
    # deepseek-reasoner 已于 2026-07-24 停用，改用 v4-flash 开思考模式（等价映射）。
    # 重推理可用 deepseek-v4-pro。
    "deepseek": "deepseek-v4-flash",
    "gpt4o":    "gpt-5.5",   # 中转站(zhangsan.yun)的模型名；官方 OpenAI 改回 gpt-4o
    "opus":     "claude-opus-5",
    "sonnet":   "claude-sonnet-5",
    "glm":      "GLM-5.3-Flash",
}


def call_llm(llm_type: str, system_prompt: str, user_message: str,
             max_retries: int = 3, temperature: float = 0.0) -> str:
    """
    Call the specified LLM and return its raw text response.

    Parameters
    ----------
    llm_type     : one of "deepseek", "gpt4o", "opus"
    system_prompt: system/instruction prompt (contains Skill or plain instruction)
    user_message : current calibration state message
    max_retries  : number of retry attempts on failure
    temperature  : sampling temperature (0 = deterministic)

    Returns
    -------
    Raw text response from LLM (should contain JSON)
    """
    llm_type = llm_type.lower()
    if llm_type not in LLM_MODELS:
        raise ValueError(f"Unknown LLM: {llm_type}. Choose from {list(LLM_MODELS)}")

    for attempt in range(max_retries):
        try:
            if llm_type == "deepseek":
                return _call_deepseek(system_prompt, user_message, temperature)
            elif llm_type == "gpt4o":
                return _call_openai(system_prompt, user_message, temperature)
            elif llm_type in ("opus", "sonnet"):
                return _call_anthropic(system_prompt, user_message, temperature,
                                       LLM_MODELS[llm_type])
            elif llm_type == "glm":
                return _call_glm(system_prompt, user_message, temperature)
        except Exception as e:
            print(f"[llm_clients] Attempt {attempt+1}/{max_retries} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # exponential backoff
    raise RuntimeError(f"All {max_retries} attempts failed for {llm_type}")


def _call_deepseek(system_prompt: str, user_message: str,
                   temperature: float) -> str:
    """DeepSeek API (OpenAI-compatible endpoint)。

    开思考模式下 reasoning_content 会占 max_tokens，思维链过长会把最终 content
    截成空串（finish_reason=length）。这里做两级兜底：先开思考 32768；若仍空，
    改关思考（thinking:disabled，必出 JSON、无 reasoning 开销）重试一次。
    （外层 call_llm 的纯重试对温度 0 的空返回无效，因为每次都重跑同样的开思考请求。）
    """
    import requests
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }
    messages = [
        {"role": "system",  "content": system_prompt},
        {"role": "user",    "content": user_message},
    ]

    def _request(max_tokens, thinking):
        payload = {
            "model": LLM_MODELS["deepseek"],
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "thinking": thinking,
        }
        resp = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers=headers, json=payload, timeout=600
        )
        resp.raise_for_status()
        choice = resp.json()["choices"][0]
        return (choice["message"].get("content") or "",
                choice.get("finish_reason"))

    content, finish = _request(32768, {"type": "enabled"})
    if not content.strip():
        print("[llm_clients] 开思考返回空 content（finish=%s），回退 thinking:disabled"
              % finish)
        content, finish = _request(8192, {"type": "disabled"})
    if not content.strip():
        raise RuntimeError(
            "deepseek 连续空 content（开思考 finish=%s + 关思考兜底也失败）" % finish)
    return content


def _call_openai(system_prompt: str, user_message: str,
                 temperature: float) -> str:
    """OpenAI 兼容 Chat Completions（raw requests 直连，零 openai SDK 依赖）。

    用 raw requests 而非 openai SDK，避免 SDK 依赖的 pydantic 2.x 与
    anaconda-cloud-auth（要求 pydantic<2）冲突。base_url 默认中转站
    https://zhangsan.yun/v1，可用环境变量 OPENAI_BASE_URL 覆盖；中转站国内/
    Cloudflare 直连可达，默认不走代理（需要时设 OPENAI_PROXY 才走代理）。
    """
    import requests
    proxy = os.environ.get("OPENAI_PROXY", "")
    proxies = {"http": proxy, "https": proxy} if proxy else None
    base_url = os.environ.get(
        "OPENAI_BASE_URL", "https://zhangsan.yun/v1").rstrip("/")
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": LLM_MODELS["gpt4o"],
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        "temperature": temperature,
        "max_tokens": 4096,
        "response_format": {"type": "json_object"},
    }
    resp = requests.post(
        base_url + "/chat/completions",
        headers=headers, json=payload, timeout=600, proxies=proxies,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


def _call_anthropic(system_prompt: str, user_message: str,
                    temperature: float, model: str = None) -> str:
    """Anthropic API (Claude Opus / Sonnet)."""
    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    msg = client.messages.create(
        model=model or LLM_MODELS["opus"],
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}],
        temperature=temperature,
    )
    content = msg.content
    if isinstance(content, str):
        return content
    return "".join(getattr(b, "text", "") for b in content)


def _call_glm(system_prompt: str, user_message: str, temperature: float) -> str:
    """智谱 GLM（OpenAI 兼容 Chat Completions，open.bigmodel.cn）。

    GLM-5.3 系列思考强制开启（thinking.type 仅支持 enabled），用 reasoning_effort
    控档：low/high/max（默认 max）。默认 max 会把全部 max_tokens 花在
    reasoning_content 上，最终 content 被截成空串（finish_reason=length）。
    这里固定用 low 档，把预算留给最终 JSON 答案；若仍空，再提升 max_tokens 兜底。
    """
    import requests
    headers = {
        "Authorization": f"Bearer {GLM_API_KEY}",
        "Content-Type": "application/json",
    }
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ]

    def _request(max_tokens, effort):
        payload = {
            "model": LLM_MODELS["glm"],
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "reasoning_effort": effort,
        }
        resp = requests.post(
            "https://open.bigmodel.cn/api/paas/v4/chat/completions",
            headers=headers, json=payload, timeout=600,
        )
        resp.raise_for_status()
        choice = resp.json()["choices"][0]
        return (choice["message"].get("content") or "",
                choice.get("finish_reason"))

    content, finish = _request(8192, "low")
    if not content.strip():
        print("[llm_clients] GLM low 档返回空 content（finish=%s），提升 max_tokens 重试"
              % finish)
        content, finish = _request(32768, "low")
    if not content.strip():
        raise RuntimeError(
            "GLM 连续空 content（reasoning 吃满预算，finish=%s）" % finish)
    return content


def parse_llm_json(raw_response: str) -> dict | None:
    """
    Extract and parse JSON from LLM response.
    Handles cases where LLM wraps JSON in markdown code blocks.

    Returns parsed dict, or None if parsing fails.
    """
    # Try direct parse first
    try:
        return json.loads(raw_response)
    except json.JSONDecodeError:
        pass

    # Try to extract from ```json ... ``` block
    pattern = r"```(?:json)?\s*([\s\S]*?)```"
    match = re.search(pattern, raw_response)
    if match:
        try:
            return json.loads(match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # Try to find first { ... } block
    match = re.search(r"\{[\s\S]*\}", raw_response)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    return None


if __name__ == "__main__":
    # Quick connectivity test (requires valid API keys)
    print("Testing LLM clients...")
    test_system = "You are a helpful assistant. Reply only with valid JSON."
    test_user   = 'Reply with: {"status": "ok", "message": "connection successful"}'

    for name in ["deepseek", "gpt4o", "opus", "glm"]:
        try:
            raw = call_llm(name, test_system, test_user)
            parsed = parse_llm_json(raw)
            status = parsed.get("status") if parsed else "parse_failed"
            print(f"  {name}: {status}")
        except Exception as e:
            print(f"  {name}: FAILED - {e}")
