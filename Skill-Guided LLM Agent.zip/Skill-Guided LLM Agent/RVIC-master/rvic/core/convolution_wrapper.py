# -*- coding: utf-8 -*-
'''
convolution_wrapper.py

Drop-in replacement for the rvic_convolution C extension.

The original RVIC shipped a tiny C routine (rvic/clib/rvic_convolution.c) that
is compiled into a shared object at install time and loaded here via ctypes.
Compiling it requires a C toolchain (MSVC on Windows), which is not always
available.  The routine is a plain triple loop (see the C source below), so
here we reimplement it in pure NumPy with identical semantics.  For the scale
of a single river basin (hundreds of sources, a handful of outlets) the NumPy
version is more than fast enough.

C semantics (line-for-line equivalent):

    for s in 0..nsources-1:
        outlet = source2outlet_ind[s]
        y      = source_y_ind[s]
        x      = source_x_ind[s]
        offset = source_time_offset[s]
        xyind  = y * x_size + x
        for i in 0..subset_length-1:
            j = i + offset
            rind  = j * noutlets + outlet          # ring[j, outlet]
            uhind = i * nsources + s               # uh[i, s]
            ring[rind] += unit_hydrograph[uhind] * aggrunin[xyind]
'''

import os
import sysconfig
import numpy as np


def _load_c_extension():
    '''Try to load a compiled rvic_convolution shared object (fast path).

    Returns the ctypes-wrapped ``convolve`` function, or None if no compiled
    object is available.
    '''
    ext = (sysconfig.get_config_var('SO')
           or sysconfig.get_config_var('EXT_SUFFIX') or '')
    shared_object = 'rvic_convolution' + ext
    libpath = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
    try:
        import ctypes
        lib = np.ctypeslib.load_library(shared_object, libpath)
        lib.convolve.argtypes = [
            ctypes.c_int,                                   # nsources
            ctypes.c_int,                                   # noutlets
            ctypes.c_int,                                   # subset_length
            ctypes.c_int,                                   # x_size
            np.ctypeslib.ndpointer(np.int32),               # source2outlet_ind
            np.ctypeslib.ndpointer(np.int32),               # source_y_ind
            np.ctypeslib.ndpointer(np.int32),               # source_x_ind
            np.ctypeslib.ndpointer(np.int32),               # source_time_offset
            np.ctypeslib.ndpointer(np.float64),             # unit_hydrograph
            np.ctypeslib.ndpointer(np.float64),             # aggrunin
            np.ctypeslib.ndpointer(np.float64),             # ring
        ]
        lib.convolve.restype = None
        return lib.convolve
    except Exception:
        return None


def _numpy_convolve(nsources, noutlets, subset_length, x_size,
                    source2outlet_ind, source_y_ind, source_x_ind,
                    source_time_offset, unit_hydrograph, aggrunin, ring):
    '''Pure-NumPy equivalent of the rvic_convolution C routine.

    Modifies ``ring`` in place, exactly like the C version.
    '''
    nsources = int(nsources)
    noutlets = int(noutlets)
    subset_length = int(subset_length)
    x_size = int(x_size)

    # unit_hydrograph is flat, laid out as [subset_length, nsources]
    uh = np.asarray(unit_hydrograph, dtype=np.float64).reshape(subset_length,
                                                               nsources)

    # aggrunin is the runoff field; the C code indexes it flat (row-major),
    # i.e. xyind = y * x_size + x.
    runoff = np.asarray(aggrunin, dtype=np.float64).ravel()

    outlets = np.asarray(source2outlet_ind, dtype=np.int64).ravel()
    offsets = np.asarray(source_time_offset, dtype=np.int64).ravel()
    y_ind = np.asarray(source_y_ind, dtype=np.int64).ravel()
    x_ind = np.asarray(source_x_ind, dtype=np.int64).ravel()
    xyind = y_ind * x_size + x_ind

    # runoff at each source cell
    source_runoff = runoff[xyind]                       # (nsources,)

    # contribution of every (unit-hydrograph step i, source s):
    #   contrib[i, s] = uh[i, s] * runoff[s]
    contrib = uh * source_runoff[None, :]               # (subset_length, nsources)

    # destination ring row: j = i + offset[s]
    i_idx = np.arange(subset_length, dtype=np.int64)[:, None]
    j = i_idx + offsets[None, :]                        # (subset_length, nsources)

    # flattened ring index: rind = j * noutlets + outlet[s]
    rind = j * noutlets + outlets[None, :]              # (subset_length, nsources)

    # accumulate in place (np.add.at handles repeated indices, matching C +=)
    flat_ring = np.asarray(ring, dtype=np.float64).ravel()
    np.add.at(flat_ring, rind.ravel(), contrib.ravel())


# Prefer the compiled object if present; otherwise use the NumPy fallback.
_C_CONVOLVE = _load_c_extension()


def rvic_convolve(nsources, noutlets, subset_length, x_size,
                  source2outlet_ind, source_y_ind, source_x_ind,
                  source_time_offset, unit_hydrograph, aggrunin, ring):
    if _C_CONVOLVE is not None:
        _C_CONVOLVE(nsources, noutlets, subset_length, x_size,
                    source2outlet_ind, source_y_ind, source_x_ind,
                    source_time_offset, unit_hydrograph, aggrunin, ring)
    else:
        _numpy_convolve(nsources, noutlets, subset_length, x_size,
                        source2outlet_ind, source_y_ind, source_x_ind,
                        source_time_offset, unit_hydrograph, aggrunin, ring)
