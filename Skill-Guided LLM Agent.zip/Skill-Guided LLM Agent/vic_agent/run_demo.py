# -*- coding: utf-8 -*-
"""一键跑通五步 agent 骨架（dry-run，不跑真实 VIC / 不调真实 API）。

用法：
    python run_demo.py [--out E:/thesis/vic_agent_out] [--max-evals 3]

产物（out 目录下）：
    scheme_library.json / diagnosis_NN.json / adjustment_NN.json / state_NN.json
    / report.md / trace.json / summary.json
"""
import argparse
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.llm.agent import Agent, SkillRegistry
from vic_agent.llm.mock_llm import make_mock_llm
from vic_agent.tools.registry import build_default_registry

# 演示用初始校准状态（基线签名：体积偏高 S1 + 时序滞后 S5）
# 指标/过程特征与 hydrology.compute_metrics(theta=全 1.0) 的输出严格一致，保证假设验证 before 自洽
INITIAL_STATE = {
    "iteration": 0,
    "current_params": {"infilt": 1.0, "Ds": 1.0, "Dsmax": 1.0,
                       "Ws": 1.0, "depth": 1.0},
    "metrics": {"NSE": 0.252, "KGE": 0.522, "PBIAS_pct": 29.2, "RMSE": 2800.0},
    "process_features": {
        "volume_bias_pct": 29.2, "peak_error_pct": -13.0,
        "lowflow_error_pct": 24.3, "recession_slope_ratio": 0.82,
        "timing_bias_days": 3,
    },
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=r"E:/thesis/vic_agent_out")
    p.add_argument("--max-evals", type=int, default=3,
                   help="dry-run 的迭代次数（真实率定用 30）")
    args = p.parse_args()

    registry = SkillRegistry(os.path.join(_HERE, "skills", "_registry.json"))
    tools = build_default_registry()

    print("== 渐进式加载：预载元数据（不加载正文） ==")
    for meta in registry.preload():
        llm_tag = "LLM" if meta["llm_involved"] else "tool"
        print("  [step%d] %-22s [%s] -> %s"
              % (meta["step"], meta["id"], llm_tag, meta["output_contract"]))

    agent = Agent(registry, tools, llm_fn=make_mock_llm(), out_dir=args.out)
    summary = agent.run(INITIAL_STATE, config={"max_evals": args.max_evals})

    print("\n== 执行轨迹（可审计） ==")
    for rec in agent.trace:
        it = "" if rec["iteration"] is None else " (iter %d)" % rec["iteration"]
        ev = "" if not rec.get("event") else "  [%s]" % rec["event"]
        print("  step%d%s %-22s llm=%s%s"
              % (rec["step"], it, rec["skill_id"], rec["llm_used"], ev))

    print("\n== 汇总 ==")
    print("  best_nse   = %s" % summary["best_nse"])
    print("  best_theta = %s" % summary["best_theta"])
    print("  n_evals    = %s" % summary["n_evals"])
    print("  stop       = %s (target=%s)" % (summary["stop_reason"],
                                              summary["target"]))

    print("\n产物已写入: %s" % args.out)


if __name__ == "__main__":
    main()
