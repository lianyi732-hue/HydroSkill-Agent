# -*- coding: utf-8 -*-
"""No-Skill 一次性推荐评估：三个 LLM（DeepSeek / ChatGPT / 智谱）各给一组乘子，
每组只跑一次 VIC+RVIC（不循环、不迭代），输出率定期 + 验证期指标。

与 skill-llm 同一 vel2 配置（pcorr 强迫 + 空间场基线），公平对比。
一次调用 controller.evaluate 即「应用乘子→VIC→强迫→卷积」，随后 val_check 读
刚写的 hist_nc 算验证期（不重跑 VIC），所以每组严格只跑 1 次 VIC。

用法：
    D:/Users/user/anaconda3/python.exe code/vic_agent/run_noskill_oneshot.py
"""
import json
import os
import sys
import time

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

os.environ.setdefault("HDF5_USE_FILE_LOCKING", "FALSE")

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

import numpy as np

from vic_agent.tools.real_backend import RealHydrology
import vic_calibration.config as cfgmod

BASE = r"E:/thesis/data/8-16-110"
TARGET = 0.95
OUT_JSON = r"E:/thesis/experiments/noskill_oneshot_results.json"

# 三个 LLM 的一次性推荐乘子（m_infilt / m_Ds / m_Dsmax / m_Ws / m_depth）
RECOMMENDATIONS = {
    "deepseek": {"infilt": 0.9, "Ds": 1.0, "Dsmax": 1.5, "Ws": 0.7, "depth": 1.2},
    "chatgpt": {"infilt": 0.85, "Ds": 1.10, "Dsmax": 1.20, "Ws": 1.05, "depth": 1.10},
    "zhipu": {"infilt": 1.3, "Ds": 0.8, "Dsmax": 1.2, "Ws": 1.1, "depth": 1.2},
}


def build_vel2_config():
    cfg = {
        "global_param": os.path.join(BASE, "global_param.vel2.txt"),
        "flux_dir": os.path.join(BASE, "results_vel2"),
        "forcing_nc": os.path.join(
            BASE, "rvic", "forcings", "jialingjiang_runoff_2004_2018_vel2.nc"),
        "rvic_conv_cfg": r"E:/thesis/code/routing/rvic.convolution.jialingjiang.vel2.cfg",
        "hist_nc": os.path.join(
            BASE, "rvic_vel2", "hist",
            "jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc"),
        "nse_targets": [TARGET],
    }
    full = dict(cfgmod.CONFIG)
    full.update(cfg)
    return full


def _to_native(o):
    """把 numpy 标量转成原生 Python 类型，让 JSON 存成数字而非字符串。"""
    if isinstance(o, dict):
        return {k: _to_native(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_to_native(v) for v in o]
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def main():
    cfg = build_vel2_config()
    real = RealHydrology(cfg)  # __init__ 已 restore 纯净基线

    results = {}
    for name, theta in RECOMMENDATIONS.items():
        print("\n== %s theta=%s ==" % (name, json.dumps(theta, ensure_ascii=False)),
              flush=True)
        t0 = time.time()
        sim_cal = real.evaluate(theta)          # 1 次 VIC+RVIC，写 hist_nc
        m_cal, pf_cal = real.compute_metrics(sim_cal)   # 率定期指标
        m_val = real.val_check(theta)           # 验证期指标（读 hist_nc，不重跑）
        results[name] = _to_native({
            "theta": theta,
            "cal": m_cal,
            "cal_pf": pf_cal,
            "val": m_val,
            "elapsed_min": round((time.time() - t0) / 60.0, 2),
        })
        print("  CAL  NSE=%.4f  KGE=%.4f  PBIAS=%.2f%%  RMSE=%.1f"
              % (m_cal["NSE"], m_cal["KGE"], m_cal["PBIAS_pct"], m_cal["RMSE"]),
              flush=True)
        print("  VAL  NSE=%.4f  KGE=%.4f  PBIAS=%.2f%%  RMSE=%.1f"
              % (m_val["NSE"], m_val["KGE"], m_val["PBIAS_pct"], m_val["RMSE"]),
              flush=True)

    print("\n========== No-Skill 一次性推荐汇总（vel2 空间场基线） ==========")
    print("  %-10s %-9s %-9s %-9s %-9s %s"
          % ("model", "cal_NSE", "cal_KGE", "val_NSE", "val_KGE", "theta"))
    for name, r in results.items():
        print("  %-10s %-9.4f %-9.4f %-9.4f %-9.4f %s"
              % (name, r["cal"]["NSE"], r["cal"]["KGE"], r["val"]["NSE"],
                 r["val"]["KGE"], json.dumps(r["theta"], ensure_ascii=False)))

    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n结果已写 %s" % OUT_JSON)


if __name__ == "__main__":
    main()
