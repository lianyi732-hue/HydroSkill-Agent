# -*- coding: utf-8 -*-
"""Tool 层：确定性动作（指标、校验、检索、方案库、报告）。

生产实现复用 vic_calibration 的 metrics.py / validator.py / sceua.py；
骨架阶段用 stub 返回固定值，仅用于跑通编排链路。
"""
