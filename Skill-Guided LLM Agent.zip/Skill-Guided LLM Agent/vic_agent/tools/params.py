# -*- coding: utf-8 -*-
"""Tool：参数定义查询（get_parameter_definition）。

VIC 5 个 basin-wide 率定参数的物理意义 / 绝对物理边界 / 耦合组 / 方向提示，
作为 Step1 诊断的权威参考（静态只读，LLM 按需读，不参与计算）。
"""

# 参数绝对物理边界（绝对物理值；率定对象为乘子，depth 为三层统一乘子）。
PARAM_DEFINITIONS = {
    "infilt": {
        "param": "infilt",
        "vic_name": "b_infilt",
        "meaning": "下渗能力曲线形状（可变下渗容量指数）。↑→可利用入渗能力↓→地表径流↑、洪峰↑；↓反之。",
        "physical_bounds": [0.001, 0.5],
        "coupling_group": "B（地表径流 vs 蓄水）",
        "direction_hint": "体积偏高→↓；体积偏低/洪峰偏低→↑",
    },
    "Ds": {
        "param": "Ds",
        "vic_name": "Ds",
        "meaning": "低含水量段的基流水平。↑→枯季低流偏高；↓反之。",
        "physical_bounds": [0.0001, 0.5],
        "coupling_group": "A（基流与水量平衡）",
        "direction_hint": "低流偏高→↓；低流偏低→↑",
    },
    "Dsmax": {
        "param": "Dsmax",
        "vic_name": "Dsmax",
        "meaning": "基流量级（最大基流释放）。↑→基流峰值与总量偏高；↓反之。",
        "physical_bounds": [0.1, 200.0],
        "coupling_group": "A（基流与水量平衡）",
        "direction_hint": "体积偏高→↓；体积偏低→↑",
    },
    "Ws": {
        "param": "Ws",
        "vic_name": "Ws",
        "meaning": "非线性基流触发阈值（相对最大含水量的比例）。↑→非线性放大更晚启动、退水更缓（RR↓）；↓→更早启动、退水更快（RR↑）。",
        "physical_bounds": [0.2, 0.999],
        "coupling_group": "A（基流与水量平衡）",
        "direction_hint": "退水过快（RR>1）→↑；退水过慢（RR<1）→↓",
    },
    "depth": {
        "param": "depth",
        "vic_name": "depth",
        "meaning": "三层土壤厚度（乘子统一缩放三层）。↑→蓄水容量↑、退水更缓（RR↓）、洪峰更平缓；↓反之。",
        "physical_bounds": [0.05, 5.0],
        "coupling_group": "B（地表径流 vs 蓄水）",
        "direction_hint": "洪峰偏高/退水过快（RR>1）→↑；洪峰偏低/退水过慢（RR<1）→↓",
    },
}


def get_parameter_definition(param=None):
    """返回单个参数或全部参数的权威定义。"""
    if param is not None:
        return PARAM_DEFINITIONS.get(param, {})
    return list(PARAM_DEFINITIONS.values())
