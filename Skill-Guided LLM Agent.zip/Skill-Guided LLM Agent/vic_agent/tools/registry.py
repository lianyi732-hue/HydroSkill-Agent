# -*- coding: utf-8 -*-
"""Tool 层注册表：把确定性工具集中注册，供 LLM 层编排时按名调用。"""
from ..contracts import check
from . import case_library, hydrology, hypothesis, params, reference, report, \
    scheme_library, sensitivity


class ToolRegistry:
    def __init__(self):
        self._tools = {}

    def register(self, name, fn):
        self._tools[name] = fn
        return fn

    def call(self, name, *args, **kwargs):
        if name not in self._tools:
            raise KeyError("未注册工具: %s" % name)
        return self._tools[name](*args, **kwargs)

    def names(self):
        return sorted(self._tools)


def build_default_registry(real=None):
    """组装工具注册表。

    real=None  → 水文计算用 stub（dry-run）；
    real=RealHydrology() → 水文计算接回真实 VIC / 实测指标。
    """
    reg = ToolRegistry()
    # 方案库 / 签名
    reg.register("build_scheme_library", scheme_library.build_scheme_library)
    reg.register("classify_signatures", scheme_library.classify_signatures)
    reg.register("classify_signature", scheme_library.classify_signature)
    # 案例检索
    reg.register("retrieve_analogs", case_library.retrieve_analogs)
    # 参数定义 / 水文参考（静态只读，LLM 按需读）
    reg.register("get_parameter_definition", params.get_parameter_definition)
    reg.register("get_hydrology_reference", reference.get_hydrology_reference)
    # 假设验证（确定性，与后端无关）
    reg.register("build_tol_map", hypothesis.build_tol_map)
    reg.register("compute_actual_response", hypothesis.compute_actual_response)
    reg.register("judge_hypothesis", hypothesis.judge_hypothesis)
    reg.register("objective_score", hypothesis.objective_score)
    reg.register("veto_reasons", hypothesis.veto_reasons)
    # 水文计算（stub 或真实后端）
    if real is None:
        reg.register("evaluate", hydrology.evaluate)
        reg.register("compute_metrics", hydrology.compute_metrics)
        reg.register("validate_adjustment", hydrology.validate_adjustment)
        reg.register("final_evaluate", hydrology.final_evaluate)
        reg.register("val_check", hydrology.val_check)
    else:
        reg.register("evaluate", real.evaluate)
        reg.register("compute_metrics", real.compute_metrics)
        reg.register("validate_adjustment", real.validate_adjustment)
        reg.register("final_evaluate", real.final_evaluate)
        reg.register("val_check", real.val_check)
    # 契约（可执行格式校验）
    reg.register("validate_diagnosis_contract", check.validate_diagnosis)
    reg.register("validate_adjustment_contract", check.validate_adjustment)
    # 参数敏感性（与 evaluate/compute_metrics 共用后端）
    _eval = real.evaluate if real is not None else hydrology.evaluate
    _mets = real.compute_metrics if real is not None else hydrology.compute_metrics
    reg.register("parameter_sensitivity",
                 sensitivity.make_sensitivity(_eval, _mets))
    # 报告
    reg.register("generate_report", report.generate_report)
    return reg
