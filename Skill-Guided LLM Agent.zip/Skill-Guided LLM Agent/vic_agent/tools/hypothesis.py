# -*- coding: utf-8 -*-
"""Tool：假设验证（expected_response → actual_response → hypothesis_outcome）。

从 vic_calibration.controller 移植的确定性逻辑，供 Step3 在每轮评估后判定
本轮调整的假设是否被支持（supported / refuted / inconclusive）。纯函数，无 I/O。

判据分层：NSE（主指标）优先，过程特征（abs_PBIAS / abs_peak_error /
abs_lowflow_error / recession_slope_ratio）只作辅助，不再反向否决 NSE。
"""

RESPONSE_KEYS = ["NSE", "KGE", "abs_PBIAS", "abs_peak_error",
                 "abs_lowflow_error", "recession_slope_ratio"]

# 映射到 response_tolerance 的键
TOL_MAP = {
    "NSE": "NSE",
    "KGE": "KGE",
    "abs_PBIAS": "abs_PBIAS_pct",
    "abs_peak_error": "abs_peak_error_pct",
    "abs_lowflow_error": "abs_lowflow_error_pct",
    "recession_slope_ratio": "recession_slope_ratio",
}

# 缺键回退默认 tolerance（与 vic_calibration.config.response_tolerance 对齐；
# KGE 不在 config 冻结值里，故此处补一个与 NSE 同量级的默认值）
DEFAULT_TOL = {
    "NSE": 0.005, "KGE": 0.005,
    "abs_PBIAS_pct": 1.0, "abs_peak_error_pct": 2.0,
    "abs_lowflow_error_pct": 2.0, "recession_slope_ratio": 0.05,
}


def build_tol_map(response_tolerance):
    """由 response_tolerance 构 RESPONSE_KEYS → tol；缺键回退 DEFAULT_TOL。"""
    return {k: response_tolerance.get(v, DEFAULT_TOL.get(v, 0.0))
            for k, v in TOL_MAP.items()}


def _direction(delta, tol):
    if delta != delta:            # NaN
        return "no_clear_change"
    if delta > tol:
        return "increase"
    if delta < -tol:
        return "decrease"
    return "no_clear_change"


def compute_actual_response(prev_m, curr_m, prev_pf, curr_pf, tol_map):
    """把两轮指标差映射为方向（与 expected_response 同键）。"""
    resp = {}
    for key in RESPONSE_KEYS:
        tk = tol_map[key]
        if key == "NSE":
            delta = curr_m["NSE"] - prev_m["NSE"]
        elif key == "KGE":
            delta = curr_m["KGE"] - prev_m["KGE"]
        elif key == "abs_PBIAS":
            delta = abs(curr_m["PBIAS_pct"]) - abs(prev_m["PBIAS_pct"])
        elif key == "abs_peak_error":
            delta = abs(curr_pf["peak_error_pct"]) - abs(prev_pf["peak_error_pct"])
        elif key == "abs_lowflow_error":
            delta = abs(curr_pf["lowflow_error_pct"]) - abs(prev_pf["lowflow_error_pct"])
        else:  # recession_slope_ratio
            delta = curr_pf["recession_slope_ratio"] - prev_pf["recession_slope_ratio"]
        resp[key] = _direction(delta, tk)
    return resp


def _judge_single(exp, act):
    """单键方向判据：expected 有方向时返回 supported/refuted/inconclusive，否则 None。"""
    if exp in ("increase", "decrease"):
        if act == exp:
            return "supported"
        if (exp == "increase" and act == "decrease") or \
           (exp == "decrease" and act == "increase"):
            return "refuted"
        return "inconclusive"
    return None


def _judge_fit(expected, actual):
    """NSE+KGE 联合拟合判据：都应 increase 才算 supported；任一相反即 refuted。"""
    pairs = [(expected.get(k), actual.get(k)) for k in ("NSE", "KGE")
             if expected.get(k) in ("increase", "decrease")]
    if not pairs:
        return None
    any_opposite = any((e == "increase" and a == "decrease") or
                       (e == "decrease" and a == "increase") for e, a in pairs)
    all_agree = all(e == a for e, a in pairs)
    if any_opposite:
        return "refuted"
    if all_agree:
        return "supported"
    return "inconclusive"


def _judge_features(expected, actual):
    """过程特征（不含 NSE/KGE）综合判据；无有方向预测返回 None。"""
    feats = [(expected.get(k), actual.get(k)) for k in RESPONSE_KEYS
             if k not in ("NSE", "KGE")]
    feats = [(e, a) for e, a in feats if e in ("increase", "decrease")]
    if not feats:
        return None
    any_opposite = any((e == "increase" and a == "decrease") or
                       (e == "decrease" and a == "increase")
                       for e, a in feats)
    all_agree = all(e == a for e, a in feats)
    if any_opposite:
        return "refuted"
    if all_agree:
        return "supported"
    return "inconclusive"


def _detect_tradeoffs(actual):
    """NSE 之外的过程误差若「increase」（=误差变大，恶化），记为 hydrological trade-off。

    仅 abs_PBIAS / abs_peak_error / abs_lowflow_error 三个「误差」键有明确好坏
    （increase=变差）；recession_slope_ratio 无单调好坏，不参与。
    """
    return [k for k in ("abs_PBIAS", "abs_peak_error", "abs_lowflow_error")
            if actual.get(k) == "increase"]


def judge_hypothesis(expected, actual):
    """NSE+KGE 联合拟合判据为主，过程特征辅助（多指标协同检验）。

    主判据 = NSE+KGE 联合方向：单一指标改善不算数，二者方向一致才算 supported；
    过程特征（abs_PBIAS/abs_peak/abs_lowflow/recession）只作辅助、不反向否决拟合。
    返回 {outcome, fit_outcome, nse_outcome, kge_outcome, features_outcome, trade_offs}。
    trade_offs：拟合之外「恶化」的误差键（如 NSE 涨了但 abs_peak_error 变大）。
    """
    nse_outcome = _judge_single(expected.get("NSE"), actual.get("NSE"))
    kge_outcome = _judge_single(expected.get("KGE"), actual.get("KGE"))
    fit_outcome = _judge_fit(expected, actual)
    features_outcome = _judge_features(expected, actual)
    if fit_outcome is not None:
        outcome = fit_outcome
    elif features_outcome is not None:
        outcome = features_outcome
    else:
        outcome = "inconclusive"
    return {
        "outcome": outcome,
        "fit_outcome": fit_outcome,
        "nse_outcome": nse_outcome,
        "kge_outcome": kge_outcome,
        "features_outcome": features_outcome,
        "trade_offs": _detect_tradeoffs(actual),
    }


def objective_score(m, pf):
    """目标分（越高越好）：纯 NSE。

    多指标（KGE/PBIAS/峰/低流/退水）只报告、不做硬否决——它们仍通过
    compute_actual_response / judge_hypothesis 喂给 LLM 看，但寻优只追 NSE，
    过拟合由验证期护栏（val_check）兜底。保留此函数作为目标唯一入口，便于将来换加权。
    """
    nse = m.get("NSE")
    return nse if (nse is not None and nse == nse) else -1e9


def veto_reasons(pf, base_pf, veto_tol):
    """硬否决（协同检验硬门）：候选过程误差相对基线（未率定）恶化超阈值 → 特征名列表。

    只盯有明确好坏方向的误差特征：|体积偏差|、|洪峰误差|、|低流误差|（%）、
    |退水比-1|。任一比基线恶化超过 veto_tol 允许量即否决；空列表 = 通过。
    宁可拒掉 NSE/KGE 好看的候选，也不让低流/退水崩掉（防「刷 KGE 弃低流」退化方向）。
    """
    reasons = []
    if not base_pf:
        return reasons
    tol = veto_tol or {}

    def _deg(key, val):
        b = abs(base_pf.get(key, 0.0)) if base_pf.get(key) is not None else 0.0
        c = abs(val) if val is not None else 0.0
        return c > b + tol.get(key, 1e9)

    if _deg("volume_bias_pct", pf.get("volume_bias_pct")):
        reasons.append("volume_bias")
    if _deg("peak_error_pct", pf.get("peak_error_pct")):
        reasons.append("peak_error")
    if _deg("lowflow_error_pct", pf.get("lowflow_error_pct")):
        reasons.append("lowflow_error")
    b_rr = abs((base_pf.get("recession_slope_ratio") or 1.0) - 1.0)
    c_rr = abs((pf.get("recession_slope_ratio") or 1.0) - 1.0)
    if c_rr > b_rr + tol.get("recession_slope_ratio", 1e9):
        reasons.append("recession")
    return reasons
