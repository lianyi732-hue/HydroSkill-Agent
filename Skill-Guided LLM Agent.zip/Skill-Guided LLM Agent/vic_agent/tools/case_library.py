# -*- coding: utf-8 -*-
"""Tool：案例库 + 类比检索（Step1 用）。

对 (VB, PE, LE, RR, TE) 归一化向量做加权相似度，返回 Top-K 历史案例。
案例库默认禁用（返回空）：内置 SAMPLE_CASES 是演示用人工样例，正式实验不得
灌入（无真实来源、可能误导先验/泄漏）；生产用真实历史 jsonl 显式传入。
"""

# 5 维过程特征权重（水量/峰值/低流/退水/时序）
FEATURE_WEIGHTS = {
    "volume_bias_pct": 0.30,
    "peak_error_pct": 0.25,
    "lowflow_error_pct": 0.25,
    "recession_slope_ratio": 0.10,
    "timing_bias_days": 0.10,
}

# 每维归一化尺度（把绝对差折进 [0,1]；|diff| >= scale → 该维相似度贡献归 0）
FEATURE_SCALES = {
    "volume_bias_pct": 30.0,      # ±30% 水量偏差量级
    "peak_error_pct": 30.0,       # ±30% 洪峰偏差量级
    "lowflow_error_pct": 30.0,    # ±30% 低流偏差量级
    "recession_slope_ratio": 0.5,  # 退水斜率比量级
    "timing_bias_days": 7.0,      # 时序 ±7 天量级
}

SAMPLE_CASES = [
    {"signature": "S1", "signature_name": "体积偏高",
     "features": {"volume_bias_pct": 22.0, "peak_error_pct": 6.0,
                  "lowflow_error_pct": 21.0, "recession_slope_ratio": 0.95,
                  "timing_bias_days": 1.0},
     "action": {"param": "Dsmax", "multiplier": 0.9},
     "outcome": "supported", "nse_delta": 0.05},
    {"signature": "S1", "signature_name": "体积偏高",
     "features": {"volume_bias_pct": 18.0, "peak_error_pct": 18.0,
                  "lowflow_error_pct": 8.0, "recession_slope_ratio": 1.05,
                  "timing_bias_days": 0.0},
     "action": {"param": "infilt", "multiplier": 0.85},
     "outcome": "supported", "nse_delta": 0.03},
    {"signature": "S3", "signature_name": "峰型偏差",
     "features": {"volume_bias_pct": 3.0, "peak_error_pct": 25.0,
                  "lowflow_error_pct": 2.0, "recession_slope_ratio": 1.0,
                  "timing_bias_days": 0.0},
     "action": {"param": "depth", "multiplier": 1.2},
     "outcome": "inconclusive", "nse_delta": 0.01},
    {"signature": "S2", "signature_name": "体积偏低",
     "features": {"volume_bias_pct": -18.0, "peak_error_pct": -5.0,
                  "lowflow_error_pct": -15.0, "recession_slope_ratio": 0.85,
                  "timing_bias_days": -1.0},
     "action": {"param": "Dsmax", "multiplier": 1.1},
     "outcome": "supported", "nse_delta": 0.04},
    {"signature": "S4", "signature_name": "退水偏差",
     "features": {"volume_bias_pct": 2.0, "peak_error_pct": 3.0,
                  "lowflow_error_pct": 5.0, "recession_slope_ratio": 1.35,
                  "timing_bias_days": 0.0},
     "action": {"param": "Ds", "multiplier": 1.15},
     "outcome": "inconclusive", "nse_delta": 0.0},
]


def _similarity(query, case):
    """加权归一化距离 → 相似度 ∈ [0,1]（1=完全相同）。"""
    wsum = 0.0
    dist = 0.0
    for k, w in FEATURE_WEIGHTS.items():
        q = float(query.get(k, 0.0))
        c = float(case.get("features", {}).get(k, 0.0))
        d = min(1.0, abs(q - c) / FEATURE_SCALES[k])
        dist += w * d
        wsum += w
    return 1.0 - (dist / wsum if wsum else 0.0)


def retrieve_analogs(query_features, case_library=None, top_k=5):
    """按 5 维过程特征加权相似度召回 Top-K 历史案例。

    query_features: 当前 state 的 process_features（VB/PE/LE/RR/TE）。
    case_library: 真实历史案例列表；为 None/空时返回空列表（禁用人工样例）。
    返回：按相似度降序的案例列表，每项带 similarity（0..1）。
    """
    if not isinstance(query_features, dict) or not query_features:
        return []
    if not case_library:
        return []  # 正式实验禁用人工 SAMPLE_CASES：无真实案例库则不召回
    cases = case_library
    scored = []
    for c in cases:
        s = _similarity(query_features, c)
        item = dict(c)
        item["similarity"] = round(s, 3)
        scored.append((s, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in scored[:top_k]]
