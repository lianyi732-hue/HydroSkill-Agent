# -*- coding: utf-8 -*-
"""Tool：参数敏感性（单参数中心差分，回答「先动哪个参数」）。

- 与 evaluate / compute_metrics 共用同一后端（stub 或真实 VIC）。
- 中心差分 ∂NSE/∂参数 ≈ (NSE(θ·(1+δ)) − NSE(θ·(1−δ))) / (2δ)。
- 真实后端下，n 个活动参数会额外跑 2n 次 VIC eval，故默认在循环外、基线处
  只跑一次（`run_sensitivity` 开关），产物喂给 Step1 做方向优先级参考。
"""


def run_sensitivity(theta, active_params, delta, eval_fn, metrics_fn,
                    metric="NSE"):
    """对每个活动参数做中心差分，返回按 |sensitivity| 降序的排名。

    theta:         当前乘子 dict（如 {infilt:1.0, Ds:1.0, ...}）
    active_params: 活动参数列表
    delta:         相对扰动幅度（相对当前值，如 0.10 = ±10%）
    eval_fn(theta) -> sim；metrics_fn(sim) -> (metrics, process_features)
    """
    active_params = list(active_params or [])
    base_sim = eval_fn(theta)
    base_m, _ = metrics_fn(base_sim)
    base_nse = float(base_m.get(metric, -1e9))

    ranking = []
    for p in active_params:
        if p not in theta:
            continue
        up = dict(theta)
        up[p] = float(theta[p]) * (1.0 + delta)
        dn = dict(theta)
        dn[p] = float(theta[p]) * (1.0 - delta)
        up_m, _ = metrics_fn(eval_fn(up))
        dn_m, _ = metrics_fn(eval_fn(dn))
        up_nse = float(up_m.get(metric, -1e9))
        dn_nse = float(dn_m.get(metric, -1e9))
        d_up = up_nse - base_nse
        d_dn = dn_nse - base_nse
        grad = (d_up - d_dn) / (2.0 * delta)
        ranking.append({
            "param": p,
            "base_multiplier": float(theta[p]),
            "nse_base": round(base_nse, 4),
            "nse_up": round(up_nse, 4),
            "nse_dn": round(dn_nse, 4),
            "dNSE_up": round(d_up, 4),
            "dNSE_dn": round(d_dn, 4),
            "sensitivity": round(grad, 4),
        })
    ranking.sort(key=lambda r: -abs(r["sensitivity"]))
    for i, r in enumerate(ranking):
        r["rank_abs"] = i + 1
    return {
        "metric": metric,
        "delta": delta,
        "base_nse": round(base_nse, 4),
        "ranking": ranking,
        "most_sensitive": ranking[0]["param"] if ranking else None,
    }


def make_sensitivity(eval_fn, metrics_fn):
    """绑定后端，返回可注册的 parameter_sensitivity(theta, ...)。"""
    from . import hydrology

    def parameter_sensitivity(theta, active_params=None, delta=0.10):
        return run_sensitivity(theta, active_params or hydrology.ACTIVE_PARAMS,
                               delta, eval_fn, metrics_fn)
    return parameter_sensitivity
