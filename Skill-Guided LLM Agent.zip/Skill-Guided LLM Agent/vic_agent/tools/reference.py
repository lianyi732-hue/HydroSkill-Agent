# -*- coding: utf-8 -*-
"""Tool：水文参考查询（get_hydrology_reference）。

面向诊断/调整的静态水文知识要点（ARNO 基流 / VIC-RVIC 结构 / 参数可辨识性），
供 LLM 引用。只读，不参与计算。文献仅到作者/年份层面，避免编造 DOI。
"""

HYDROLOGY_REFERENCES = {
    "arno_baseflow": {
        "topic": "ARNO 基流方案",
        "key_points": [
            "VIC 用 ARNO 非线性基流：当底层含水量低于阈值 Ws·Wmax 时基流近似线性（Ds 控制），",
            "超过阈值后非线性放大（Dsmax 控制最大基流），故 Dsmax↔Ws↔Ds 构成耦合组 A。",
            "Dsmax 定基流总量、Ws 定「何时加速」、Ds 定低流基线水平。",
        ],
        "ref": "Todini (1996) ARNO rainfall-runoff model; Liang et al. (1994) VIC 基流参数化。",
    },
    "routing": {
        "topic": "RVIC 汇流",
        "key_points": [
            "本实验 RVIC 汇流参数固定，不在率定空间内；",
            "纯洪峰时序偏差（S5）无法用 VIC 产流参数补偿，应作为汇流/强迫疑点记录，不得强行补偿。",
        ],
        "ref": "Lohmann et al. (1996) 汇流路径模型 / RVIC 路由实现。",
    },
    "identifiability": {
        "topic": "参数可辨识性",
        "key_points": [
            "多参数同轮扰动会稀释归因信号（无法分辨谁起效），应先单参数确认方向再叠加。",
            "基流类参数（Ds/Dsmax/Ws）与水量/低流强相关；infilt/depth 与峰值/蓄水强相关。",
        ],
        "ref": "Duan, Sorooshian & Gupta (1992) SCE-UA 全局优化与参数可辨识性。",
    },
}


def get_hydrology_reference(topic=None):
    """返回指定主题或全部参考要点。"""
    if topic is not None:
        return HYDROLOGY_REFERENCES.get(topic, {})
    return list(HYDROLOGY_REFERENCES.values())
