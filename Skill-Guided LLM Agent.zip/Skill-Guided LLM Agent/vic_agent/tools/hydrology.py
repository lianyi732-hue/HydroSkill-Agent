# -*- coding: utf-8 -*-
"""Tool：水文计算（骨架 stub，生产复用 vic_calibration）。

- evaluate            → 生产: vic_calibration.controller.evaluate(theta, config, baseline_lines)
- compute_metrics     → 生产: vic_calibration.metrics.compute_cal_metrics(sim, obs, config)
- validate_adjustment → 生产: vic_calibration.validator.validate(parsed, current_theta,
                        baseline_lines, absolute_bounds, active_params)

此处返回固定值 / 假响应面，仅用于把编排链路跑通，不涉及真实 VIC / 数据。
"""

# 活动参数（与 vic_calibration.config.active_params 一致）
ACTIVE_PARAMS = ["infilt", "Ds", "Dsmax", "Ws", "depth"]

# 参数绝对物理边界（绝对物理值，非乘子；depth 为每层厚度）。
# 乘子合法性由 real_backend 用 config.compute_multiplier_bounds 从这些边界推导。
PHYSICAL_BOUNDS = {
    "infilt": (0.001, 0.5), "Ds": (0.0001, 0.5),
    "Dsmax": (0.1, 200.0), "Ws": (0.2, 0.999), "depth": (0.05, 5.0),
}

# 顶层禁止字段（旧 validator.FORBIDDEN_FIELDS，会被 reject）
FORBIDDEN_FIELDS = {
    "diagnosis_summary",
    "stop_decision",
    "best_parameter_set",
    "validation_metrics",
    "internal_station_metrics",
    "model_evaluation_budget_decision",
}

# expected_response 允许的方向（旧 validator.VALID_DIRECTIONS）
VALID_DIRECTIONS = {"increase", "decrease", "no_clear_change"}


def evaluate(theta):
    """stub：返回一个"模拟结果"占位。

    生产实现：把乘子写回 soil 参数 → 跑 VIC → RVIC → 读出口流量序列。
    """
    return {"theta": theta, "_note": "mock sim（生产替换为 VIC→RVIC 输出序列）"}


def _demo_nse(dsmax):
    """演示用假响应面：以真实基线 NSE=0.252 为锚，最优 Dsmax≈0.85 时 NSE≈0.30。

    仅用于让闭环里的 best 追踪 / 回滚在 dry-run 里可见。
    """
    return round(max(0.0, min(0.99, 0.30 - 2.133 * (float(dsmax) - 0.85) ** 2)), 3)


def compute_metrics(sim, obs=None):
    """stub：由 Dsmax 推出假 NSE 与过程特征。生产实现见 metrics.compute_cal_metrics。"""
    d = float(sim["theta"].get("Dsmax", 1.0))
    nse = _demo_nse(d)
    metrics = {"NSE": nse, "KGE": round(nse + 0.27, 3),
               "PBIAS_pct": round(29.2 * d, 1), "RMSE": round(2800.0 * d, 1)}
    pf = {"volume_bias_pct": round(29.2 * d, 1), "peak_error_pct": -13.0,
          "lowflow_error_pct": round(24.3 * d, 1), "recession_slope_ratio": 0.82,
          "timing_bias_days": 3}
    return metrics, pf


def final_evaluate(theta):
    """stub：生产实现为冻结 best 后的验证期 + 内部站点评价。

    生产实现见 vic_calibration.controller.final_evaluation(theta, config,
    baseline_lines)：只跑一次 VIC，算 Beibei 验证期 + 略阳/武胜/罗渡溪。
    """
    return {"dry_run": True, "skipped_final_evaluation": True}


def val_check(theta):
    """stub：生产实现为读 hist_nc 算 Beibei 验证期指标（不重跑 VIC）。"""
    return {"NSE": 0.30, "KGE": 0.30, "PBIAS_pct": 0.0, "RMSE": 0.0}


def validate_adjustment(adjustment, active_params=None, priors=None,
                        current_params=None, max_step=None):
    """结构/策略校验（生产实现见 vic_calibration.validator.validate）。

    已覆盖：禁字段 / expected_response 方向 / 数量上限 / 参数合法性 / mode /
    乘子正负 / 去重 / 先验区间。
    生产补：乘子边界校验（real_backend 用 multiplier_bounds）。
    """
    if not isinstance(adjustment, dict):
        return False, "输出不是 JSON 对象"
    active_params = active_params or ACTIVE_PARAMS

    # 禁字段（旧 validator.FORBIDDEN_FIELDS）：LLM 不得输出这些策略性字段
    for f in FORBIDDEN_FIELDS:
        if f in adjustment:
            return False, "禁止输出字段: %s" % f

    # expected_response 方向（旧 validator.VALID_DIRECTIONS）
    er = adjustment.get("expected_response", {})
    if not isinstance(er, dict):
        return False, "expected_response 必须是对象"
    for k, v in er.items():
        if v not in VALID_DIRECTIONS:
            return False, "expected_response.%s 非法方向: %r" % (k, v)

    adj = adjustment.get("adjustments", [])
    if not isinstance(adj, list):
        return False, "adjustments 必须是数组"
    if len(adj) > 2:
        return False, "每轮最多调整 2 个参数"

    # 先验区间（Step1 priors → Step2 决策的物理红线，reject-not-clamp）
    pr = {}
    for p in (priors or []):
        if isinstance(p, dict) and "param" in p and "range" in p:
            pr[p["param"]] = (float(p["range"][0]), float(p["range"][1]))

    seen = set()
    for a in adj:
        if not isinstance(a, dict):
            return False, "adjustment 不是对象"
        param = a.get("param")
        if param not in active_params:
            return False, "非法参数: %r" % param
        if a.get("mode") != "multiply":
            return False, "只允许 mode=multiply"
        m = a.get("multiplier")
        if m is None or not isinstance(m, (int, float)) or \
                isinstance(m, bool) or m <= 0:
            return False, "multiplier 必须为正数"
        if param in seen:
            return False, "同一参数重复调整: %s" % param
        seen.add(param)
        if param in pr:
            lo, hi = pr[param]
            if not (lo <= float(m) <= hi):
                return False, "乘子 %.4f 超出先验区间 [%.4f, %.4f] (%s)" \
                    % (float(m), lo, hi, param)
        if max_step is not None and current_params:
            cur = current_params.get(param)
            if cur is not None and abs(float(m) - float(cur)) > max_step:
                return False, "乘子 %.4f 相对当前 %.4f 的步长 %.4f 超限（>%.4f，%s）" \
                    % (float(m), float(cur), abs(float(m) - float(cur)),
                       max_step, param)
    return True, ""
