# -*- coding: utf-8 -*-
"""Tool：误差签名分类 + 方案库构建（Step0/Step1 用，骨架 stub）。

生产实现：
- classify_signatures 复用 vic_calibration.metrics 的确定性过程特征；
- build_scheme_library 复用 vic_calibration.sceua 对每种签名预跑参数方案。

签名分类要点：
- 多标签（复合误差）：水量/峰值/退水/时序各自独立判定，可同时命中；
- 不把「正常」兜底成「结构型」：无命中 → normal，缺失/NaN → missing_data；
- S6（结构型）只在显式标记（structural_flag）时出现，不做兜底。
"""

SIGNATURE_TAXONOMY = {
    "S1": {"name": "体积偏高", "rule": "|VB|>5% 且 VB>0",
           "direction": {"Dsmax": "down", "infilt": "down", "Ws": "up"}},
    "S2": {"name": "体积偏低", "rule": "|VB|>5% 且 VB<0",
           "direction": {"Dsmax": "up", "infilt": "up", "Ws": "down"}},
    "S3": {"name": "峰型偏差", "rule": "体积OK 且 |PE|>8%",
           "direction": {"infilt": "adjust", "depth": "adjust"}},
    "S4": {"name": "退水偏差", "rule": "|RR-1|>0.10",
           "direction": {"depth": "adjust", "Dsmax": "adjust", "Ds": "adjust", "Ws": "adjust"}},
    "S5": {"name": "时序偏差", "rule": "其他OK 且 |TE|>=1天",
           "direction": {"__routing__": "suspect"}},
    "S6": {"name": "结构型", "rule": "显式标记（特征矛盾 / 逼近边界）",
           "direction": {"__structural__": "suspect"}},
    "S7": {"name": "低流偏差", "rule": "|LE|>10%",
           "direction": {"Dsmax": "adjust", "Ds": "adjust", "Ws": "adjust"}},
}

DEFAULT_THRESHOLDS = {"vb": 5.0, "pe": 8.0, "le": 10.0, "rr": 0.10, "te": 1}


def classify_signatures(pf, thresholds=None):
    """多标签误差签名分类（支持复合误差）。

    返回 (status, sigs)：
      status = "missing_data"  # 关键特征缺失/NaN，不诊断
             | "normal"        # 无签名命中（正常，不是结构型）
             | "ok"            # 命中 ≥1 个签名
      sigs   = 命中的签名 ID 列表；normal/missing_data 时为空。
    """
    th = thresholds or DEFAULT_THRESHOLDS
    required = ("volume_bias_pct", "peak_error_pct",
                "recession_slope_ratio", "timing_bias_days")
    vals = {k: pf.get(k) for k in required}

    def _bad(v):
        return v is None or (isinstance(v, float) and v != v)  # None 或 NaN

    if any(_bad(vals[k]) for k in required):
        return "missing_data", []

    vb = vals["volume_bias_pct"]
    pe = vals["peak_error_pct"]
    rr = vals["recession_slope_ratio"]
    te = vals["timing_bias_days"]
    le = pf.get("lowflow_error_pct")   # 低流偏差，缺失则不触发 S7（soft）

    sigs = []
    if abs(vb) > th["vb"]:
        sigs.append("S1" if vb > 0 else "S2")
    if abs(pe) > th["pe"]:
        sigs.append("S3")
    if abs(rr - 1.0) > th["rr"]:
        sigs.append("S4")
    if not _bad(le) and abs(le) > th["le"]:
        sigs.append("S7")
    if abs(te) >= th["te"]:
        sigs.append("S5")
    if pf.get("structural_flag"):  # 显式标记的矛盾/边界特征
        sigs.append("S6")

    if not sigs:
        return "normal", []
    return "ok", sigs


def classify_signature(pf, thresholds=None):
    """主签名（复合里取第一个）；normal/missing 返回哨兵串。"""
    status, sigs = classify_signatures(pf, thresholds)
    if status == "normal":
        return "normal"
    if status == "missing_data":
        return "missing_data"
    return sigs[0]


def build_scheme_library(taxonomy=None):
    """Step0：为每种签名生成默认方案（stub）。"""
    taxonomy = taxonomy or SIGNATURE_TAXONOMY
    schemes = {}
    for sid, meta in taxonomy.items():
        schemes[sid] = {
            "name": meta["name"],
            "rule": meta["rule"],
            "recommended_direction": meta["direction"],
            # 生产实现：这里放 SCE-UA 预跑出的 warm-start 乘子区间
            "warm_start_multipliers": None,
        }
    return {"taxonomy": taxonomy, "schemes": schemes}
