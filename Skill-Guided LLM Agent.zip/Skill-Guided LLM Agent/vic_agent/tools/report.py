# -*- coding: utf-8 -*-
"""Tool：率定报告生成（Step4 产物）。"""


def generate_report(trace):
    """把执行轨迹归并成可审计的 Markdown 报告。"""
    lines = ["# VIC 率定 Agent 执行报告（骨架演示）", ""]
    for rec in trace:
        head = "## Step %d — %s" % (rec["step"], rec["skill_name"])
        if rec.get("iteration") is not None:
            head += "（iter %d）" % rec["iteration"]
        lines.append(head)
        lines.append("- LLM 参与: %s" % ("是" if rec["llm_used"] else "否"))
        tools = ", ".join("`%s`" % t for t in rec["tools_used"])
        lines.append("- 工具: %s" % (tools or "—"))
        if rec.get("event"):
            lines.append("- 事件: %s" % rec["event"])
        lines.append("")
    lines.append("> 完整契约与指标见同目录 trace.json / summary.json / *.json。")
    return "\n".join(lines) + "\n"
