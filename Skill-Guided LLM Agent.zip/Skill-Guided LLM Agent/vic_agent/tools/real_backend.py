# -*- coding: utf-8 -*-
"""真实水文后端：把 hydrology 的 evaluate / compute_metrics / validate_adjustment
接回 vic_calibration 的真实实现（VIC → RVIC → 站点径流 + 实测指标）。

率定对象是 5 个 basin-wide **乘子**（非绝对参数值）：
  theta = {infilt, Ds, Dsmax, Ws, depth}，每个乘子统一缩放全流域对应列；
  depth 乘子统一缩放三层厚度。

构造一次（加载 config / baseline / obs），再绑定到 ToolRegistry：
    real = RealHydrology()
    registry = build_default_registry(real=real)

注意：
- evaluate 会真跑 VIC（分钟级），compute_metrics 用实测径流算真实指标；
- validate_adjustment 在 stub 的结构/先验校验之上，追加乘子边界校验
  （乘子需落在 compute_multiplier_bounds 推出的 [m_lo, m_hi] 内）。
"""
import os
import sys

_CODE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
if _CODE_DIR not in sys.path:
    sys.path.insert(0, _CODE_DIR)

from vic_calibration import config as config_module
from vic_calibration import controller, metrics, soil_io
from . import hydrology


class RealHydrology:
    """真实 VIC 评价后端（乘子版）。"""

    def __init__(self, config=None):
        self.config = config or config_module.CONFIG
        # 恢复到纯净基线（防跨 run 污染），与 controller.run_llm_loop 一致
        soil_io.restore_baseline(self.config["soil_param_pristine"],
                                 self.config["soil_param"])
        self.baseline_lines = soil_io.load_soil_lines(
            self.config["soil_param_pristine"])
        self.baseline_fields = soil_io.baseline_fields(self.baseline_lines)
        self.obs = metrics.load_observed(self.config["obs_dir"],
                                         self.config["primary_keyword"],
                                         self.config["cal_start"],
                                         self.config["cal_end"])
        # 乘子合法区间（保证所有格点/土层 m·p ∈ absolute_bounds）
        self.multiplier_bounds = config_module.compute_multiplier_bounds(
            self.baseline_fields, self.config["absolute_bounds"])

    def evaluate(self, theta):
        """应用乘子 → VIC → RVIC → 返回 Beibei 率定期模拟 Series。"""
        return controller.evaluate(theta, self.config, self.baseline_lines)

    def compute_metrics(self, sim):
        """实测径流对齐，返回 (metrics, process_features)。"""
        return metrics.compute_cal_metrics(sim, self.obs, self.config)

    def final_evaluate(self, theta):
        """冻结 best 后只跑一次：Beibei 验证期 + 内部站点指标。"""
        return controller.final_evaluation(theta, self.config, self.baseline_lines)

    def val_check(self, theta):
        """读刚跑完的 hist_nc 算 Beibei 验证期指标，不重跑 VIC（验证期护栏用）。

        必须在最近一次 evaluate(theta) 之后、下一次 evaluate 之前调用
        （hist_nc 仍是该 theta 的完整 2004-2018 汇流输出）。失败返回哨兵
        NSE=-1e9，护栏据此否决候选（安全方向）。
        """
        try:
            sim_val = metrics.load_simulated(self.config["hist_nc"],
                                             self.config["val_start"],
                                             self.config["val_end"])
            obs_val = metrics.load_observed(self.config["obs_dir"],
                                            self.config["primary_keyword"],
                                            self.config["val_start"],
                                            self.config["val_end"])
            m_val, _ = metrics.compute_cal_metrics(
                sim_val[self.config["primary_station"]], obs_val, self.config)
            return m_val
        except Exception:
            return {"NSE": -1e9, "KGE": -1e9, "PBIAS_pct": None, "RMSE": None}

    def validate_adjustment(self, adjustment, active_params=None, priors=None,
                            current_params=None, max_step=None):
        """结构/先验校验（复用 stub）+ 乘子边界校验。"""
        ok, err = hydrology.validate_adjustment(
            adjustment, active_params=active_params, priors=priors,
            current_params=current_params, max_step=max_step)
        if not ok:
            return ok, err
        for a in adjustment.get("adjustments", []):
            param = a["param"]
            lo, hi = self.multiplier_bounds[param]
            m = float(a["multiplier"])
            if not (lo <= m <= hi):
                return False, "乘子 %.4f 超出边界 [%.4f, %.4f] (%s)" \
                    % (m, lo, hi, param)
        return True, ""
