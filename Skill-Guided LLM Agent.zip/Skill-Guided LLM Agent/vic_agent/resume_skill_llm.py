# -*- coding: utf-8 -*-
"""续跑 skill-llm（vel2 空间场基线）：从 checkpoint.json 恢复，再补 N 轮。

原理：Agent.run 已支持 resume_from（读 checkpoint 的 used/state/best/history/trace），
本脚本负责重建 Agent 并把 total_evals 抬到 30 + extra，使循环继续跑第 31..total 轮。

基线验证期护栏正确性：run() 会用 val_check 重算 baseline_val_nse（读当前 hist_nc）。
为避免 hist_nc 残留上一轮 best theta 的产物、把护栏基线算偏，续跑前先用 all-1.0
重跑一次 VIC 把 hist_nc 重置为真基线（val_check 与 theta 无关，只读 hist_nc）。

用法：
    D:/Users/user/anaconda3/python.exe code/vic_agent/resume_skill_llm.py --extra 20
"""
import argparse
import json
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.llm.agent import Agent, SkillRegistry
from vic_agent.llm.real_llm import make_real_llm
from vic_agent.tools.real_backend import RealHydrology
from vic_agent.tools.registry import build_default_registry

BASE = r"E:/thesis/data/8-16-110"
TARGET = 0.95            # 不可达阈值：关闭早停，保证用满 total_evals
OUT_DIR = r"E:/thesis/vic_agent_out_vel2_spatial"
CHECKPOINT = os.path.join(OUT_DIR, "checkpoint.json")


def build_vel2_config():
    cfg = {
        "global_param": os.path.join(BASE, "global_param.vel2.txt"),
        "flux_dir": os.path.join(BASE, "results_vel2"),
        "forcing_nc": os.path.join(
            BASE, "rvic", "forcings", "jialingjiang_runoff_2004_2018_vel2.nc"),
        "rvic_conv_cfg": r"E:/thesis/code/routing/rvic.convolution.jialingjiang.vel2.cfg",
        "hist_nc": os.path.join(
            BASE, "rvic_vel2", "hist",
            "jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc"),
        "nse_targets": [TARGET],
    }
    # 其它路径沿用冻结 config.CONFIG
    import vic_calibration.config as cfgmod
    full = dict(cfgmod.CONFIG)
    full.update(cfg)
    return full


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--extra", type=int, default=20, help="在 30 轮基础上再补的轮数")
    args = ap.parse_args()

    total_evals = 30 + args.extra

    if not os.path.exists(CHECKPOINT):
        raise FileNotFoundError("找不到 checkpoint: %s" % CHECKPOINT)

    cfg = build_vel2_config()
    real = RealHydrology(cfg)
    registry = build_default_registry(real=real)
    skills = SkillRegistry(os.path.join(_HERE, "skills", "_registry.json"))
    llm = make_real_llm()

    base_config = {
        "max_evals": total_evals,
        "eval_offset": 1,
        "nse_target": TARGET,
        "nse_targets": [TARGET],
        "response_tolerance": dict(real.config["response_tolerance"]),
        "run_sensitivity": False,
    }
    # 与 run_compare_vel2.py 一致的反馈容差修正
    base_config["response_tolerance"]["NSE"] = 0.0002
    base_config["response_tolerance"]["KGE"] = 0.005
    base_config["response_tolerance"]["abs_PBIAS_pct"] = 0.005

    with open(CHECKPOINT, "r", encoding="utf-8") as f:
        resume = json.load(f)
    used_before = int(resume["used"])
    print("checkpoint: used=%d  best_nse=%.4f  best_theta=%s"
          % (used_before, resume["best"]["nse"],
             json.dumps(resume["best"]["theta"], ensure_ascii=False)), flush=True)

    # 重置 hist_nc 到真基线（val_check 只读 hist_nc，与 theta 无关），
    # 使 resume 时 run() 重算的 baseline_val_nse = 基线验证期 NSE（0.6439）而非 best 的 0.6372。
    theta0 = {p: 1.0 for p in real.config["active_params"]}
    print("重置 hist_nc 到基线（all-1.0 重跑一次 VIC）...", flush=True)
    real.evaluate(theta0)
    print("基线已重置。", flush=True)

    agent = Agent(skills, registry, llm_fn=llm, out_dir=OUT_DIR)
    initial_state = {"current_params": theta0}
    summary = agent.run(initial_state, config=base_config, resume_from=resume)

    print("== 续跑完成：best NSE=%.4f  theta=%s  (%d evals, %s) =="
          % (summary["best_nse"],
             json.dumps(summary["best_theta"], ensure_ascii=False),
             summary["n_evals"], summary["stop_reason"]), flush=True)
    print("验证期 NSE=%.4f  KGE=%.4f"
          % (summary["best_val_nse"], summary["best_kge"]), flush=True)


if __name__ == "__main__":
    main()
