# -*- coding: utf-8 -*-
"""用真实 VIC 评价闭环跑 agent 骨架。

用法：
    # 秒级自检：只加载 config/baseline/obs，用 sim=obs 自比验证指标管线（不跑 VIC）
    python run_real.py --smoke

    # 正式率定：真跑 VIC（每轮分钟级），--max-evals=2 即 1 基线 + 1 调整
    python run_real.py --max-evals 2

    # 用真实 DeepSeek（默认用 mock LLM 先验证评价闭环）
    python run_real.py --max-evals 30 --real-llm

注意：正式率定的 LLM 推理质量取决于 skills/*.md 正文是否写满（真实 skill 知识）。
本 runner 先保证「评价闭环」真实；真实 LLM 推理是下一步（任务4）。
"""
import argparse
import json
import os
import sys

# Windows 控制台/重定向下强制 UTF-8，避免中文打印乱码或报错
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.llm.agent import Agent, SkillRegistry
from vic_agent.llm.mock_llm import make_mock_llm
from vic_agent.llm.real_llm import make_real_llm
from vic_agent.tools.real_backend import RealHydrology
from vic_agent.tools.registry import build_default_registry


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=r"E:/thesis/vic_agent_out")
    p.add_argument("--max-evals", type=int, default=2,
                   help="总 VIC eval 数（含基线），与 run_experiment.py 同口径")
    p.add_argument("--smoke", action="store_true",
                   help="秒级自检：不跑 VIC，只验证指标管线")
    p.add_argument("--real-llm", action="store_true",
                   help="用真实 DeepSeek（默认 mock LLM）")
    p.add_argument("--sensitivity", action="store_true",
                   help="基线处跑一次参数敏感性（额外 2×N_param 次 VIC eval）")
    p.add_argument("--resume", action="store_true",
                   help="从 out 目录的 checkpoint.json 断点续跑（跳过基线）")
    args = p.parse_args()

    real = RealHydrology()

    # ---- smoke：sim=obs 自比，验证指标管线（不跑 VIC） ----
    if args.smoke:
        m, pf = real.compute_metrics(real.obs)
        print("== smoke 自检（sim=obs，不跑 VIC） ==")
        print("  NSE=%.4f  KGE=%.4f  PBIAS=%.3f%%  RMSE=%.2f"
              % (m["NSE"], m["KGE"], m["PBIAS_pct"], m["RMSE"]))
        print("  process_features: %s" % pf)
        print("  (NSE 应≈1.0，PBIAS≈0.0，说明实测加载与指标计算正确)")
        return

    registry = build_default_registry(real=real)
    skills = SkillRegistry(os.path.join(_HERE, "skills", "_registry.json"))
    llm = make_real_llm() if args.real_llm else make_mock_llm()

    base_config = {
        "max_evals": args.max_evals,          # 总 eval（含基线）
        "eval_offset": 1,                     # 基线 eval 已在上方跑过（resume 时忽略）
        "nse_target": real.config["nse_targets"][-1],
        "nse_targets": real.config["nse_targets"],
        "response_tolerance": dict(real.config["response_tolerance"]),
        "run_sensitivity": args.sensitivity,
    }
    # 反馈容差修正（同 run_vel2.py）：config 冻结值过粗（NSE 0.005 / PBIAS 1.0，
    # 实测单步 ~0.0005 / ~0.02pp），覆盖为实测量级，否则假设永远 inconclusive。
    base_config["response_tolerance"]["NSE"] = 0.0002
    base_config["response_tolerance"]["abs_PBIAS_pct"] = 0.005

    agent = Agent(skills, registry, llm_fn=llm, out_dir=args.out)

    if args.resume:
        ckpt_path = os.path.join(args.out, "checkpoint.json")
        if not os.path.exists(ckpt_path):
            print("未找到 %s，无法续跑；请去掉 --resume 从基线重跑。" % ckpt_path)
            return
        with open(ckpt_path, "r", encoding="utf-8") as f:
            resume_from = json.load(f)
        print("断点续跑：used=%s，best_nse=%.4f（跳过基线）"
              % (resume_from.get("used"),
                 resume_from.get("best", {}).get("nse", -1e9)))
        summary = agent.run(None, config=base_config, resume_from=resume_from)
    else:
        # ---- 基线评价（1 次真实 VIC 跑），给 agent 一个真实起点 ----
        theta0 = {k: 1.0 for k in real.config["active_params"]}
        print("跑基线评价（乘子全 1.0）...")
        sim0 = real.evaluate(theta0)
        m0, pf0 = real.compute_metrics(sim0)
        print("  基线 NSE=%.4f  KGE=%.4f  PBIAS=%.3f%%"
              % (m0["NSE"], m0["KGE"], m0["PBIAS_pct"]))

        initial_state = {"iteration": 1, "current_params": theta0,
                         "metrics": m0, "process_features": pf0}
        summary = agent.run(initial_state, config=base_config)

    print("\n== 完成 ==")
    print("  best_nse   = %.4f" % summary["best_nse"])
    print("  best_theta = %s" % summary["best_theta"])
    print("  n_evals    = %s (总 VIC eval，含基线)" % summary["n_evals"])
    print("  stop       = %s (target=%s)" % (summary["stop_reason"],
                                              summary["target"]))
    print("  N_eval_to_threshold = %s" % summary["n_eval_to_threshold"])
    def _outcome(o):
        # 兼容历史版本：旧 history 条目存字符串，新条目存 {outcome,...} 字典
        return o.get("outcome") if isinstance(o, dict) else o
    print("  hypothesis_outcome  = %s" %
          [_outcome(h.get("hypothesis_outcome"))
           for h in summary["history"]])


if __name__ == "__main__":
    main()
