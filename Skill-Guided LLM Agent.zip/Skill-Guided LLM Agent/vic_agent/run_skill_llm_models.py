# -*- coding: utf-8 -*-
"""在多个 LLM 后端下跑 Skill-LLM 迭代闭环（带 skill 正文 + 方案库），50 轮冷启动。

与 run_compare_vel2.py 的 run_skill_llm 完全一致，只把 make_real_llm(model=...) 参数化，
并按给定顺序逐个模型执行（VIC 串行：共享 flux_dir/soil_param，绝不能并行）。

模型 → 后端（llm_clients.LLM_MODELS）：
  deepseek -> deepseek-v4-flash（已完成，默认不重跑）
  gpt4o    -> gpt-5.5（中转站 zhangsan.yun，即「ChatGPT」槽位）
  glm      -> GLM-5.3-Flash（open.bigmodel.cn，即「智谱」）

每个模型独立 out_dir（checkpoint / summary 互不覆盖）。

用法：
    D:/Users/user/anaconda3/python.exe code/vic_agent/run_skill_llm_models.py --models gpt4o,glm --max-evals 50
"""
import argparse
import json
import os
import sys
import time

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.llm.agent import Agent, SkillRegistry
from vic_agent.llm.real_llm import make_real_llm
from vic_agent.tools.real_backend import RealHydrology
from vic_agent.tools.registry import build_default_registry

BASE = r"E:/thesis/data/8-16-110"
TARGET = 0.95   # 不可达阈值：关闭早停，保证用满 max_evals（除非 no_progress 早停）

# 各模型独立输出目录（deepseek 目录是已完成的结果，默认不动）
MODEL_OUT_DIRS = {
    "deepseek": r"E:/thesis/vic_agent_out_vel2_spatial",
    "gpt4o":    r"E:/thesis/vic_agent_out_vel2_spatial_gpt4o",
    "glm":      r"E:/thesis/vic_agent_out_vel2_spatial_glm",
}


def build_vel2_config():
    cfg = dict()
    import vic_calibration.config as cfgmod
    cfg = dict(cfgmod.CONFIG)
    cfg["global_param"] = os.path.join(BASE, "global_param.vel2.txt")
    cfg["flux_dir"] = os.path.join(BASE, "results_vel2")
    cfg["forcing_nc"] = os.path.join(
        BASE, "rvic", "forcings", "jialingjiang_runoff_2004_2018_vel2.nc")
    cfg["rvic_conv_cfg"] = r"E:/thesis/code/routing/rvic.convolution.jialingjiang.vel2.cfg"
    cfg["hist_nc"] = os.path.join(
        BASE, "rvic_vel2", "hist",
        "jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc")
    cfg["nse_targets"] = [TARGET]
    return cfg


def run_skill_llm(cfg, out_dir, model, max_evals):
    """Skill-LLM（新框架）：all-1.0 乘子冷启动，指定 LLM 后端。"""
    real = RealHydrology(cfg)
    registry = build_default_registry(real=real)
    skills = SkillRegistry(os.path.join(_HERE, "skills", "_registry.json"))
    llm = make_real_llm(model=model)
    base_config = {
        "max_evals": max_evals,
        "eval_offset": 1,
        "nse_target": TARGET,
        "nse_targets": [TARGET],
        "response_tolerance": dict(real.config["response_tolerance"]),
        "run_sensitivity": False,
    }
    # 反馈容差修正（同 run_vel2.py / run_compare_vel2.py）：config 冻结值过粗，
    # 覆盖为实测量级，否则假设永远 inconclusive。
    base_config["response_tolerance"]["NSE"] = 0.0002
    base_config["response_tolerance"]["KGE"] = 0.005
    base_config["response_tolerance"]["abs_PBIAS_pct"] = 0.005

    agent = Agent(skills, registry, llm_fn=llm, out_dir=out_dir)
    theta0 = {k: 1.0 for k in real.config["active_params"]}
    print("  [%s] 基线评价（all-1.0 乘子）..." % model, flush=True)
    sim0 = real.evaluate(theta0)
    m0, pf0 = real.compute_metrics(sim0)
    print("  [%s] 基线 NSE=%.4f" % (model, m0["NSE"]), flush=True)
    initial_state = {"iteration": 1, "current_params": theta0,
                     "metrics": m0, "process_features": pf0}
    return agent.run(initial_state, config=base_config)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="gpt4o,glm",
                    help="逗号分隔的模型列表，按此顺序串行跑")
    ap.add_argument("--max-evals", type=int, default=50)
    args = ap.parse_args()

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    for m in models:
        if m not in MODEL_OUT_DIRS:
            raise SystemExit("未知模型 %s（可选 %s）" % (m, list(MODEL_OUT_DIRS)))

    cfg = build_vel2_config()
    results = {}
    t_all = time.time()
    for model in models:
        out_dir = MODEL_OUT_DIRS[model]
        print("\n===== Skill-LLM [%s] 冷启动 %d 轮 -> %s ====="
              % (model, args.max_evals, out_dir), flush=True)
        t0 = time.time()
        s = run_skill_llm(cfg, out_dir, model, args.max_evals)
        results[model] = {
            "best_theta": s["best_theta"],
            "best_nse": s["best_nse"],
            "best_kge": s.get("best_kge"),
            "best_score": s.get("best_score"),
            "best_val_nse": s.get("best_val_nse"),
            "n_evals": s["n_evals"],
            "stop_reason": s["stop_reason"],
            "final_evaluation": s.get("final_evaluation"),
            "out_dir": out_dir,
            "elapsed_min": round((time.time() - t0) / 60.0, 1),
        }
        print("== [%s] 完成：best NSE=%.4f  theta=%s  (%d evals, %s, %.1f min) =="
              % (model, s["best_nse"],
                 json.dumps(s["best_theta"], ensure_ascii=False),
                 s["n_evals"], s["stop_reason"], (time.time() - t0) / 60.0),
              flush=True)

    out_json = r"E:/thesis/experiments/skill_llm_models_results.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)
    print("\n结果已写 %s（总耗时 %.1f min）" % (out_json, (time.time() - t_all) / 60.0),
          flush=True)


if __name__ == "__main__":
    main()
