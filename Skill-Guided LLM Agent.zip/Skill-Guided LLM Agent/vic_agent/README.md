# vic_agent — VIC 率定 agent 骨架

参考 **HydroAgent**（Skill-orchestrated 洪水预报工作流）的三层分离，把 VIC 流域级乘子率定
重构成「Skill 层 / LLM 层 / Tool 层」+ 五步闭环。

## 架构

```
code/vic_agent/
├── skills/                    # Skill 层：做什么（规则/契约/约束）
│   ├── _registry.json         #   元数据注册表（渐进式加载第一步：只预载这里）
│   ├── step0_scheme_library.md
│   ├── step1_diagnosis.md
│   ├── step2_adjustment.md
│   ├── step3_evaluate.md
│   └── step4_report.md
├── llm/                       # LLM 层：怎么推理（不碰数值）
│   ├── agent.py               #   Agent 编排器 + SkillRegistry（渐进式加载 + 闭环）
│   ├── mock_llm.py            #   mock 后端（make_mock_llm，dry-run）
│   └── real_llm.py            #   真实后端（make_real_llm，DeepSeek + 鲁棒 JSON 提取）
├── tools/                     # Tool 层：怎么算（确定性）
│   ├── registry.py            #   工具注册表（按名调用）
│   ├── scheme_library.py      #   签名分类 + 方案库
│   ├── case_library.py        #   案例库 + 类比检索
│   ├── sensitivity.py         #   parameter_sensitivity（单参数中心差分，判断先动哪个参数）
│   ├── params.py              #   get_parameter_definition（参数物理意义/边界/耦合组）
│   ├── reference.py           #   get_hydrology_reference（ARNO/RVIC/可辨识性参考）
│   ├── hypothesis.py          #   compute_actual_response / judge_hypothesis（假设验证）
│   ├── hydrology.py           #   evaluate / compute_metrics / validate / final_evaluate（stub）
│   ├── real_backend.py        #   RealHydrology：接回真实 VIC / 实测指标
│   └── report.py              #   报告生成
├── contracts/                 # 真 JSON Schema 契约（draft-07，机器可校验）
│   ├── diagnosis.schema.json
│   └── adjustment.schema.json
├── run_demo.py                # dry-run 一键跑通五步闭环（stub）
├── run_real.py                # 真实 VIC 评价闭环（--smoke / --max-evals / --real-llm）
└── README.md
```

## 三层职责（严格守界）

| 层 | 回答 | 干 | 不干 |
|----|------|----|----|
| Skill | 做什么 | 规则、契约、约束、物理红线 | 不算数、不决策 |
| LLM | 怎么推理 | 诊断、先验区间、调整决策、解释 | 不碰数值、不校验 |
| Tool | 怎么算 | 指标、签名分类、校验、检索、报告 | 不推理 |

## 五步闭环 + 契约流

```
Step0 方案库构建 ──tool──► scheme_library.json          （一次）
        ┌──────────────────────────────────────────┐
        ▼                                          │
Step1 误差诊断/先验 ──tool+LLM──► diagnosis_NN.json   │
Step2 参数调整决策 ──LLM+tool──► adjustment_NN.json    │  × N 轮
Step3 迭代评估 ──tool──► state_NN.json ──────────────┘
Step4 率定报告 ──tool──► report.md                    （一次）
全程落 trace.json / summary.json（可审计）
```

闭环内置：`max_evals` 停止 / `nse_target` 达目标即停 / `best_so_far` 追踪 /
`rollback_nse_drop` 回滚（单轮 NSE 较 best 跌超阈值即回滚 theta）。Step2 的
`validate_adjustment` 会校验乘子是否落在 Step1 的**先验区间**内，越界 reject-not-clamp
并 re-ask（`reask_max` 上限）；re-ask 用尽仍非法则**本轮 no-op**，绝不带着坏调整继续。

实验管理对齐已落地：每轮 Step3 用 `compute_actual_response` + `judge_hypothesis` 对
Step2 的 `expected_response` 做**假设验证**（supported / refuted / inconclusive），写入
`history.json`（同口径喂回 Step1 诊断）；`n_eval_to_threshold` 记录首次达阈值的 eval 序号；
闭环结束后用 `final_evaluate` 冻结 best 只跑一次验证期 + 内部站点（Beibei/略阳/武胜/罗渡溪）。

假设验证采用**分层判据**：NSE（主指标）方向优先，过程特征（abs_PBIAS / abs_peak_error /
abs_lowflow_error / recession_slope_ratio）只作辅助、不再反向否决 NSE。`hypothesis_outcome`
返回 `{outcome, nse_outcome, features_outcome}`，其中 `outcome` 为主判据——避免「NSE 已上升
却被过程特征误判为 refuted」误导 LLM。

其余已落地：误差签名**多标签复合分类**（水量/峰值/退水/时序各自判定，正常态不再误判为
结构型，缺失/NaN 单独标记）；`contracts/check.py` 对 `*.schema.json` 做**可执行校验**
（required/type/enum）；方案库的推荐方向注入 Step1 决策上下文。

## 运行（dry-run）

```powershell
D:/Users/user/anaconda3/python.exe code/vic_agent/run_demo.py --max-evals 3
```

dry-run 不跑真实 VIC、不调真实 API，用 `make_mock_llm()` 返回脚本化契约，几十毫秒跑完。

## 消融口径（关键设计约定）

retrieval / priors / scheme_library 是**机制（scaffold）**，不是 skill 知识。为保持
「skill vs noskill = 全文 vs 最小指令、其余全同」的干净因果，两条件必须跑在**同一个
scaffold**上，唯一翻转的是 skill 正文。若另要论证 scaffold 本身有用，那是第二个正交
实验（scaffold ON/OFF，skill 固定），不要混进 skill 的二元对照。

## 参数敏感性 / 参数定义 / 水文参考（对齐教师框架）

Step1 诊断额外注入三类确定性信息（tool 层预载，LLM 只读不重算）：

- **`parameter_sensitivity`**：单参数中心差分 ∂NSE/∂乘子，返回按 |sensitivity| 降序的
  排名，帮助「先动敏感参数」。默认关闭——真实后端下 n 个活动参数会额外跑 **2n 次 VIC
  eval**（5 参数 = 10 次），故在循环外、基线处只跑一次。开启方式：在 `run_real.py` 的
  `config` 里加 `"run_sensitivity": True`（可配 `"sensitivity_delta"`），产物落
  `sensitivity.json`。
- **`get_parameter_definition`**：参数物理意义 / 绝对物理边界 / 耦合组 / 方向提示，
  权威来源在 `tools/params.py` 的 `PARAM_DEFINITIONS`。
- **`get_hydrology_reference`**：ARNO 基流 / RVIC 汇流 / 参数可辨识性的静态要点，
  来源在 `tools/reference.py`（文献仅到作者/年份层面，避免编造 DOI）。

## 预算口径

预算单位 = **一次 VIC 模型评价**（`max_evals`），不是 LLM 调用。每轮 = 1 次 VIC eval +
2 次 LLM 调用（Step1 诊断 + Step2 调整，含 re-ask 更多）。三方法统一用 VIC-eval 预算，
LLM 调用次数随架构而异，不计入预算（LLM 调用成本 << 一次 VIC 评价）。

## 接真实 LLM（DeepSeek）

`llm/real_llm.py` 提供 `make_real_llm()`，把 `llm_fn` 接口接回 DeepSeek，并做鲁棒
JSON 提取（真实 LLM 可能包 markdown fence）+ API 失败降级（走 re-ask/no-op）：

```python
from vic_agent.llm.real_llm import make_real_llm

agent = Agent(registry, tools, llm_fn=make_real_llm(), out_dir=args.out)
```

`run_real.py` 的 `--real-llm` 已默认走这条路。推理质量取决于 `skills/step1_diagnosis.md`
与 `skills/step2_adjustment.md` 的正文（已写入真实诊断决策树 / 调整规则，源自
`vic_calibration_v1.3.skill`）。

## 接真实水文计算（已接线）

`tools/real_backend.py` 的 `RealHydrology` 把 `evaluate` / `compute_metrics` /
`validate_adjustment` 接回 `vic_calibration` 的真实实现，与
`vic_calibration/run_experiment.py` 走的是**同一条** VIC→RVIC 链：

| 骨架 stub | 真实后端（RealHydrology） |
|----------|--------------------------|
| `hydrology.evaluate` | `controller.evaluate(theta, config, baseline_lines)`（VIC→RVIC→Beibei 率定期序列） |
| `hydrology.compute_metrics` | `metrics.compute_cal_metrics(sim, obs, config)`（实测径流算 NSE/KGE/PBIAS/RMSE + 5 过程特征） |
| `hydrology.validate_adjustment` | 结构/先验校验 + `compute_multiplier_bounds` 物理边界 |
| `hydrology.final_evaluate` | `controller.final_evaluation(theta, config, baseline_lines)`（验证期 + 内部站点） |

```powershell
# 秒级自检（不跑 VIC）：sim=obs 自比验证指标管线
D:/Users/user/anaconda3/python.exe code/vic_agent/run_real.py --smoke

# 正式率定（真跑 VIC，每轮分钟级；--max-evals=30 为含基线的总 eval 数）
D:/Users/user/anaconda3/python.exe code/vic_agent/run_real.py --max-evals 30
```

## 对齐旧实现的任务清单（已全部落地）

`vic_calibration/`（旧实现）已是**完整可跑**的 Skill-LLM / NoSkill-LLM / SCE-UA 系统：
`run_experiment.py` 统一入口、`controller.run_llm_loop` 真实闭环（含 hypothesis_outcome /
resume / 回滚 / final_evaluation）、`validator.py` 参数约束（≤2 参数 / 禁字段 /
check_bounds）。本骨架的"补齐"实质是**在 3 层设计下重写这些行为**，并新增旧实现
没有的 scaffold（案例库 / 先验区间 / 方案库）：

1. **真实 VIC 评价闭环** ✅ 已接：`real_backend.RealHydrology` + `run_real.py`。
2. **参数约束对齐** ✅ 已做：禁字段 reject / `expected_response` 方向校验 / ≤2 参数 /
   mode / 正乘子 / 去重 / 先验区间，物理边界由 `compute_multiplier_bounds` 等价覆盖。
3. **实验管理对齐** ✅ 已做：history 注入 / `expected_response`→`hypothesis_outcome` /
   `final_evaluation` / `n_eval_to_threshold` 同口径日志（`history.json` + `summary.json`）。
4. **真实 LLM 推理** ✅ 已接：`real_llm.make_real_llm`（DeepSeek + 鲁棒 JSON 提取），
   `run_real.py --real-llm` 已默认走此路；skill 正文拆进诊断/调整两步 system prompt。
5. **案例检索升级** ✅ 已做：`retrieve_analogs` 改为 (VB,PE,LE,RR,TE) 5 维加权相似度。
