# -*- coding: utf-8 -*-
"""方案 A（velocity=2 汇流修正）+ 重率定闭环。

背景（接 diagnose_routing.py 的结论）：
- 3 天汇流时滞是 NSE 瓶颈；RVIC VELOCITY 1→2 m/s 后单位线质心 4.57→1.66 天，
  时滞归零，冻结 best_theta 已达 NSE=0.6856 cal / 0.6215 val。
- 本脚本在 velocity=2 汇流上「重新率定」5 参数，目标 NSE=0.8。
- 强迫用 ×0.89（pcorr）；不再用强度校正（velocity=2 已把峰误从 -37% 收到 -11.9%，
  强度校正会过度削峰、压死低水）。

依赖：rvic_vel2 参数文件（velocity=2）+ pcorr 强迫已就绪；本脚本只指路、不重算。
用法：
    python run_vel2.py --max-evals 30            # 从 best_theta 起点重率定
    python run_vel2.py --resume --max-evals 100  # 断点续跑
"""
import argparse
import json
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.llm.agent import Agent, SkillRegistry
from vic_agent.llm.real_llm import make_real_llm
from vic_agent.tools.real_backend import RealHydrology
from vic_agent.tools.registry import build_default_registry

from vic_calibration import config as config_module

BASE = r"E:/thesis/data/8-16-110"

# 方案 A（×0.89 无强度校正）在 velocity=1 汇流上重率定的 best_theta，作为本阶段起点
PLAN_A_BEST = {"infilt": 1.3, "Ds": 1.0, "Dsmax": 1.0, "Ws": 1.0, "depth": 1.3}

# 本阶段目标：velocity=2 汇流上冻结起点已 0.6856，目标抬到 0.8 尽力追
TARGET = 0.8


def build_vel2_config():
    """把 vic_calibration.CONFIG 覆盖到 velocity=2 汇流的产物路径上（不动原文件）。"""
    cfg = dict(config_module.CONFIG)
    cfg["global_param"] = os.path.join(BASE, "global_param.vel2.txt")
    cfg["flux_dir"] = os.path.join(BASE, "results_vel2")
    cfg["forcing_nc"] = os.path.join(
        BASE, "rvic", "forcings", "jialingjiang_runoff_2004_2018_vel2.nc")
    cfg["rvic_conv_cfg"] = r"E:/thesis/code/routing/rvic.convolution.jialingjiang.vel2.cfg"
    cfg["hist_nc"] = os.path.join(
        BASE, "rvic_vel2", "hist",
        "jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc")
    return cfg


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=r"E:/thesis/vic_agent_out_vel2")
    p.add_argument("--model", default="deepseek",
                   choices=["deepseek", "gpt4o", "opus", "sonnet", "glm"],
                   help="LLM 后端（默认 deepseek 保持旧行为；换 GLM 用 --model glm）")
    p.add_argument("--max-evals", type=int, default=30,
                   help="总 VIC eval 数（含基线）")
    p.add_argument("--resume", action="store_true",
                   help="从 out 目录 checkpoint.json 断点续跑")
    p.add_argument("--from-scratch", action="store_true",
                   help="从乘子全 1.0 起点（默认从方案 A best_theta 起点）")
    p.add_argument("--rollback-nse-drop", type=float, default=None,
                   help="回滚阈值（默认 0.05；平坦地形建议 0.002）")
    p.add_argument("--tol-nse", type=float, default=None,
                   help="NSE 假设判定容差（默认 0.0002；config 冻结 0.005 过粗，实测单步 ~0.0005）")
    p.add_argument("--max-step", type=float, default=None,
                   help="单轮单参数最大乘子步长（默认不限；建议 0.1）")
    args = p.parse_args()

    cfg = build_vel2_config()
    if not os.path.isdir(cfg["flux_dir"]) or not os.listdir(
            os.path.join(BASE, "forcing_6hr_pcorr")):
        print("请先用 smoke_pcorr.py --factor 0.89 备好 ×0.89 校正强迫。")
        return

    real = RealHydrology(cfg)
    registry = build_default_registry(real=real)
    skills = SkillRegistry(os.path.join(_HERE, "skills", "_registry.json"))
    llm = make_real_llm(args.model)

    base_config = {
        "max_evals": args.max_evals,
        "eval_offset": 1,
        "nse_target": TARGET,
        "nse_targets": [TARGET],
        "response_tolerance": dict(real.config["response_tolerance"]),
        "run_sensitivity": False,
    }
    # 反馈容差修正：config.py 冻结值（NSE 0.005 / abs_PBIAS_pct 1.0）相对实际单步变化
    # （NSE ~0.0005、PBIAS ~0.02pp）过粗，会把每步都判 no_clear_change → 假设永远
    # inconclusive → LLM 拿不到方向反馈。这里在 vic_agent 层覆盖（不改 config.py）。
    base_config["response_tolerance"]["NSE"] = 0.0002
    base_config["response_tolerance"]["abs_PBIAS_pct"] = 0.005
    if args.rollback_nse_drop is not None:
        base_config["rollback_nse_drop"] = args.rollback_nse_drop
    if args.tol_nse is not None:
        base_config["response_tolerance"]["NSE"] = args.tol_nse
    if args.max_step is not None:
        base_config["max_step"] = args.max_step
    agent = Agent(skills, registry, llm_fn=llm, out_dir=args.out)

    if args.resume:
        ckpt_path = os.path.join(args.out, "checkpoint.json")
        if not os.path.exists(ckpt_path):
            print("未找到 %s，无法续跑；请去掉 --resume。" % ckpt_path)
            return
        with open(ckpt_path, "r", encoding="utf-8") as f:
            resume_from = json.load(f)
        print("断点续跑：used=%s，best_nse=%.4f"
              % (resume_from.get("used"), resume_from.get("best", {}).get("nse", -1e9)))
        summary = agent.run(None, config=base_config, resume_from=resume_from)
    else:
        theta0 = {k: 1.0 if args.from_scratch else PLAN_A_BEST.get(k, 1.0)
                  for k in real.config["active_params"]}
        tag = "乘子全 1.0" if args.from_scratch else "方案 A best_theta 起点"
        print("跑基线评价（velocity=2 汇流，%s）..." % tag, flush=True)
        sim0 = real.evaluate(theta0)
        m0, pf0 = real.compute_metrics(sim0)
        print("  基线 NSE=%.4f  KGE=%.4f  PBIAS=%.3f%%"
              % (m0["NSE"], m0["KGE"], m0["PBIAS_pct"]), flush=True)
        initial_state = {"iteration": 1, "current_params": theta0,
                         "metrics": m0, "process_features": pf0}
        summary = agent.run(initial_state, config=base_config)

    print("\n== 完成（velocity=2 汇流重率定） ==")
    print("  best_nse   = %.4f" % summary["best_nse"])
    print("  best_theta = %s" % summary["best_theta"])
    print("  n_evals    = %s（总 VIC eval，含基线）" % summary["n_evals"])
    print("  stop       = %s (target=%s)" % (summary["stop_reason"],
                                              summary["target"]))
    fe = summary.get("final_evaluation") or {}
    if isinstance(fe, dict) and "Beibei_val" in fe:
        print("  验证期 Beibei: NSE=%.4f" % fe["Beibei_val"].get("NSE", float("nan")))


if __name__ == "__main__":
    main()
