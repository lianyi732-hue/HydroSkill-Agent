# Step 4 · 率定报告

## Instructions（做什么 / 不做什么）
- 冻结最优参数后，把全程轨迹归并成可审计、可读的报告。
- 报告是"可解释性"的直接产物，必须保留每轮的假设 → 动作 → 响应 → 结论。

## Tools（可调用的确定性动作）
- `generate_report`：把 trace 归并成 Markdown。

## Resources（可访问数据）
- 执行轨迹 trace（Step0–4 的全部输入输出摘要）

## Output Contract（必须产出）
- `report.md`：人可读的率定审计报告
