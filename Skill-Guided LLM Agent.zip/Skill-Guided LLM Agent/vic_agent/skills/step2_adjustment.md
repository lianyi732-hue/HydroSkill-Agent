# Step 2 · 参数调整决策

## Instructions（做什么 / 不做什么）

基于 Step1 的 diagnosis.json（含先验区间），选择 **0–2 个**参数给出具体**乘子**。

- **默认每轮只调 1 个参数**：先验证单个参数的方向是否正确（看下一轮 Step3 的
  `hypothesis_outcome.outcome`，即 NSE 优先的主判据），方向被确认（`supported`）后再
  叠加第二个参数。两个参数同轮一起调会无法归因谁起了作用——尤其当二者效果相反时
  （如 `Dsmax↓` 本应改善却被 `Ds↑` 抵消）。有多个高置信先验时也只动最高置信的那一个。
- **判据分层**：`hypothesis_outcome.outcome` 是主判据（NSE 方向优先）；`nse_outcome`
  是 NSE 单独方向，`features_outcome` 是过程特征方向（仅作诊断参考）。方向确认看
  `outcome` / `nse_outcome`，不要因为 `features_outcome` 是 refuted 就否定一个 NSE
  已 `supported` 的方向。
- 乘子必须落在 Step1 先验区间 `[lo, hi]` 内，越界即触发 re-ask（reject，不 clamp）。
- 本版只允许 `mode = "multiply"`；`multiplier` 为乘子，必须为正数；同一参数不得重复出现。
- 只给方向 + 幅度的物理解释，不计算任何指标。
- 给出 `expected_response`：预测本轮调整后 NSE / KGE / abs_PBIAS / abs_peak_error /
  abs_lowflow_error / recession_slope_ratio 各自的响应方向（供 Step3 做假设验证）。
- 严格输出一个 JSON 对象（adjustment.json），不得输出其他文字。
- 不负责判断率定是否停止。

## 调整幅度建议（按迭代进程，非硬约束）

- 第 1–3 次迭代：相对当前乘子 ±30% 粗调（`multiplier ≈ 0.7 ~ 1.3`）；
- 第 4–6 次迭代：相对当前乘子 ±20% 细调（× 0.8 ~ 1.2）；
- 第 7 次以后：默认 ±10% 精修（× 0.9 ~ 1.1），但**不要自我限制步长**：
  - 若某方向已被 `outcome`/`nse_outcome` 判为 `supported`，可沿该方向继续
    **大步长推进**（±20%~30%），一路推到乘子边界附近，不必缩到 ±5%；
  - 若 NSE 连续多轮 `no_clear_change`、或离 `nse_target` 仍远，允许重新
    大跨步探索（可回到 ±40%），不要被「精修阶段」卡死在局部平台。

幅度只是建议；硬约束仍是「先验区间 + 乘子边界」。乘子超先验区间会被 reject。

## 参数耦合警示

- 耦合组 A（基流与水量平衡）`Dsmax ↔ Ws ↔ Ds`：Dsmax 定基流总量、Ws 定"何时加速"、
  Ds 定低流基流水平。调 Dsmax 后要重估 Ws 是否仍合理。
- 耦合组 B（地表径流 vs 蓄水）`infilt ↔ depth`：infilt 定地表径流比例、depth 定蓄满容量。
  避免同时大调两者。
- 耦合关系仅用于**选出最该先动的那 1 个参数**：同一耦合组内（A 或 B）原则上**不要同轮
  同时调 2 个**——先动主导参数、方向确认后再动耦合的次要参数。

## 乘子边界（由 validator 据基线 × 绝对物理边界推导，reject 不 clamp）

乘子 m 需保证所有格点/土层 m·p_base ∈ 绝对物理边界，故不同参数的合法乘子区间不同，
以 `validate_adjustment` 返回的乘子边界为准。冷启动乘子全部为 1.0（即基线本身）。

## 冷启动基线（第一轮乘子 = all-1.0，供你校准量级）

```text
infilt = 1.0    Ds = 1.0    Dsmax = 1.0    Ws = 1.0    depth = 1.0
```

validator 会按乘子边界 reject 越界值（不 clamp）。

## Tools（可调用的确定性动作）
- `validate_adjustment`：校验参数合法性 / mode / 乘子正负 / 数量上限 / 去重 / 先验区间。

## Resources（可访问数据）
- `diagnosis.json`（Step1 产物，含先验区间与方向）。

## Output Contract（必须产出）
严格输出 adjustment.json：

```json
{
  "adjustments": [
    {"param": "Dsmax", "mode": "multiply", "multiplier": 0.8,
     "physical_reason": "降低基流释放量级，削减总水量与低流阶段的系统性高估。",
     "confidence": 0.72}
  ],
  "expected_response": {
    "NSE": "increase", "KGE": "increase", "abs_PBIAS": "decrease",
    "abs_peak_error": "no_clear_change", "abs_lowflow_error": "decrease",
    "recession_slope_ratio": "decrease"
  }
}
```

- `adjustments`：长度 0–2，可为 `[]`（诊断建议不调整时）；
- `param` 仅 infilt/Ds/Dsmax/Ws/depth；`mode` 仅 "multiply"；`multiplier` 为乘子 > 0；
- `physical_reason`：方向 + 幅度的物理解释；`confidence` 0–1；
- `expected_response`：**可选**，预测本轮调整后各响应的方向。键固定为
  NSE / KGE / abs_PBIAS / abs_peak_error / abs_lowflow_error / recession_slope_ratio，
  值仅 increase / decrease / no_clear_change。
