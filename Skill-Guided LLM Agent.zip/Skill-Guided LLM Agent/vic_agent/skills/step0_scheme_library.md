# Step 0 · 方案库构建（离线）

## Instructions（做什么 / 不做什么）
- 在率定开始前，把历史误差签名分级，为每级预计算参数方案（warm start）。
- 由 tool 层确定性执行（SCE-UA / 敏感性扫描），LLM 不参与。
- 产物是后续 Step1/Step2 的检索基础，率定中途不得改动。

## Tools（可调用的确定性动作）
- `build_scheme_library`：签名型 → 推荐方向 + warm-start 乘子区间。

## Resources（可访问数据）
- 历史率定日志（`experiments/*.jsonl`）
- SCE-UA 轨迹 / 敏感性扫描结果

## Output Contract（必须产出）
- `scheme_library.json`：{taxonomy, schemes}
