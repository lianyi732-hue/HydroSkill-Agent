# Step 3 · 迭代评估

## Instructions（做什么 / 不做什么）
- 应用 Step2 的 adjustment，跑一次完整模型评价，产出新一轮状态。
- 全部由 tool 层确定性计算，LLM 不参与。

## Tools（可调用的确定性动作）
- `evaluate`：应用乘子 → VIC → RVIC → 读模拟序列。
- `compute_metrics`：算 NSE/KGE/PBIAS/RMSE + 五个过程特征。

## Resources（可访问数据）
- `adjustment.json`（Step2 产物）

## Output Contract（必须产出）
- `state.json`：新一轮 calibration state（含 metrics + process_features）
- 供下一轮 Step1 消费（闭环）。
