# -*- coding: utf-8 -*-
"""LLM 层：Agent 编排器 + 可插拔后端。

后端接口约定：llm_fn(system_prompt, user_prompt, task) -> str（JSON 字符串）。
- mock_llm 用于骨架 dry-run；
- 生产替换为 vic_calibration 外的 llm_clients.call_llm（真实 DeepSeek API）。
"""
