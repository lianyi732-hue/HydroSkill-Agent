# -*- coding: utf-8 -*-
"""LLM 层：Agent 编排器（三层分离中的"怎么推理"层）。

职责（严格守界）：
- 预载 skill 元数据，命中任务后按需加载正文（progressive disclosure）
- 编排 Step0–4 闭环：推理步调 LLM，计算步调 tool
- 维护 JSON 契约流，落可审计 trace

本层不计算任何水文量、不校验数值、不决定"怎么调"。数值与校验全部在 tools 层。
"""
import json
import os

DEFAULT_RUN_CONFIG = {
    "metric": "NSE",            # 主指标（best / 停止判定依据）
    "max_evals": 30,            # 总 VIC 评价预算（含基线；一次完整评价 = 1 eval）
    "eval_offset": 0,           # 循环前已消耗的 eval 数（真实率定=1 基线跑；dry-run=0）
    "nse_target": 0.50,         # 到达即停（主阈值）
    "nse_targets": [0.50],      # 阈值列表：记录 N_eval_to_threshold
    "rollback_nse_drop": 0.05,  # 本轮 NSE 较 best 跌超此阈值 → 回滚 theta
    "reask_max": 3,             # 单步 re-ask 上限（拒绝后重问）
    "run_sensitivity": False,   # 是否在基线处跑一次参数敏感性（真实后端额外 2×N_param+1 次 eval，计入预算）
    "sensitivity_delta": 0.10,  # 单参数中心差分扰动幅度（乘子相对量）
    "case_library": None,       # 类比案例库（None=禁用人工 SAMPLE_CASES，正式实验不灌虚构先验）
    "print_every": 10,          # 每 N 轮打印一条进度（末轮/达目标必打）
    # 冻结的 response tolerance（与 vic_calibration.config 一致，假设验证用）
    "response_tolerance": {
        "NSE": 0.005, "KGE": 0.005, "abs_PBIAS_pct": 1.0, "abs_peak_error_pct": 2.0,
        "abs_lowflow_error_pct": 2.0, "recession_slope_ratio": 0.05,
    },
    "val_guard_tol": 0.02,             # 候选验证期 NSE 允许低于基线的量（防过拟合护栏）
}


class SkillRegistry:
    """Skill 元数据注册表 + 正文按需加载。"""

    def __init__(self, registry_path):
        self.path = registry_path
        with open(registry_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self._skills = {s["id"]: s for s in data["skills"]}
        self._bodies = {}

    def preload(self):
        """渐进式加载第一步：只返回轻量元数据，不读正文。"""
        meta = []
        for s in sorted(self._skills.values(), key=lambda x: x["step"]):
            meta.append({k: s[k] for k in
                         ("id", "step", "name", "trigger",
                          "output_contract", "llm_involved")})
        return meta

    def skill(self, skill_id):
        return self._skills[skill_id]

    def load_body(self, skill_id):
        """渐进式加载第二步：命中任务后才读 SKILL.md 正文。"""
        if skill_id not in self._bodies:
            rel = self._skills[skill_id]["skill_file"]
            path = os.path.join(os.path.dirname(self.path), rel)
            with open(path, "r", encoding="utf-8") as f:
                self._bodies[skill_id] = f.read()
        return self._bodies[skill_id]


class Agent:
    """把 Step0–4 编排成一条可审计、带闭环的执行链。"""

    def __init__(self, skills, tools, llm_fn, out_dir):
        self.skills = skills
        self.tools = tools
        self.llm = llm_fn
        self.out_dir = out_dir
        self.trace = []
        self.summary = {}
        self._scheme = None

    # ---- 落盘 ----
    def _write_json(self, filename, obj):
        os.makedirs(self.out_dir, exist_ok=True)
        path = os.path.join(self.out_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        return path

    def _write_text(self, filename, text):
        os.makedirs(self.out_dir, exist_ok=True)
        path = os.path.join(self.out_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return path

    def _record(self, step, iteration, skill_id, tools_used, inputs, outputs,
                llm_used, event=None):
        rec = {
            "step": step,
            "iteration": iteration,
            "skill_id": skill_id,
            "skill_name": self.skills.skill(skill_id)["name"],
            "llm_used": llm_used,
            "tools_used": tools_used,
            "inputs": inputs,
            "outputs": outputs,
        }
        if event:
            rec["event"] = event
        self.trace.append(rec)
        return rec

    # ---- LLM JSON 请求 + 校验 + re-ask ----
    @staticmethod
    def _parse(raw):
        try:
            return json.loads(raw)
        except Exception as e:
            return {"_parse_error": str(e)}

    @staticmethod
    def _run_validators(obj, validators):
        errs = []
        for v in validators:
            r = v(obj)
            if r:
                errs.extend(r)
        return errs

    def _ask_json(self, system, user, task, validators, reask_max):
        """调 LLM 取 JSON → 逐个 validator 校验 → 失败 re-ask。

        validators: callable(obj) -> list[str]（空=通过）。
        返回 (obj, errs)；errs 非空 = re-ask 用尽后仍失败。
        """
        raw = self.llm(system, user, task=task)
        obj = self._parse(raw)
        errs = self._run_validators(obj, validators)
        attempts = 1
        while errs and attempts <= reask_max:
            raw = self.llm(system, user + "\n\n被拒绝原因: " + "; ".join(errs),
                           task=task)
            obj = self._parse(raw)
            errs = self._run_validators(obj, validators)
            attempts += 1
        return obj, errs

    def _scheme_hints(self, sigs):
        """从方案库抽取命中签名对应的推荐方向，喂给 LLM。"""
        hints = []
        for s in sigs:
            sc = self._scheme.get("schemes", {}).get(s)
            if sc:
                hints.append({"signature": s, "rule": sc["rule"],
                              "direction": sc["recommended_direction"]})
        return hints

    # ---- 主流程 ----
    def run(self, initial_state, config=None, resume_from=None):
        cfg = dict(DEFAULT_RUN_CONFIG)
        if config:
            cfg.update(config)
        metric = cfg["metric"]
        tol_map = self.tools.call("build_tol_map", cfg["response_tolerance"])
        targets = cfg.get("nse_targets", [cfg["nse_target"]])
        stop_target = cfg["nse_target"]
        # 验证期护栏参考：基线验证期 NSE（防过拟合）。
        # hist_nc 此刻仍是 run 脚本里 evaluate(theta0) 的产物，val_check 免重跑 VIC。
        baseline_val_nse = float(self.tools.call(
            "val_check", initial_state["current_params"]).get("NSE", -1e9))

        # ---------- Step 0：方案库（tool only，一次） ----------
        sid = "step0_scheme_library"
        self._scheme = self.tools.call("build_scheme_library")
        self._write_json("scheme_library.json", self._scheme)
        self._record(0, None, sid, ["build_scheme_library"], {},
                     {"schemes": list(self._scheme["schemes"].keys())}, False)

        # ---------- 可选：基线参数敏感性（tool only，一次性，喂 Step1 方向优先级） ----------
        # 只在全新起点（非 resume）跑；resume 沿用上次已落盘的 sensitivity.json。
        self._sensitivity = None
        sens_cost = 0
        if cfg.get("run_sensitivity") and resume_from is None:
            self._sensitivity = self.tools.call(
                "parameter_sensitivity", initial_state["current_params"],
                delta=cfg.get("sensitivity_delta", 0.10))
            self._write_json("sensitivity.json", self._sensitivity)
            self._record(0, None, sid, ["parameter_sensitivity"],
                         {"theta0": initial_state["current_params"]},
                         {"most_sensitive": self._sensitivity["most_sensitive"]},
                         False)
            # 敏感性额外跑 1（base，与基线重复）+ 2×N_param 次 VIC eval，计入总预算
            sens_cost = 2 * len(self._sensitivity.get("ranking", [])) + 1

        # ---------- 初始化 best / 或从 checkpoint 恢复（存完整 metrics，回滚时 state 才一致） ----------
        if resume_from is not None:
            best = dict(resume_from["best"])
            state = resume_from["state"]
            used = int(resume_from["used"])
            stop_reason = resume_from.get("stop_reason", "max_evals")
            history = list(resume_from.get("history", []))
            n_eval_to_threshold = dict(resume_from.get("n_eval_to_threshold", {}))
            for t in targets:
                n_eval_to_threshold.setdefault(t, None)
            self.trace = list(resume_from.get("trace", []))
        else:
            best = {"theta": dict(initial_state["current_params"]),
                    "nse": float(initial_state["metrics"].get(metric, -1e9)),
                    "kge": float(initial_state["metrics"].get("KGE", -1e9)),
                    "score": self.tools.call(
                        "objective_score", initial_state["metrics"],
                        initial_state["process_features"]),
                    "val_nse": baseline_val_nse,
                    "metrics": dict(initial_state["metrics"]),
                    "pf": dict(initial_state["process_features"])}
            state = initial_state
            used = cfg.get("eval_offset", 0) + sens_cost  # 循环前已消耗（基线 + 可选敏感性）
            stop_reason = "max_evals"
            history = []                               # 每轮动作+响应+假设验证，喂 LLM + 落盘
            n_eval_to_threshold = {t: None for t in targets}
            base_nse = float(initial_state["metrics"].get(metric, -1e9))
            for t in targets:                          # 基线 eval 本身可能已达标，必须计入
                if base_nse >= t:
                    n_eval_to_threshold[t] = used

        noop_streak = 0    # 连续 no-op 计数：防止 LLM 反复空调整导致死循环

        # ---------- 闭环：Step1→Step2→Step3 ----------
        while used < cfg["max_evals"]:
            it = used + 1

            # ---- Step 1：诊断 + 先验（LLM + tool，多标签 + 方案库参与） ----
            sid = "step1_diagnosis"
            status, sigs = self.tools.call("classify_signatures",
                                           state["process_features"])
            analogs = self.tools.call("retrieve_analogs",
                                      state.get("process_features", {}),
                                      case_library=cfg.get("case_library"))
            scheme_hints = self._scheme_hints(sigs)
            system = self.skills.load_body(sid)
            user = json.dumps({"state": state, "signatures": sigs,
                               "status": status, "analogs": analogs,
                               "scheme_hints": scheme_hints,
                               "sensitivity": self._sensitivity,
                               "param_defs": self.tools.call(
                                   "get_parameter_definition"),
                               "hydrology_refs": self.tools.call(
                                   "get_hydrology_reference"),
                               "history": history[-8:]},
                              ensure_ascii=False, indent=2)
            diagnosis, errs = self._ask_json(
                system, user, task="diagnosis",
                validators=[lambda o: self.tools.call(
                    "validate_diagnosis_contract", o)],
                reask_max=cfg["reask_max"])
            if errs:
                # 契约校验最终失败 → no-op 诊断：给全部活动参数保守待观察先验，
                # 保住 priors minItems=1 契约自洽 + 锁小 Step2 调整幅度（避免无约束大跳）
                diagnosis = {
                    "signature": (sigs[0] if sigs else "normal"),
                    "signature_name": (sigs[0] if sigs else "normal"),
                    "top_k_analogs": analogs,
                    "priors": [
                        {"param": p, "range": [0.95, 1.05],
                         "direction": "no_clear_change", "confidence": 0.3}
                        for p in state.get("current_params", {})
                    ],
                    "reasoning": "诊断契约校验失败，本轮 no-op：全部参数保守待观察。",
                }
            self._write_json("diagnosis_%02d.json" % it, diagnosis)
            self._record(1, it, sid,
                         ["classify_signatures", "retrieve_analogs",
                          "get_parameter_definition", "get_hydrology_reference",
                          "validate_diagnosis_contract"],
                         {"signatures": sigs, "status": status,
                          "scheme_hints": scheme_hints},
                         {"priors": diagnosis.get("priors"),
                          "contract_ok": not errs}, True)

            # ---- Step 2：调整决策（LLM + 契约 + 先验校验，失败 no-op） ----
            sid = "step2_adjustment"
            system = self.skills.load_body(sid)
            user = json.dumps({"diagnosis": diagnosis}, ensure_ascii=False,
                              indent=2)
            priors = diagnosis.get("priors", [])

            def _semantic(o):
                ok, e = self.tools.call(
                    "validate_adjustment", o, priors=priors,
                    current_params=state["current_params"],
                    max_step=cfg.get("max_step"))
                return [] if ok else [e]

            adjustment, errs = self._ask_json(
                system, user, task="adjustment",
                validators=[
                    lambda o: self.tools.call("validate_adjustment_contract", o),
                    _semantic,
                ],
                reask_max=cfg["reask_max"])
            if errs:
                # 校验最终失败 → no-op（绝不带着非法调整继续）
                adjustment = {"adjustments": []}
            self._write_json("adjustment_%02d.json" % it, adjustment)
            self._record(2, it, sid,
                         ["validate_adjustment_contract", "validate_adjustment"],
                         {"priors": priors},
                         {"adjustments": adjustment.get("adjustments"),
                          "accepted": not errs}, True,
                         event=None if not errs else "rejected_noop")

            # ---- Step 3：迭代评估 + 假设验证 + best/回滚 + 阈值记录 ----
            sid = "step3_evaluate"
            prev_m = state.get("metrics")
            prev_pf = state.get("process_features")
            theta_tried = self._apply(state["current_params"],
                                      adjustment.get("adjustments", []))
            if theta_tried == state["current_params"]:
                # 明确 no-op（调整为空或被拒）：绝不重复跑同一个 theta，不消耗
                # VIC eval、不制造冗余数据点；连续 no-op 超限即停（防死循环）。
                self._record(3, it, sid, [],
                             {"theta_tried": theta_tried,
                              "nse": float(prev_m.get(metric, -1e9))},
                             {"theta_next": state["current_params"]}, False,
                             event="noop_skipped")
                history.append({
                    "iteration": it, "action": None,
                    "before": {"NSE": prev_m.get("NSE")},
                    "after": {"NSE": prev_m.get("NSE")},
                    "hypothesis_outcome": "noop_skipped",
                })
                noop_streak += 1
                if noop_streak > cfg["reask_max"]:
                    stop_reason = "no_progress"
                    self._write_json("checkpoint.json", {
                        "used": used, "state": state, "best": best,
                        "history": history,
                        "n_eval_to_threshold": n_eval_to_threshold,
                        "stop_reason": stop_reason, "trace": self.trace})
                    break
                continue
            noop_streak = 0
            sim = self.tools.call("evaluate", theta_tried)
            m, pf = self.tools.call("compute_metrics", sim)
            used += 1
            new_nse = float(m.get(metric, -1e9))
            new_score = self.tools.call("objective_score", m, pf)

            # 假设验证：本轮 adjustment 的 expected_response vs 实际方向
            outcome = None
            expected = adjustment.get("expected_response", {}) \
                if isinstance(adjustment, dict) else {}
            if expected and prev_m is not None:
                actual = self.tools.call("compute_actual_response",
                                         prev_m, m, prev_pf, pf, tol_map)
                outcome = self.tools.call("judge_hypothesis", expected, actual)

            # best 选择：纯 NSE 目标 → 验证期护栏（多指标只报告、不否决）
            event = None
            val_nse = None
            if new_score > best["score"]:
                val_m = self.tools.call("val_check", theta_tried)
                val_nse = float(val_m.get("NSE", -1e9))
                if val_nse >= baseline_val_nse - cfg.get("val_guard_tol", 0.02):
                    best = {"theta": dict(theta_tried), "nse": new_nse,
                            "kge": float(m.get("KGE", -1e9)), "score": new_score,
                            "val_nse": val_nse, "metrics": dict(m), "pf": dict(pf)}
                    event = "best_update"
                else:
                    event = "overfit_rejected"
            elif new_score < best["score"] - cfg["rollback_nse_drop"]:
                event = "rollback_to_best"

            if expected and prev_m is not None:
                history.append({
                    "iteration": it,
                    "action": adjustment.get("adjustments", []) or None,
                    "before": {"NSE": prev_m.get("NSE"), "KGE": prev_m.get("KGE"),
                               "PBIAS_pct": prev_m.get("PBIAS_pct")},
                    "after": {"NSE": m.get("NSE"), "KGE": m.get("KGE"),
                              "PBIAS_pct": m.get("PBIAS_pct")},
                    "actual_response": actual,
                    "hypothesis_outcome": outcome,
                    "val_nse": val_nse,
                    "event": event,
                })

            # 被拒收（验证期过拟合 / 回滚）的候选不推进状态，回退到 best
            revert = event in ("rollback_to_best", "overfit_rejected")
            next_theta = dict(best["theta"]) if revert else dict(theta_tried)
            next_metrics = dict(best["metrics"]) if revert else dict(m)
            next_pf = dict(best["pf"]) if revert else dict(pf)

            for t in targets:
                if n_eval_to_threshold[t] is None and new_nse >= t:
                    n_eval_to_threshold[t] = used

            new_state = {"iteration": it,
                         "current_params": next_theta,
                         "metrics": next_metrics,
                         "process_features": next_pf}
            self._write_json("state_%02d.json" % it, new_state)
            step3_tools = ["evaluate", "compute_metrics"]
            if outcome is not None:
                step3_tools += ["compute_actual_response", "judge_hypothesis"]
            self._record(3, it, sid, step3_tools,
                         {"theta_tried": theta_tried, "nse": new_nse,
                          "hypothesis_outcome": outcome},
                         {"theta_next": next_theta}, False, event=event)

            state = new_state
            if new_nse >= stop_target:
                stop_reason = "target_reached"
            # 进度：每 print_every 轮打印一条（末轮/达目标必打），避免逐轮刷屏
            if (used % cfg.get("print_every", 10) == 0 or
                    used == cfg["max_evals"] or new_nse >= stop_target):
                oc = outcome.get("outcome") if isinstance(outcome, dict) else outcome
                print("[eval %3d/%3d] nse=%.4f  kge=%.4f  best_nse=%.4f  score=%.4f  outcome=%s  event=%s  theta=%s"
                      % (used, cfg["max_evals"], new_nse, m.get("KGE", float("nan")),
                         best["nse"], best["score"], oc, event or "-",
                         json.dumps(best["theta"], ensure_ascii=False)),
                      flush=True)
            # 断点：每轮结束落 checkpoint，供 --resume 续跑
            self._write_json("checkpoint.json", {
                "used": used, "state": state, "best": best,
                "history": history, "n_eval_to_threshold": n_eval_to_threshold,
                "stop_reason": stop_reason, "trace": self.trace})
            if stop_reason == "target_reached":
                break

        # ---------- Step 4：报告 + 冻结后最终评价 ----------
        sid = "step4_report"
        self._record(4, None, sid, ["generate_report"], {},
                     {"report": "report.md"}, False)
        report_md = self.tools.call("generate_report", self.trace)
        self._write_text("report.md", report_md)

        # 冻结 best 后只跑一次：验证期 + 内部站点（dry-run 返回 skip 占位）
        final = self.tools.call("final_evaluate", best["theta"])

        self.summary = {"best_theta": best["theta"], "best_nse": best["nse"],
                        "best_kge": best.get("kge"), "best_score": best.get("score"),
                        "best_val_nse": best.get("val_nse"),
                        "baseline_val_nse": baseline_val_nse,
                        "best_metrics": best.get("metrics"), "best_pf": best.get("pf"),
                        "n_evals": used, "stop_reason": stop_reason,
                        "target": stop_target,
                        "n_eval_to_threshold": n_eval_to_threshold,
                        "history": history,
                        "final_evaluation": final}
        self._write_json("trace.json", self.trace)
        self._write_json("history.json", history)
        self._write_json("summary.json", self.summary)
        return self.summary

    @staticmethod
    def _apply(current, adjustments):
        theta = dict(current)
        for a in adjustments:
            theta[a["param"]] = float(a["multiplier"])
        return theta
