# -*- coding: utf-8 -*-
"""Mock LLM 后端：骨架演示用，返回可脚本化的 JSON 契约。

接口约定：llm_fn(system_prompt, user_prompt, task) -> str。
- make_mock_llm 返回有状态后端，adjustment 脚本按调用顺序消费，
  用于演示「先验越界 re-ask / 回滚 / 校验失败 no-op」的控制流。
- 生产替换为真实 DeepSeek API（见包 __init__ 说明）。
"""
import json


def make_mock_llm(adjustment_script=None):
    """返回有状态 mock 后端。

    adjustment_script: 每轮 adjustment 调用的乘子序列，越界值会触发
    先验区间 re-ask（由 Agent 层的 validate 拒绝后再问）。
    默认脚本演示：0.8 改进 → 1.3 越界被拒 → 0.6 导致回滚 → 0.85 到最优。
    """
    script = list(adjustment_script) if adjustment_script else \
        [0.8, 1.3, 0.6, 0.85]
    calls = {"adjustment": 0}

    def llm(system_prompt, user_prompt, task):
        if task == "diagnosis":
            # 回显工具层分类出的主签名（复合取第一个）+ 检索出的类比案例
            sigs = ["S1"]
            analogs = [{"signature": "S1",
                        "action": {"param": "Dsmax", "multiplier": 0.9},
                        "outcome": "supported", "nse_delta": 0.05}]
            try:
                u = json.loads(user_prompt)
                if u.get("signatures"):
                    sigs = list(u["signatures"])
                if isinstance(u.get("analogs"), list) and u["analogs"]:
                    analogs = u["analogs"]
            except Exception:
                pass
            primary = sigs[0] if sigs else "S1"
            return json.dumps({
                "signature": primary,
                "signature_name": "体积偏高" if primary == "S1" else primary,
                "top_k_analogs": analogs,
                "priors": [
                    {"param": "Dsmax", "range": [0.6, 1.0],
                     "direction": "decrease", "confidence": 0.72},
                ],
                "reasoning": "水量偏高且低流偏高，优先检验降低 Dsmax 压缩基流。",
            }, ensure_ascii=False)

        if task == "adjustment":
            i = calls["adjustment"]
            calls["adjustment"] += 1
            mult = script[min(i, len(script) - 1)]
            return json.dumps({
                "adjustments": [
                    {"param": "Dsmax", "mode": "multiply", "multiplier": mult,
                     "physical_reason": "降低基流释放量级。",
                     "confidence": 0.72},
                ],
                "expected_response": {
                    "NSE": "increase", "abs_PBIAS": "decrease",
                    "abs_peak_error": "no_clear_change",
                    "abs_lowflow_error": "decrease",
                    "recession_slope_ratio": "decrease",
                },
            }, ensure_ascii=False)

        raise ValueError("未知 task: %s" % task)

    return llm
