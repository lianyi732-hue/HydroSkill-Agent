# -*- coding: utf-8 -*-
"""真实 LLM 后端：把 vic_agent 的 llm_fn 接口接回 DeepSeek。

接口约定：llm_fn(system_prompt, user_prompt, task) -> str（返回 JSON 文本）。
- 调 llm_clients.call_llm("deepseek", system_prompt, user_prompt)；
- 用 parse_llm_json 做鲁棒 JSON 提取（真实 LLM 可能包 markdown fence），
  解析成功则重新序列化为干净 JSON，失败则原样返回（交由 Agent 层 re-ask）；
- API 调用失败降级为空串，走 re-ask / no-op 路径，不崩掉长跑。
"""
import json
import os
import sys

_CODE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
if _CODE_DIR not in sys.path:
    sys.path.insert(0, _CODE_DIR)

from llm_clients import call_llm, parse_llm_json  # noqa: E402


def make_real_llm(model="deepseek"):
    """返回真实 LLM 后端（llm_fn 接口）。"""
    def llm(system_prompt, user_prompt, task):
        try:
            raw = call_llm(model, system_prompt, user_prompt)
        except Exception as e:  # noqa: BLE001
            print("[vic_agent.llm.real_llm] LLM 调用失败（降级为空，走 re-ask/no-op）：%s"
                  % e)
            return ""
        parsed = parse_llm_json(raw)
        if parsed is None:
            return raw  # 交给 Agent 层 _parse 失败 → re-ask
        return json.dumps(parsed, ensure_ascii=False)
    return llm
