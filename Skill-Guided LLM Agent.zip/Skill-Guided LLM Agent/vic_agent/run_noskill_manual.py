# -*- coding: utf-8 -*-
"""NoSkill 手动一次性评价：把老师（advisor）给的 5 个参数**绝对值**跑一遍模型。

与 run_compare_vel2.py 里「NoSkill-LLM 循环」不同，本脚本**不调 LLM、不循环**：
  1. 你在下方 ADVISOR_PARAMS 里填入老师给的绝对值；
  2. 脚本内部换算成乘子（实际值 = 基线 × 乘子）；
  3. 跑 VIC→RVIC 一次（率定期），再 final_evaluate 一次（验证期 + 内部站点）；
  4. 打印率定/验证指标，供与 Skill-LLM / SCE-UA 对照。

用法：
    python run_noskill_manual.py                  # velocity=2 配置（对齐三方法对照）
    python run_noskill_manual.py --base           # 方案C 日尺度配置（global_param.C.txt）

输入形式（绝对值，物理单位）：
    infilt : b_infilt 下渗曲线指数，无量纲，典型 0.1~0.5（基线 0.3）
    Ds     : 低含水段基流 Ds，mm/day，典型 0.0001~0.5（基线 0.001）
    Dsmax  : 基流峰值 Dsmax，mm/day，空间异质（基线 3.25~189，参考均值见运行时打印）
    Ws     : 基流非线性触发阈值，0~1（基线 0.8）
    depth  : 三层土壤深度 [d1, d2, d3]，m（基线 [0.1, 0.3, 1.5]，总 1.9）
"""
import argparse
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_CODE = os.path.dirname(_HERE)
if _CODE not in sys.path:
    sys.path.insert(0, _CODE)

from vic_agent.tools.real_backend import RealHydrology  # noqa: E402
from vic_calibration import config as config_module, soil_io  # noqa: E402

BASE = r"E:/thesis/data/8-16-110"

# ==================================================================== #
#  ★★★ 在这里输入老师给的参数绝对值（唯一需要改动的地方） ★★★
# ==================================================================== #
ADVISOR_PARAMS = {
    "infilt": 0.3,                 # 下渗曲线指数（无量纲）
    "Ds":     0.001,               # 基流低段 Ds（mm/day）
    "Dsmax":  0.0,                 # 基流峰值 Dsmax（mm/day；空间异质→按全场均值换算；0=不调）
    "Ws":     0.8,                 # 基流非线性阈值（0~1）
    "depth":  [0.1, 0.3, 1.5],     # 三层土壤深度 [d1,d2,d3]（m）
}
# ==================================================================== #


def build_vel2_config():
    """velocity=2 配置覆盖（与 run_compare_vel2.py 完全一致）。"""
    cfg = dict(config_module.CONFIG)
    cfg["global_param"] = os.path.join(BASE, "global_param.vel2.txt")
    cfg["flux_dir"] = os.path.join(BASE, "results_vel2")
    cfg["forcing_nc"] = os.path.join(
        BASE, "rvic", "forcings", "jialingjiang_runoff_2004_2018_vel2.nc")
    cfg["rvic_conv_cfg"] = r"E:/thesis/code/routing/rvic.convolution.jialingjiang.vel2.cfg"
    cfg["hist_nc"] = os.path.join(
        BASE, "rvic_vel2", "hist",
        "jialingjiang_convolution.rvic.h0i.2019-01-02-00-00-00.nc")
    return cfg


def absolute_to_multipliers(advisor, real):
    """老师给的绝对值 → 乘子 dict。

    基线参考值实时取自 real.baseline_fields（不硬编码）：
      - infilt/Ds/Ws 全流域常数 → 除该常数；
      - Dsmax 空间异质 → 除全场均值（等比例缩放整场）；
      - depth 三层 → 总深度比（保持三层比例）。
    """
    ref = {
        "infilt": float(real.baseline_fields["infilt"][0]),
        "Ds":     float(real.baseline_fields["Ds"][0]),
        "Ws":     float(real.baseline_fields["Ws"][0]),
        "Dsmax":  float(real.baseline_fields["Dsmax"].mean()),
    }
    depth_layers = soil_io.depth_layers_baseline(real.baseline_lines)
    ref_depth_total = float(sum(depth_layers))

    depth_in = advisor["depth"]
    if isinstance(depth_in, (list, tuple)):
        depth_total = float(sum(depth_in))
    else:  # 标量视作总深度
        depth_total = float(depth_in)

    theta = {
        "infilt": advisor["infilt"] / ref["infilt"],
        "Ds":     advisor["Ds"] / ref["Ds"],
        "Ws":     advisor["Ws"] / ref["Ws"],
        "depth":  depth_total / ref_depth_total,
    }
    # Dsmax=0 表示不调（保持基线）
    if advisor["Dsmax"] > 0:
        theta["Dsmax"] = advisor["Dsmax"] / ref["Dsmax"]
    else:
        theta["Dsmax"] = 1.0

    return theta, ref, depth_layers, ref_depth_total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", action="store_true",
                    help="用方案C日尺度配置（默认 velocity=2）")
    args = ap.parse_args()

    cfg = config_module.CONFIG if args.base else build_vel2_config()
    cfg = dict(cfg)

    real = RealHydrology(cfg)

    theta, ref, depth_layers, ref_depth_total = absolute_to_multipliers(
        ADVISOR_PARAMS, real)

    # ---- 换算表（含越界提醒） ----
    print("\n== 绝对值 → 乘子换算（实际值 = 基线 × 乘子） ==")
    print("  %-7s %-12s %-12s %-9s %s"
          % ("参数", "基线参考", "老师值", "乘子", "实际值"))
    print("  %-7s %-12s %-12s %-9s %s"
          % ("infilt", "%.4g" % ref["infilt"], "%.4g" % ADVISOR_PARAMS["infilt"],
             "%.4f" % theta["infilt"], "%.4g" % (ref["infilt"] * theta["infilt"])))
    print("  %-7s %-12s %-12s %-9s %s"
          % ("Ds", "%.4g" % ref["Ds"], "%.4g" % ADVISOR_PARAMS["Ds"],
             "%.4f" % theta["Ds"], "%.4g" % (ref["Ds"] * theta["Ds"])))
    dsmax_str = ("%.4g" % ADVISOR_PARAMS["Dsmax"]) if ADVISOR_PARAMS["Dsmax"] > 0 \
        else "不调(=1.0)"
    print("  %-7s %-12s %-12s %-9s %s"
          % ("Dsmax", "%.3g(均值)" % ref["Dsmax"], dsmax_str,
             "%.4f" % theta["Dsmax"], "整场×%.4f" % theta["Dsmax"]))
    print("  %-7s %-12s %-12s %-9s %s"
          % ("Ws", "%.4g" % ref["Ws"], "%.4g" % ADVISOR_PARAMS["Ws"],
             "%.4f" % theta["Ws"], "%.4g" % (ref["Ws"] * theta["Ws"])))
    print("  %-7s %-12s %-12s %-9s %s"
          % ("depth", "总%.4g" % ref_depth_total, str(ADVISOR_PARAMS["depth"]),
             "%.4f" % theta["depth"],
             "三层×%.4f" % theta["depth"]))

    # 乘子越界提醒（不动 vic_calibration，只在 vic_agent 层提示）
    for k, m in theta.items():
        lo, hi = real.multiplier_bounds[k]
        if not (lo <= m <= hi):
            print("  [!] %s 乘子 %.4f 越界 [%.4f, %.4f]，VIC 可能拒绝/失真"
                  % (k, m, lo, hi))

    # ---- 率定期评价（VIC→RVIC 跑一次） ----
    print("\n跑率定期评价（VIC→RVIC，约分钟级）...", flush=True)
    sim = real.evaluate(theta)
    m, pf = real.compute_metrics(sim)
    print("  [率定] NSE=%.4f  KGE=%.4f  PBIAS=%.3f%%  RMSE=%.2f"
          % (m["NSE"], m["KGE"], m["PBIAS_pct"], m["RMSE"]))
    print("  [过程特征] 体积偏差=%.2f%%  峰值误差=%.2f%%  低流误差=%.2f%%  "
          "退水斜率比=%.3f  时间偏差=%.1f天"
          % (pf.get("volume_bias_pct", 0.0), pf.get("peak_error_pct", 0.0),
             pf.get("lowflow_error_pct", 0.0), pf.get("recession_slope_ratio", 1.0),
             pf.get("timing_bias_days", 0.0)))

    # ---- 冻结后只跑一次：验证期 + 内部站点 ----
    print("\n跑 final_evaluate（验证期 + 内部站点）...", flush=True)
    final = real.final_evaluate(theta)
    for key in ["Beibei_val"] + [n for n, _ in cfg["internal_stations"]]:
        v = final.get(key)
        if isinstance(v, dict) and "NSE" in v:
            print("  [%s] NSE=%.4f  KGE=%.4f  PBIAS=%.3f%%"
                  % (key, v["NSE"], v["KGE"], v["PBIAS_pct"]))
        else:
            print("  [%s] %s" % (key, v))

    print("\n== 完成（一次性，无循环） ==")
    print("  乘子 theta = %s" % theta)


if __name__ == "__main__":
    main()
