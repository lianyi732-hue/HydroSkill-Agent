# -*- coding: utf-8 -*-
"""vic_agent：VIC 率定 agent 智能体框架（三层分离 + 多 skill 编排）。

三层：
  skills/  Skill 层 —— 做什么（规则、契约、约束）
  llm/     LLM 层   —— 怎么推理（诊断、决策、解释，不碰数值）
  tools/   Tool 层  —— 怎么算（指标、校验、检索，确定性）

五步：
  Step0 方案库构建 → Step1 误差诊断/先验判断 → Step2 参数调整决策
  → Step3 迭代评估 → Step4 率定报告

参考：HydroAgent (Yang et al., 2026, arXiv:2607.23983)。
"""
