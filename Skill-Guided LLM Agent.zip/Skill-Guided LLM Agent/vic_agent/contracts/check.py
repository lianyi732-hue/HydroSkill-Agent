# -*- coding: utf-8 -*-
"""JSON Schema 校验（draft-07），用 jsonschema 库完整执行 contracts/*.json。

覆盖 const / exclusiveMinimum / minimum / maximum / minItems / maxItems /
enum / additionalProperties / 嵌套 items 等 draft-07 全部约束，不再是手写子集。
依赖：jsonschema（4.x，已随 anaconda 提供）。
"""
import json
import os

import jsonschema
from jsonschema import Draft7Validator

_HERE = os.path.dirname(os.path.abspath(__file__))
_cache = {}


def load_schema(name):
    if name not in _cache:
        with open(os.path.join(_HERE, name), "r", encoding="utf-8") as f:
            _cache[name] = json.load(f)
    return _cache[name]


def validate_contract(obj, schema):
    """返回错误列表（空=通过）。用 Draft7Validator 完整校验 draft-07 契约。"""
    errors = []
    for err in Draft7Validator(schema).iter_errors(obj):
        path = getattr(err, "json_path", "$")
        errors.append("%s: %s" % (path, err.message))
    return errors


def validate_diagnosis(obj):
    return validate_contract(obj, load_schema("diagnosis.schema.json"))


def validate_adjustment(obj):
    return validate_contract(obj, load_schema("adjustment.schema.json"))
