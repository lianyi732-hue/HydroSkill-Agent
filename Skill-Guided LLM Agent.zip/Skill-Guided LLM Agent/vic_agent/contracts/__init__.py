# -*- coding: utf-8 -*-
"""契约层：步骤间 JSON 契约的 schema 定义 + 极简可执行校验。

schema 是机器可读的 draft-07 子集；check.py 提供 required/type/enum 校验，
让契约从"说明性文件"变成"可执行门槛"。
"""
